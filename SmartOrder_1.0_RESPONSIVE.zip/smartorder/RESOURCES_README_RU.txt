Ресурсы SmartOrder
==================

Папку resources разместите рядом с main.py:

  SmartOrder_1.0_ADAPTIVE\
  |-- main.py
  |-- resources\
      |-- smartorder_logo_icon.png
      |-- loading2.gif
      |-- login_background.gif

Не помещайте resources внутрь пакета smartorder\smartorder. При сборке PyInstaller
добавьте содержимое resources как data-файлы в каталог resources рядом с exe
или используйте --add-data "resources;resources".

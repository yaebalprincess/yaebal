"""Safe SmartOrder patch staging.

Patch archives never contain databases. They carry a ``patch.json`` manifest
and application files under ``payload/``; the running process stages the
archive and writes a pending manifest for the launcher to apply on restart.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

from .config import APP_VERSION, local_root

MAX_PATCH_BYTES = 100 * 1024 * 1024
MAX_FILES = 2048
MAX_FILE_BYTES = 20 * 1024 * 1024


class PatchError(ValueError):
    pass


def _safe_relative(name: str) -> str:
    path = Path(str(name).replace("\\", "/"))
    if path.is_absolute() or ".." in path.parts or str(path) in ("", "."):
        raise PatchError(f"Недопустимый путь в патче: {name}")
    return path.as_posix()


def inspect_patch(path: str | Path) -> dict:
    archive = Path(path)
    if not archive.is_file() or archive.stat().st_size > MAX_PATCH_BYTES:
        raise PatchError("Патч отсутствует или превышает 100 МБ")
    try:
        with zipfile.ZipFile(archive, "r") as zf:
            infos = zf.infolist()
            if len(infos) > MAX_FILES:
                raise PatchError("В патче слишком много файлов")
            manifest_raw = zf.read("patch.json")
            manifest = json.loads(manifest_raw.decode("utf-8"))
            version = str(manifest.get("version", "")).strip()
            if not version:
                raise PatchError("В patch.json отсутствует version")
            files = []
            total = 0
            for info in infos:
                name = _safe_relative(info.filename)
                if name == "patch.json" or info.is_dir():
                    continue
                if not name.startswith("payload/"):
                    raise PatchError("Файлы патча должны находиться в payload/")
                if info.file_size > MAX_FILE_BYTES:
                    raise PatchError(f"Файл патча слишком большой: {name}")
                total += int(info.file_size)
                if total > MAX_PATCH_BYTES:
                    raise PatchError("Распакованный патч превышает 100 МБ")
                files.append(name)
            if not files:
                raise PatchError("Патч не содержит файлов payload/")
            return {"version": version, "title": str(manifest.get("title", "")),
                    "description": str(manifest.get("description", "")),
                    "files": files, "previous_version": str(manifest.get("previous_version", "")),
                    "source": str(archive)}
    except zipfile.BadZipFile as exc:
        raise PatchError("Файл патча повреждён или не является ZIP") from exc


def stage_patch(path: str | Path) -> dict:
    manifest = inspect_patch(path)
    target_root = local_root() / "updates" / manifest["version"]
    target_root.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="patch-", dir=str(target_root.parent)))
    try:
        with zipfile.ZipFile(path, "r") as zf:
            for name in manifest["files"]:
                destination = tmp / name.removeprefix("payload/")
                destination.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(name, "r") as src, destination.open("wb") as dst:
                    shutil.copyfileobj(src, dst, length=1024 * 1024)
        if target_root.exists():
            shutil.rmtree(target_root)
        os.replace(tmp, target_root)
    except Exception:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    manifest["staged_root"] = str(target_root)
    manifest["base_version"] = APP_VERSION
    pending = local_root() / "updates" / "pending_update.json"
    pending.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest

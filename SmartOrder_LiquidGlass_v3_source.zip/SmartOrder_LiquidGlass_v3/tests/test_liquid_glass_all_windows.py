"""Interaction coverage for real Qt controllers behind every glass surface."""
import json
from datetime import date
from decimal import Decimal

import pytest
from PyQt5 import sip
from PyQt5.QtCore import QDate, QEvent, QTimer, Qt
from PyQt5.QtWidgets import (QApplication, QDialog, QDialogButtonBox, QFileDialog,
    QLabel, QLineEdit, QMenu, QMessageBox, QPushButton, QTableWidget, QVBoxLayout)

from test_liquid_glass import app, system, glass, javascript, drain, populate
from smartorder import heavy_ui
from smartorder.analytics_ui import EmployeeAnalyticsDialog, FactUnitsDialog, ProductionAnalyticsDialog
from smartorder.glass_surface import SurfaceController, install_glass_surfaces
from smartorder.enterprise_ui import WorkshopDialog
from smartorder.live_ui import NotificationPopup
from smartorder.news_ui import NewsDialog
from smartorder.ui import FirstAdminDialog


@pytest.fixture(autouse=True)
def no_unattended_notifications(monkeypatch):
    monkeypatch.setattr(heavy_ui,"info",lambda *a,**k:None)
    def unexpected(*args,**kwargs):
        raise AssertionError("Unexpected controller message: " + str(args[1:]))
    monkeypatch.setattr(heavy_ui,"error",unexpected)
    monkeypatch.setattr(heavy_ui,"warn",unexpected)
    import sys,traceback
    errors=[]
    def exception_hook(cls,value,tb):
        traceback.print_exception(cls,value,tb)
        errors.append(value)
    monkeypatch.setattr(sys,"excepthook",exception_hook)
    yield
    assert not errors


def js(app, dialog, expression):
    result = []
    dialog._glass_surface.view.page().runJavaScript(expression, result.append)
    drain(app, lambda: bool(result), timeout=10)
    return result[0]


def handle(controller, widget):
    return controller._ids[widget]


def act(controller, op, widget=None, **data):
    controller.execute(dict(op=op, **({"id": handle(controller, widget)} if widget is not None else {}), **data))


def walk(node):
    if not node:return
    yield node
    for child in node.get("children", []):yield from walk(child)
    if node.get("child"):yield from walk(node["child"])
    for row in node.get("rows", []):
        for cell in row.get("cells", []):
            if cell.get("widget"):yield from walk(cell["widget"])


@pytest.fixture
def dialogs(app, glass):
    opened=[]
    def show(dialog):
        opened.append(dialog);dialog.show()
        drain(app, lambda: getattr(dialog,"_glass_surface",None) is not None and dialog._glass_surface.controller.ready,timeout=15)
        return dialog,dialog._glass_surface.controller
    yield show
    for dialog in reversed(opened):
        if sip.isdeleted(dialog):continue
        dialog.close();dialog.deleteLater()
    app.sendPostedEvents(None,QEvent.DeferredDelete);app.processEvents()


@pytest.mark.parametrize("index",[1,2,3,4,5])
def test_all_main_tabs_stay_in_chromium_with_original_widgets(glass,app,index):
    w,_,_=glass
    w.tabs.setCurrentIndex(index)
    drain(app,lambda: not getattr(w,"_building_tab",False))
    w._publish_glass_state(True)
    drain(app,lambda: javascript(app,w,'!document.getElementById("section-surface").hidden'))
    assert w._glass_stack.currentWidget() is w._glass
    assert javascript(app,w,'document.querySelector("#tabs .active").dataset.tab')==str(index)
    assert javascript(app,w,'document.querySelector(".orders-top").hidden')
    assert javascript(app,w,'document.getElementById("section-surface").childElementCount')==1
    assert w.glass_state()["section"]


def test_catalog_form_real_input_button_selection_and_update(glass,app):
    w,_,_=glass;w.tabs.setCurrentIndex(1);w._publish_glass_state(True)
    controller=w._section_surface
    for widget,value in ((w.work_name,"Упаковка тест"),(w.work_code,"UI-1"),(w.work_price,"12.50")):
        token=handle(controller,widget)
        javascript(app,w,f'''(()=>{{const e=document.querySelector('[data-ui="{token}"] input');e.value={json.dumps(value)};e.dispatchEvent(new Event("input",{{bubbles:true}}));}})()''')
    drain(app,lambda:w.work_name.text()=="Упаковка тест" and w.work_price.text()=="12.50")
    add=next(b for b in w.tabs.currentWidget().findChildren(QPushButton) if b.text()=="Добавить")
    act(controller,"click",add)
    drain(app,lambda:w.work_table.rowCount()==1)
    w._publish_glass_state(True)
    drain(app,lambda:javascript(app,w,'document.querySelectorAll("#section-surface tbody tr[data-row]").length')==1)
    javascript(app,w,'document.querySelector("#section-surface tbody tr[data-row] td").click()')
    drain(app,lambda:w.work_table.currentRow()==0 and w.work_edit_btn.isEnabled())
    assert w.work_table.item(0,0).data(Qt.UserRole) is not None
    act(controller,"click",w.work_edit_btn)
    assert w.work_save_btn.isEnabled()
    act(controller,"input",w.work_name,value="Изменено визуальным вводом")
    act(controller,"click",w.work_save_btn)
    assert w.db.get_active_work_types()[0][1]=="Изменено визуальным вводом"


def test_people_modes_call_existing_radio_handlers(glass,app):
    w,_,_=glass;w.tabs.setCurrentIndex(2);w._publish_glass_state(True);c=w._section_surface
    radios=[n for n in walk(w.glass_state()["section"]) if n["kind"]=="check" and n.get("radio")]
    assert len(radios)==3
    for label,mode in (("Мастера","master"),("Подразделения","department"),("Работники","worker")):
        node=next(n for n in radios if n["text"]==label)
        c.execute({"op":"click","id":node["id"]})
        assert w._people_mode()==mode


@pytest.mark.parametrize("factory",[
    lambda w:heavy_ui.LoginDialog(w.workshop_manager.auth),
    lambda w:FirstAdminDialog(w.workshop_manager.auth),
    lambda w:heavy_ui.WorkOrderDialog(w.db,w.user,parent=w),
    lambda w:heavy_ui.HeavyUserDialog(parent=w),
    lambda w:heavy_ui.EmployeeSelectionDialog(w.db,w),
    lambda w:heavy_ui.WorkSelectionDialog(w.db,w),
    lambda w:heavy_ui.DateRangeDialog(QDate(2026,10,1),QDate(2026,10,20),w),
    lambda w:heavy_ui.ArchiveSnapshotsDialog(w.db,w),
    lambda w:heavy_ui.DiagnosticsCenterDialog(w),
    lambda w:WorkshopDialog(w),
    lambda w:NotificationPopup(w),
    lambda w:NewsDialog(w,w.workshop_manager.root/"UPDATE_NEWS.txt"),
])
def test_application_dialogs_use_same_glass_renderer(glass,app,dialogs,factory):
    w,_,_=glass;dialog,c=dialogs(factory(w))
    assert js(app,dialog,'document.getElementById("dialog-surface").childElementCount')==1
    assert js(app,dialog,'CSS.supports("backdrop-filter","blur(28px)")')
    assert js(app,dialog,'document.documentElement.dataset.theme')==w.ui_settings.theme
    assert "factory-glass.png" in js(app,dialog,'getComputedStyle(document.getElementById("app-shell")).backgroundImage')
    assert c.snapshot()


def test_glass_login_authenticates_using_original_scrypt_handler(glass,app,dialogs):
    w,manager,_=glass;dialog,c=dialogs(heavy_ui.LoginDialog(manager.auth))
    for widget,value in ((dialog.username_edit,"admin"),(dialog.password_edit,"password123")):
        act(c,"input",widget,value=value)
    assert "password123" not in json.dumps(c.state(),ensure_ascii=False)
    act(c,"return",dialog.password_edit)
    drain(app,lambda:dialog.result()==QDialog.Accepted)
    assert dialog.user.id==manager.auth.authenticate("admin","password123").id


def test_user_roles_checkboxes_and_original_dialog_result(glass,app,dialogs):
    w,_,_=glass;dialog,c=dialogs(heavy_ui.HeavyUserDialog(parent=w))
    snapshot=c.snapshot();node=next(n for n in walk(snapshot) if n["kind"]=="list")
    admin=next(row for row in node["rows"] if row["text"]=="Администратор")
    act(c,"list",dialog.role_list,key=admin["key"])
    assert "Администратор" in dialog.selected_roles()
    box=dialog.findChild(QDialogButtonBox)
    act(c,"click",box.button(QDialogButtonBox.Ok))
    assert dialog.result()==QDialog.Accepted


def test_picker_search_and_selection_keep_existing_employee_ids(glass,app,dialogs):
    w,_,_=glass;populate(app,glass)
    dialog,c=dialogs(heavy_ui.EmployeeSelectionDialog(w.db,w))
    act(c,"input",dialog.search,value="Иванов")
    snapshot=c.snapshot();listing=next(n for n in walk(snapshot) if n["kind"]=="list")
    assert len(listing["rows"])==1
    act(c,"list",dialog.list,key=listing["rows"][0]["key"])
    assert len(dialog.selected())==1 and "Иванов" in dialog.selected()[0][1]


def test_work_order_cells_use_original_fix_fact_flags_and_recalculation(glass,app,dialogs):
    w,_,_=glass;db,oid,*_=populate(app,glass)
    dialog,c=dialogs(heavy_ui.WorkOrderDialog(w.db,w.user,db.get_order(oid),parent=w))
    node=next(n for n in walk(c.snapshot()) if n["kind"]=="table")
    row=next(r for r in node["rows"] if not dialog._is_total(r["row"]))
    before=dialog.table.item(row["row"],5).text()
    act(c,"cell",dialog.table,key=row["key"],col=5,before=before,value="15")
    assert dialog._line_from_row(row["row"]).fixed_boxes==Decimal("15")
    assert dialog._line_from_row(row["row"]).fixed_total==Decimal("30")
    assert not dialog.table.item(row["row"],9).flags()&Qt.ItemIsEditable
    actual_before=dialog.table.item(row["row"],9).text()
    act(c,"cell",dialog.table,key=row["key"],col=9,before=actual_before,value="99")
    assert dialog.table.item(row["row"],9).text()==actual_before
    # A calculated cell cannot be edited by a forged WebChannel message.
    calculated=dialog.table.item(row["row"],7).text()
    act(c,"cell",dialog.table,key=row["key"],col=7,before=calculated,value="999")
    assert dialog.table.item(row["row"],7).text()==calculated


def test_work_order_view_mode_cannot_be_edited(glass,app,dialogs):
    w,_,_=glass;db,oid,*_=populate(app,glass)
    dialog,c=dialogs(heavy_ui.WorkOrderDialog(w.db,w.user,db.get_order(oid),view_only=True,parent=w))
    table=next(n for n in walk(c.snapshot()) if n["kind"]=="table")
    assert not any(cell["editable"] for row in table["rows"] for cell in row["cells"])


def test_range_calendar_uses_native_range_state(glass,app,dialogs):
    w,_,_=glass;dialog,c=dialogs(heavy_ui.DateRangeDialog(QDate(2026,10,1),QDate(2026,10,1),w))
    act(c,"calendar",dialog.calendar,value="2026-10-20")
    act(c,"calendar",dialog.calendar,value="2026-10-07")
    assert dialog.selected_range()==(QDate(2026,10,7),QDate(2026,10,20))
    act(c,"calendar",dialog.calendar,value="2026-02-30")
    assert dialog.selected_range()==(QDate(2026,10,7),QDate(2026,10,20))


def test_real_glass_combo_sends_existing_index(glass,app,dialogs):
    w,_,_=glass;dialog,c=dialogs(heavy_ui.WorkOrderDialog(w.db,w.user,parent=w));token=handle(c,dialog.shift)
    js(app,dialog,f'document.querySelector(\'[data-ui="{token}"] button\').click()')
    assert js(app,dialog,'getComputedStyle(document.querySelector(".surface-popover")).backdropFilter').startswith("blur")
    js(app,dialog,'document.querySelector(\'[data-option="1"]\').click()')
    drain(app,lambda:dialog.shift.currentIndex()==1)


def test_stale_row_after_in_place_refresh_cannot_select_another_entity(glass,app):
    w,_,_=glass;w.tabs.setCurrentIndex(1)
    w.work_table.setRowCount(1)
    from smartorder.heavy_ui import make_item
    w.work_table.setItem(0,0,make_item("Первый",101))
    c=w._section_surface;snapshot=c.snapshot(w.tabs.currentWidget());table=next(n for n in walk(snapshot) if n["kind"]=="table");old=table["rows"][0]["key"]
    w.work_table.setItem(0,0,make_item("Другой",202));w.work_table.clearSelection()
    act(c,"select",w.work_table,key=old,col=0)
    assert not w.work_table.selectedItems()


def test_hidden_tab_handles_are_revoked(glass,app):
    w,_,_=glass;w.tabs.setCurrentIndex(1);c=w._section_surface;w.glass_state();token=handle(c,w.work_name)
    w.tabs.setCurrentIndex(2);w.glass_state()
    c.execute({"op":"input","id":token,"value":"Не должно попасть в другую вкладку"})
    assert w.work_name.text()==""


def test_context_menu_returns_original_qaction_and_triggers_once(glass,app):
    w,_,_=glass;c=w._section_surface;manager=install_glass_surfaces(app);c.ready=True
    menu=QMenu(w);action=menu.addAction("Проверка");called=[];action.triggered.connect(lambda:called.append(True))
    def choose():
        record=manager._menu
        if record:manager.menu_result(c,record["session"],"a0")
    QTimer.singleShot(150,choose)
    from PyQt5.QtCore import QPoint
    chosen=manager.present_menu(menu,c,QPoint(30,40),blocking=True)
    assert chosen is action and called==[True]


def test_message_box_keeps_yes_no_return_codes(glass,app,dialogs):
    w,_,_=glass;box=QMessageBox(QMessageBox.Question,"Подтверждение","Продолжить?",QMessageBox.Yes|QMessageBox.No,w)
    box,c=dialogs(box);act(c,"click",box.button(QMessageBox.Yes))
    assert box.result()==QMessageBox.Yes


def test_cpp_owned_standard_buttons_keep_live_handles_and_accept_from_html(glass,app,dialogs):
    w,_,_=glass;dialog,c=dialogs(heavy_ui.HeavyUserDialog(parent=w))
    box=dialog.findChild(QDialogButtonBox);token=handle(c,box.button(QDialogButtonBox.Ok))
    c.snapshot();app.processEvents();c.snapshot()
    assert handle(c,box.button(QDialogButtonBox.Ok))==token
    js(app,dialog,f'document.querySelector(\'[data-ui="{token}"]\').click()')
    drain(app,lambda:dialog.result()==QDialog.Accepted)


def test_editor_html_changes_create_a_revision_through_original_save_path(glass,app):
    w,_,_=glass;db,oid,*_=populate(app,glass)
    w._glass_command("select",{"key":"order:"+str(oid)})
    state={"phase":0,"attempts":0,"errors":[]}
    timer=QTimer(w);timer.setInterval(60)
    def interact():
        state["attempts"]+=1
        dialog=next((d for d in w.findChildren(QDialog) if d.isVisible() and hasattr(d,"get_data") and hasattr(d,"table")),None)
        if state["attempts"]>250:
            state["errors"].append("Editor did not complete")
            timer.stop()
            if dialog:dialog.reject()
            return
        surface=getattr(dialog,"_glass_surface",None) if dialog else None
        if surface is None or not surface.controller.ready:return
        try:
            c=surface.controller
            if state["phase"]==0:
                table=next(n for n in walk(c.snapshot()) if n["kind"]=="table")
                row=next(r for r in table["rows"] if not dialog._is_total(r["row"]))
                state["row"]=row["row"];state["phase"]=1
                expression=f'''(()=>{{const input=document.querySelector('[data-ui="{table['id']}"] tr[data-row="{row['key']}"] td[data-col="5"] input');input.focus();input.value="15";input.dispatchEvent(new Event("change",{{bubbles:true}}));input.blur();}})()'''
                surface.view.page().runJavaScript(expression)
            elif state["phase"]==1 and dialog._line_from_row(state["row"]).fixed_total==Decimal(30):
                token=handle(c,dialog.button_box.button(QDialogButtonBox.Ok));state["phase"]=2
                surface.view.page().runJavaScript(f'document.querySelector(\'[data-ui="{token}"]\').click()')
        except Exception as exc:
            state["errors"].append(str(exc));timer.stop();dialog.reject()
    timer.timeout.connect(interact);timer.start()
    try:w._glass_command("edit",{"key":"order:"+str(oid)})
    finally:timer.stop()
    assert not state["errors"] and state["phase"]==2
    versions=db.list_orders()
    assert len(versions)==2
    latest=db.get_order(int(versions[0][0]))
    assert latest["lines"][0].fixed_total==Decimal(30)
    assert db.get_order(oid)["lines"][0].fixed_total==Decimal(20)


def test_button_requested_qmenu_is_glass_and_returns_its_original_action(glass,app,dialogs):
    w,_,_=glass;dialog,c=dialogs(heavy_ui.HeavyUserDialog(parent=w))
    manager=install_glass_surfaces(app);menu=QMenu(dialog);chosen_action=menu.addAction("Тест действия")
    def choose():
        record=manager._menu
        if record:manager.menu_result(c,record["session"],"a0")
    QTimer.singleShot(150,choose)
    from PyQt5.QtCore import QPoint
    assert menu.exec_(dialog.mapToGlobal(QPoint(20,40))) is chosen_action


def test_live_plain_text_news_does_not_turn_markup_into_html(glass,app,dialogs):
    w,_,_=glass;source=w.workshop_manager.root/"UPDATE_NEWS.txt"
    source.write_text("Изменения <b>буквальный текст</b>",encoding="utf-8")
    dialog,c=dialogs(NewsDialog(w,source))
    drain(app,lambda:dialog.last_text is not None)
    c.publish(True)
    drain(app,lambda:"<b>буквальный текст</b>" in js(app,dialog,'document.getElementById("dialog-surface").textContent'))
    assert js(app,dialog,'document.querySelectorAll("#dialog-surface b").length')==0


def test_untrusted_rich_text_is_formatted_without_scripts_images_or_arbitrary_links(glass):
    w,_,_=glass;c=SurfaceController(w)
    label=QLabel();safe=c.rich('<b>Текст</b><script>alert(1)</script><img src="file:///etc/passwd"><a href="javascript:alert(1)">Ссылка</a>',label)
    assert "<b>Текст</b>" in safe
    assert "script" not in safe and "img" not in safe and "javascript:" not in safe
    assert not c.dispatch('{"op":"__getattribute__"}')
    assert not c.dispatch('[]')


def test_native_file_dialog_is_not_replaced(glass,app):
    w,_,_=glass;dialog=QFileDialog(w);dialog.setOption(QFileDialog.DontUseNativeDialog,True);dialog.show();app.processEvents()
    assert getattr(dialog,"_glass_surface",None) is None
    dialog.close();dialog.deleteLater()


def test_analytics_charts_and_profiles_use_existing_report_and_interactions(glass,app,dialogs):
    w,_,_=glass;populate(app,glass);w.tabs.setCurrentIndex(4)
    drain(app,lambda:w.analytics is not None and w.analytics.report is not None,timeout=12)
    w._publish_glass_state(True);c=w._section_surface
    snapshot=w.glass_state()["section"];charts=[n for n in walk(snapshot) if n["kind"]=="chart"]
    assert len(charts)==5 and all(n["src"].startswith("data:image/png;base64,") for n in charts)
    drain(app,lambda:javascript(app,w,'Array.from(document.querySelectorAll("#section-surface .surface-chart img")).filter(i=>i.complete&&i.naturalWidth>0).length')==5,timeout=10)
    radar=w.analytics.radar;radar.anim.stop();radar._progress=1;c.snapshot(w.tabs.currentWidget())
    assert radar._hits
    axis,rect=radar._hits[0]
    act(c,"pointer",radar,kind="press",x=rect.center().x()/radar.width(),y=rect.center().y()/radar.height())
    assert radar.selected_axis==axis
    employee=w.analytics.report.employees[0]
    dialog,dc=dialogs(EmployeeAnalyticsDialog(w.analytics,employee))
    assert len(dialog.rows)==1 and dialog.scatter.values==[20]
    assert any(n["kind"]=="chart" for n in walk(dc.snapshot()))
    fact,fc=dialogs(FactUnitsDialog(w.analytics))
    assert any(cell.get("widget",{}).get("kind")=="combo" for n in walk(fc.snapshot()) if n["kind"]=="table" for r in n["rows"] for cell in r["cells"])


def test_snapshot_does_not_read_repositories(glass,app,monkeypatch):
    w,_,_=glass;w.tabs.setCurrentIndex(1);w._publish_glass_state(True)
    def fail(*a,**k):pytest.fail("Presentation read the database")
    monkeypatch.setattr(w.db,"get_work_types",fail);monkeypatch.setattr(w.db,"get_employees",fail)
    assert w._section_surface.snapshot(w.tabs.currentWidget())


@pytest.mark.parametrize("index",[1,2,3,4,5])
def test_other_sections_fit_small_window_at_two_hundred_percent(glass,app,index):
    w,_,_=glass;w.resize(680,620);w.zoom.setValue(200);w.tabs.setCurrentIndex(index)
    drain(app,lambda:not w._rc18_zoom_timer.isActive())
    w._publish_glass_state(True)
    assert javascript(app,w,'getComputedStyle(document.getElementById("workspace-scroll")).overflowY')=="auto"
    assert javascript(app,w,'document.querySelector(".window-controls").getBoundingClientRect().right<=innerWidth')
    expected="14px" if index==4 else "28px"
    drain(app,lambda:javascript(app,w,'getComputedStyle(document.getElementById("section-surface")).fontSize')==expected)

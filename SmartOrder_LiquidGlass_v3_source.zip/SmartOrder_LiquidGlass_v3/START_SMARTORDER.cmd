@echo off
setlocal
cd /d "%~dp0"
set "SMARTORDER_SOURCE_VENV=%LOCALAPPDATA%\SmartOrder\glass-preview-venv-py312"
set "SMARTORDER_SOURCE_PY=%SMARTORDER_SOURCE_VENV%\Scripts\python.exe"
if exist "%SMARTORDER_SOURCE_PY%" goto dependencies
py.exe -3.12 -m venv "%SMARTORDER_SOURCE_VENV%"
if errorlevel 1 goto failed
:dependencies
"%SMARTORDER_SOURCE_PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto failed
"%SMARTORDER_SOURCE_PY%" main.py %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo SmartOrder could not start. Python 3.12 x64 and the listed dependencies are required.
pause
exit /b 1

"""Open the real orders window against an isolated temporary database.

Run from the project root: python tools/preview_liquid_glass.py
No production databases or saved user preferences are accessed.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main():
    parser = argparse.ArgumentParser(description="Предпросмотр окна Smart Order Liquid Glass")
    parser.add_argument("--screenshot", type=Path)
    parser.add_argument("--pdf", type=Path, help="Снимок HTML-страницы через Chromium PDF renderer")
    parser.add_argument("--width", type=int, default=1727)
    parser.add_argument("--height", type=int, default=910)
    parser.add_argument("--zoom", type=int, default=100)
    parser.add_argument("--theme", choices=["light", "dark"], default="light")
    parser.add_argument("--tab", choices=["orders", "catalog", "employees", "admin", "analytics", "about"], default="orders")
    parser.add_argument("--dialog", choices=["login", "first-admin", "order", "view-order", "user", "employees", "works", "date", "archive", "diagnostics", "news", "workshop", "profile", "fact-units", "message"])
    parser.add_argument("--demo", action="store_true", help="Пример данных только во временной базе предпросмотра")
    parser.add_argument("--popup", choices=["master", "shift", "department", "workshop", "date"], help="Открыть стеклянную панель в снимке")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="SmartOrderGlass-") as folder:
        root = Path(folder)
        os.environ["LOCALAPPDATA"] = str(root / "local")
        os.environ["SMARTORDER_NETWORK_ROOT"] = str(root / "shared")
        from PyQt5.QtCore import QEvent, QTimer, Qt
        from PyQt5.QtWidgets import QApplication
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
        from smartorder.glass_ui import MainWindow
        from smartorder.config import SettingsStore, UiSettings
        from smartorder.db import Database
        from smartorder.workshops import WorkshopManager
        app = QApplication(sys.argv[:1])
        app.setStyle("Fusion")
        SettingsStore().save(UiSettings(args.theme, max(50, min(200, args.zoom))))
        db = Database(root / "shared" / "work_orders.db")
        db.create_first_admin("admin", "preview-only-password")
        manager = WorkshopManager(db, db.path.parent)
        user = manager.auth.authenticate("admin", "preview-only-password")
        if args.demo:
            from decimal import Decimal
            from smartorder.domain import OrderLine
            demo_db = manager.database("packaging", user)
            master = demo_db.add_employee(user, "Петров Андрей Сергеевич", True)
            department = demo_db.add_department(user, "Упаковка готовой продукции")
            work = demo_db.add_work_type(user, "Упаковка сыра в коробки", "УП-01", "12.50")
            people = ["Иванов Иван Иванович", "Смирнова Анна Викторовна", "Кузнецов Алексей Петрович"]
            lines = [OrderLine(demo_db.add_employee(user, name), name, work, "Упаковка сыра в коробки", "УП-01", Decimal("12.50"), Decimal(8), Decimal(20 + i * 5), Decimal(2)) for i, name in enumerate(people)]
            demo_db.save_order(user, __import__("datetime").date.today().strftime("%d-%m-%Y"), "Дневная", master, department, lines, "Пример для просмотра оформления")
        window = MainWindow(db, user, manager)
        if args.screenshot or args.pdf:
            window.resize(args.width, args.height)
            window.show()
        else:
            window.showMaximized()
        window.tabs.setCurrentIndex(["orders", "catalog", "employees", "admin", "analytics", "about"].index(args.tab))
        target = {"view": window._glass, "dialog": None}

        def open_dialog():
            from PyQt5.QtCore import QDate
            from PyQt5.QtWidgets import QMessageBox
            from smartorder import heavy_ui as h
            from smartorder.analytics_ui import EmployeeAnalyticsDialog, FactUnitsDialog
            from smartorder.enterprise_ui import WorkshopDialog
            from smartorder.news_ui import NewsDialog
            from smartorder.ui import FirstAdminDialog
            orders = window.db.list_orders()
            source = window.db.get_order(int(orders[0][0])) if orders else None
            factories = {
                "login": lambda: h.LoginDialog(manager.auth),
                "first-admin": lambda: FirstAdminDialog(manager.auth),
                "order": lambda: h.WorkOrderDialog(window.db, user, source, parent=window),
                "view-order": lambda: h.WorkOrderDialog(window.db, user, source, view_only=True, parent=window),
                "user": lambda: h.HeavyUserDialog(parent=window),
                "employees": lambda: h.EmployeeSelectionDialog(window.db, window),
                "works": lambda: h.WorkSelectionDialog(window.db, window),
                "date": lambda: h.DateRangeDialog(QDate.currentDate().addDays(-7), QDate.currentDate(), window),
                "archive": lambda: h.ArchiveSnapshotsDialog(window.db, window),
                "diagnostics": lambda: h.DiagnosticsCenterDialog(window),
                "news": lambda: NewsDialog(window, root / "shared" / "UPDATE_NEWS.txt"),
                "workshop": lambda: WorkshopDialog(window),
                "profile": lambda: EmployeeAnalyticsDialog(window.analytics, window.analytics.report.employees[0]),
                "fact-units": lambda: FactUnitsDialog(window.analytics),
                "message": lambda: QMessageBox(QMessageBox.Question, "Подтверждение", "Сохранить изменения наряда?", QMessageBox.Yes | QMessageBox.No, window),
            }
            dialog = factories[args.dialog]()
            target["dialog"] = dialog
            if args.pdf or args.screenshot:
                dialog.resize(args.width, args.height)
            dialog.show()
            return dialog

        if args.dialog in {"profile", "fact-units"}:
            window.tabs.setCurrentIndex(4)
        if args.screenshot or args.pdf or args.dialog:
            timer = QTimer(window)
            timer.setInterval(100)
            attempts = 0

            def capture():
                nonlocal attempts
                attempts += 1
                loaded = window._glass_ready and not window._orders_running
                if args.tab == "analytics" or args.dialog in {"profile", "fact-units"}:
                    loaded = loaded and window.analytics is not None and window.analytics.report is not None
                if loaded and args.dialog and target["dialog"] is None:
                    open_dialog()
                if loaded and target["dialog"] is not None:
                    surface = getattr(target["dialog"], "_glass_surface", None)
                    loaded = surface is not None and surface.controller.ready
                    if loaded:target["view"] = surface.view
                if loaded:
                    timer.stop()
                    if not args.pdf and not args.screenshot:
                        return

                    def save():
                        if args.pdf and not target.get("images_ready"):
                            target["image_checks"] = target.get("image_checks",0) + 1
                            def checked(ready):
                                if ready or target["image_checks"] >= 30:
                                    target["images_ready"] = True
                                    QTimer.singleShot(250,save)
                                else:QTimer.singleShot(100,save)
                            target["view"].page().runJavaScript("Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)",checked)
                            return
                        if args.pdf:
                            from PyQt5.QtCore import QMarginsF, QSizeF
                            from PyQt5.QtGui import QPageLayout, QPageSize
                            from PyQt5.QtWebEngineWidgets import QWebEngineSettings
                            target["view"].settings().setAttribute(QWebEngineSettings.PrintElementBackgrounds, True)
                            size = QPageSize(QSizeF(args.width * .75, args.height * .75), QPageSize.Point)
                            layout = QPageLayout(size, QPageLayout.Portrait, QMarginsF(0, 0, 0, 0), QPageLayout.Point)
                            def printed(data):
                                args.pdf.parent.mkdir(parents=True, exist_ok=True)
                                args.pdf.write_bytes(bytes(data))
                                print(str(args.pdf.resolve()), flush=True)
                                if target["dialog"] is not None:target["dialog"].close()
                                window._rc4_exit_confirmed = True
                                window.close()
                                app.quit()
                            target["view"].page().printToPdf(printed, layout)
                            return
                        args.screenshot.parent.mkdir(parents=True, exist_ok=True)
                        if not target["view"].grab().save(str(args.screenshot)):
                            raise RuntimeError("Не удалось сохранить снимок окна")
                        print(str(args.screenshot.resolve()), flush=True)
                        if target["dialog"] is not None:target["dialog"].close()
                        window._rc4_exit_confirmed = True
                        window.close()
                        app.quit()
                    def prepare_capture():
                        if args.popup:
                            identifier = {"date":"date", "workshop":"account"}.get(args.popup, args.popup + "-trigger")
                            target["view"].page().runJavaScript(
                                "document.getElementById('" + identifier + "').click()",
                                lambda _: QTimer.singleShot(250, save))
                        else:
                            save()
                    QTimer.singleShot(1000, prepare_capture)
                elif attempts > 150 or window._glass_error:
                    print("Окно не загрузилось", file=sys.stderr, flush=True)
                    app.exit(1)
            timer.timeout.connect(capture)
            timer.start()
        result = app.exec_()
        window._rc4_exit_confirmed = True
        window.close()
        window.deleteLater()
        app.sendPostedEvents(None, QEvent.DeferredDelete)
        app.processEvents()
        return result


if __name__ == "__main__":
    raise SystemExit(main())

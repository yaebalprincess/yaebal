"use strict";
(() => {
  const standalone = document.body.dataset.surface === "dialog";
  let bridge = null, popup = null, menuSession = null, toastTimer = 0, help = null, helpTimer = 0;
  const mounts = new WeakMap(), nodes = new Map();
  const element = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };
  function children(parent, desired) {
    desired = desired.filter(Boolean);
    for (let i = 0; i < desired.length; i++) if (parent.children[i] !== desired[i]) parent.insertBefore(desired[i], parent.children[i] || null);
    for (const child of Array.from(parent.children)) if (!desired.includes(child)) child.remove();
  }
  function send(op, data = {}) { if (bridge) bridge.dispatch(JSON.stringify(Object.assign({op}, data))); }
  function toast(text) {
    const target = document.getElementById("surface-toast") || document.getElementById("toast");
    if (!target) return;
    target.textContent = text; target.hidden = false; clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { target.hidden = true; }, 4500);
  }
  function setText(e, text) { text = String(text || ""); if (e.textContent !== text) e.textContent = text; }
  function rich(e, text) { if (e._html !== text) { e.innerHTML = text || ""; e._html = text; } }
  function inputValue(input, value) {
    if (document.activeElement !== input && input.value !== String(value === undefined ? "" : value)) input.value = value === undefined ? "" : value;
  }
  function build(n, cache) {
    if (!n) return null;
    nodes.set(n.id, n);
    let e = cache.get(n.id);
    if (!e || e.dataset.kind !== n.kind) {
      e = element(n.kind === "button" ? "button" : "div", "surface-node surface-" + n.kind);
      e.dataset.ui = n.id; e.dataset.kind = n.kind;
      cache.set(n.id, e);
    }
    e._node = n; e.title = n.tip || "";
    e.classList.toggle("surface-grow",!!n.grow);e.classList.toggle("surface-fill",!!n.fill);e.classList.toggle("surface-pulse",!!n.pulse);
    e.dataset.help=n.help||"";
    e.dataset.nativeName = n.name || "";
    if (n.enabled === false) e.setAttribute("aria-disabled", "true"); else e.removeAttribute("aria-disabled");
    if (n.grid) { e.style.gridRow = (n.grid[0] + 1) + " / span " + n.grid[2]; e.style.gridColumn = (n.grid[1] + 1) + " / span " + n.grid[3]; }
    else { e.style.gridRow = ""; e.style.gridColumn = ""; }
    const sub = node => build(node, cache);
    switch (n.kind) {
      case "button":
        setText(e, n.glyph ? "" : n.text); e.disabled = !n.enabled;
        e.classList.toggle("icon-button",!!n.glyph);
        if(n.glyph){
          e.setAttribute("aria-label",n.text);e.title=n.text;
          if(!e._glyph){
            const ns="http://www.w3.org/2000/svg",svg=document.createElementNS(ns,"svg"),path=document.createElementNS(ns,"path");svg.setAttribute("viewBox","0 0 24 24");
            path.setAttribute("d",n.glyph==="eye"?"M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z":"M6 6l12 12M18 6L6 18");svg.appendChild(path);
            if(n.glyph==="eye"){const circle=document.createElementNS(ns,"circle");circle.setAttribute("cx","12");circle.setAttribute("cy","12");circle.setAttribute("r","3");svg.appendChild(circle);}
            e._glyph=svg;e.appendChild(svg);
          }
        }
        e.classList.toggle("primary", !!n.primary); e.classList.toggle("danger", !!n.danger); e.classList.toggle("checked", !!n.checked);
        e.onclick = () => { const r=e.getBoundingClientRect(); send("click", {id:n.id,x:Math.round(r.left),y:Math.round(r.bottom)}); };
        break;
      case "label":
        e.style.color=n.color||"";
        e.classList.toggle("heading", !!n.heading); e.classList.toggle("muted", !!n.muted); e.classList.toggle("center", !!n.center);
        if (n.html) rich(e, n.html); else setText(e, n.text);
        break;
      case "rich": rich(e, n.html); break;
      case "image":
        if (!e._image) { e._image=element("img"); e._image.alt=""; e.appendChild(e._image); }
        if(e._image.src!==n.src)e._image.src=n.src;
        e._image.style.width=n.width+"px";e._image.style.height=n.height+"px";
        break;
      case "line": {
        if (!e._input) {
          e._input=element("input"); e._input.autocomplete="off";
          e._suffix=element("span","surface-suffix"); e.appendChild(e._input);e.appendChild(e._suffix);
        }
        const input=e._input; input.type=n.password?"password":"text"; input.placeholder=n.placeholder||"";
        input.readOnly=!!n.readonly;input.disabled=!n.enabled;input.maxLength=n.maxlength||32767;input.setAttribute("aria-label", n.placeholder||"Поле ввода");
        if(n.secret) { if(n.clear && e._lastClear===false)input.value="";e._lastClear=n.clear; }
        else inputValue(input,n.value);
        input.oninput=()=>send("input",{id:n.id,value:input.value});
        input.onchange=()=>send("finish",{id:n.id});
        input.onkeydown=event=>{if(event.key==="Enter"){event.preventDefault();send("return",{id:n.id});}};
        children(e._suffix,(n.suffix||[]).map(sub));e.classList.toggle("has-suffix",e._suffix.children.length>0);
        break;
      }
      case "number": {
        if(!e._input){e._input=element("input");e._input.type="number";e.appendChild(e._input);}
        const input=e._input;input.min=n.minimum;input.max=n.maximum;input.step=n.step;input.disabled=!n.enabled;input.readOnly=!!n.readonly;inputValue(input,n.value);
        input.onchange=()=>{const value=Number(input.value.replace(",","."));if(Number.isFinite(value)){send("number",{id:n.id,value});send("finish",{id:n.id});}};
        input.onkeydown=event=>{if(event.key==="Enter"){event.preventDefault();input.blur();send("return",{id:n.id});}};
        break;
      }
      case "text":
        if(!e._input){e._input=element("textarea");e._input.rows=7;e.appendChild(e._input);}
        e._input.disabled=!n.enabled;inputValue(e._input,n.value);e._input.oninput=()=>send("input",{id:n.id,value:e._input.value});
        break;
      case "check": {
        if(!e._label){e._label=element("label");e._input=element("input");e._caption=element("span");e._label.appendChild(e._input);e._label.appendChild(e._caption);e.appendChild(e._label);}
        e._input.type=n.radio?"radio":"checkbox";e._input.checked=!!n.checked;e._input.disabled=!n.enabled;
        setText(e._caption,n.text);e.classList.toggle("is-disabled",!n.enabled);
        e._input.onchange=()=>send("click",{id:n.id});break;
      }
      case "combo":case "date":case "range": {
        if(n.kind==="range")e.classList.add("surface-date");
        if(!e._button){e._button=element("button");e._caption=element("span","combo-text");e._arrow=element("span",n.kind==="combo"?"surface-arrow":"surface-date-symbol");e._button.appendChild(e._caption);e._button.appendChild(e._arrow);e.appendChild(e._button);}
        setText(e._caption,n.text);e._button.disabled=!n.enabled;e._button.setAttribute("aria-haspopup",n.kind==="combo"?"listbox":"dialog");
        e._button.setAttribute("aria-expanded", popup && popup.anchor===e._button?"true":"false");
        if(n.kind!=="combo")setText(e._arrow,"▦");
        e._button.onclick=()=>{if(popup&&popup.anchor===e._button)closePopup();else if(n.kind==="combo")openCombo(e._button,n);else openCalendar(e._button,n);};break;
      }
      case "table": renderTable(e,n,cache);break;
      case "list": renderList(e,n);break;
      case "tabs": {
        if(!e._tabs){e._tabs=element("nav","surface-subtabs");e._body=element("section");e.appendChild(e._tabs);e.appendChild(e._body);}
        const buttons=[];
        n.tabs.forEach((t,i)=>{let b=e._tabs.children[i];if(!b)b=element("button");setText(b,t.text);b.disabled=!t.enabled;b.classList.toggle("active",i===n.current);b.setAttribute("role","tab");b.setAttribute("aria-selected",String(i===n.current));b.onclick=()=>{closePopup();send("tab",{id:n.id,value:i});};buttons.push(b);});
        children(e._tabs,buttons);children(e._body,[sub(n.child)]);break;
      }
      case "calendar": renderInlineCalendar(e,n);break;
      case "chart": renderChart(e,n);break;
      case "progress":
        if(!e._bar){e._bar=element("progress");e._label=element("span");e.appendChild(e._bar);e.appendChild(e._label);}
        if(n.minimum===n.maximum)e._bar.removeAttribute("value");else{e._bar.max=n.maximum-n.minimum;e._bar.value=n.value-n.minimum;}
        setText(e._label,n.text);break;
      case "slider":
        if(!e._input){e._input=element("input");e._input.type="range";e.appendChild(e._input);}
        e._input.min=n.minimum;e._input.max=n.maximum;e._input.step=n.step;e._input.disabled=!n.enabled;inputValue(e._input,n.value);
        e._input.oninput=()=>send("number",{id:n.id,value:Number(e._input.value)});break;
      case "group":
        if(!e._heading){e._heading=element("h2");e._body=element("div");e.appendChild(e._heading);e.appendChild(e._body);}
        setText(e._heading,n.title);children(e._body,[sub(n.child)]);break;
      default:
        if(n.kind==="grid")e.style.gridTemplateColumns="repeat("+n.columns+",minmax(0,1fr))";
        children(e,n.child?[sub(n.child)]:(n.children||[]).map(sub));
    }
    return e;
  }
  function renderTable(e,n,cache) {
    if(!e._table){
      e._table=element("table");e._cols=element("colgroup");e._head=element("thead");e._body=element("tbody");
      e._table.appendChild(e._cols);e._table.appendChild(e._head);e._table.appendChild(e._body);e.appendChild(e._table);e._rows=new Map();
      e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label","Таблица данных");
    }
    const columnsKey=JSON.stringify(n.columns);
    if(e._columnsKey!==columnsKey){
      e._columnsKey=columnsKey;e._cols.textContent="";e._head.textContent="";const tr=element("tr");let width=0;
      for(const col of n.columns){const c=element("col");c.style.width=col.width+"px";e._cols.appendChild(c);const th=element("th");th.scope="col";th.textContent=col.text;th.title=col.text;tr.appendChild(th);width+=col.width;}
      e._head.appendChild(tr);e._table.style.minWidth=width+"px";
    }
    e.style.maxHeight=n.maxheight+"px";
    const desired=[],keep=new Set();
    for(const row of n.rows){
      let tr=e._rows.get(row.key);
      if(!tr){tr=element("tr");tr._cells=new Map();tr.dataset.row=row.key;e._rows.set(row.key,tr);}
      keep.add(row.key);tr._row=row;tr.setAttribute("aria-selected",String(!!row.selected));
      const cells=[];let skip=0;
      for(const cell of row.cells){
        if(skip>0){skip--;continue;}
        let td=tr._cells.get(cell.col);if(!td){td=element("td");tr._cells.set(cell.col,td);}
        td.dataset.col=cell.col;td.title=cell.tip||"";td.classList.toggle("danger",!!cell.danger);td.classList.toggle("cell-disabled",!cell.enabled);
        td.classList.toggle("numeric",/^[-+]?\d[\d\s.,%]*$/.test(cell.text));
        td.colSpan=cell.span||1;skip=td.colSpan-1;
        if(cell.widget){children(td,[build(cell.widget,cache)]);td._input=null;}
        else if(cell.editable&&cell.enabled&&n.enabled){
          if(!td._input){td.textContent="";td._input=element("input");td._input.type="text";td._input.inputMode="decimal";td.appendChild(td._input);}
          const input=td._input;inputValue(input,cell.text);input.setAttribute("aria-label",(n.columns.find(c=>c.col===cell.col)||{}).text||"Значение");
          if(document.activeElement!==input)input._before=cell.text;
          input.onfocus=()=>{input._before=cell.text;};
          input.onchange=()=>{if(input.value!==input._before){send("cell",{id:n.id,key:row.key,col:cell.col,before:input._before,value:input.value});input._before=input.value;}};
          input.onkeydown=event=>{if(event.key==="Enter"){event.preventDefault();input.blur();}if(event.key==="Escape"){event.stopPropagation();input.value=input._before;input.blur();}};
        } else {td._input=null;setText(td,cell.text);}
        cells.push(td);
      }
      children(tr,cells);desired.push(tr);
    }
    if(!desired.length){const tr=element("tr"),td=element("td","surface-empty");td.colSpan=Math.max(1,n.columns.length);td.textContent="Нет записей";tr.appendChild(td);desired.push(tr);}
    children(e._body,desired);
    for(const key of e._rows.keys())if(!keep.has(key))e._rows.delete(key);
    function select(row,col,event,op="select"){
      const selected=new Set(n.rows.filter(r=>r.selected).map(r=>r.key));
      if(n.multi&&(event.ctrlKey||event.metaKey)){if(selected.has(row.key))selected.delete(row.key);else selected.add(row.key);}
      else if(n.multi&&event.shiftKey&&e._anchor){
        const a=n.rows.findIndex(r=>r.key===e._anchor),b=n.rows.findIndex(r=>r.key===row.key);selected.clear();
        for(let i=Math.min(a,b);i<=Math.max(a,b);i++)if(n.rows[i])selected.add(n.rows[i].key);
      }else{selected.clear();selected.add(row.key);e._anchor=row.key;}
      for(const r of n.rows)r.selected=selected.has(r.key);
      for(const tr of e._rows.values())tr.setAttribute("aria-selected",String(selected.has(tr.dataset.row)));
      send(op,{id:n.id,key:row.key,col,keys:Array.from(selected),x:Math.round(event.clientX||0),y:Math.round(event.clientY||0)});
    }
    e.onclick=event=>{const owner=event.target.closest("[data-ui]");if(event.target.closest("button")||(owner&&owner!==e&&e.contains(owner)))return;const tr=event.target.closest("tr[data-row]"),td=event.target.closest("td[data-col]");if(tr&&td)select(tr._row,Number(td.dataset.col),event);};
    e.ondblclick=event=>{if(event.target.closest("input,button"))return;const tr=event.target.closest("tr[data-row]"),td=event.target.closest("td[data-col]");if(tr&&td)select(tr._row,Number(td.dataset.col),event,"double");};
    e.oncontextmenu=event=>{const tr=event.target.closest("tr[data-row]"),td=event.target.closest("td[data-col]");if(tr&&td&&n.context){event.preventDefault();select(tr._row,Number(td.dataset.col),event,"context");}};
    e.onkeydown=event=>{
      if(event.target.closest("input,button"))return;
      if(["ArrowUp","ArrowDown","Home","End"].includes(event.key)){
        event.preventDefault();const index=n.rows.findIndex(r=>r.selected);let next=event.key==="Home"?0:event.key==="End"?n.rows.length-1:index+(event.key==="ArrowDown"?1:-1);
        next=Math.max(0,Math.min(n.rows.length-1,next));if(n.rows[next]){select(n.rows[next],0,event);e._rows.get(n.rows[next].key).scrollIntoView({block:"nearest"});}
      }else if(event.key==="Enter"){const row=n.rows.find(r=>r.selected);if(row){event.preventDefault();select(row,0,event,"double");}}
    };
  }
  function renderList(e,n){
    e.style.maxHeight=n.maxheight+"px";
    if(!e._rows)e._rows=new Map();const desired=[];
    for(const row of n.rows){
      let b=e._rows.get(row.key);if(!b){b=element("button");b._check=element("span","list-check");b._text=element("span");b.appendChild(b._check);b.appendChild(b._text);e._rows.set(row.key,b);}
      b.dataset.row=row.key;b.disabled=!n.enabled||!row.enabled;b.setAttribute("aria-selected",String(!!row.selected));b.setAttribute("role",row.checkable?"checkbox":"option");
      b.setAttribute("aria-checked",String(!!row.checked));b._check.hidden=!row.checkable;setText(b._check,row.checked?"✓":"");setText(b._text,row.text);
      b.onclick=()=>send("list",{id:n.id,key:row.key});b.ondblclick=()=>send("list",{id:n.id,key:row.key,double:true});desired.push(b);
    }
    children(e,desired);
    const keep=new Set(n.rows.map(r=>r.key));for(const key of e._rows.keys())if(!keep.has(key))e._rows.delete(key);
  }
  function renderChart(e,n){
    if(!e._image){
      e._image=element("img");e._image.draggable=false;e.appendChild(e._image);
      if(typeof ResizeObserver!=="undefined"){
        e._observer=new ResizeObserver(()=>{const width=Math.round(e.clientWidth),height=280;if(width>=280&&width!==e._reportedWidth){e._reportedWidth=width;send("chart_size",{id:e._node.id,width,height});}});
        e._observer.observe(e);
      }
    }
    if(e._image.src!==n.src)e._image.src=n.src;e._image.alt=n.title;
    const pointer=(kind,event)=>{const r=e._image.getBoundingClientRect();send("pointer",{id:n.id,kind,x:(event.clientX-r.left)/Math.max(1,r.width),y:(event.clientY-r.top)/Math.max(1,r.height)});};
    e.onpointermove=event=>{const now=performance.now();if(now-(e._lastMove||0)>60){e._lastMove=now;pointer("move",event);}};
    e.onpointerdown=event=>{if(event.button===0)pointer("press",event);};e.onpointerleave=()=>send("pointer",{id:n.id,kind:"leave"});
  }
  const iso=date=>date.toISOString().slice(0,10);
  const dateOf=value=>new Date(value+"T00:00:00Z");
  function monthText(year,month){return new Date(Date.UTC(year,month-1,1)).toLocaleDateString("ru-RU",{month:"long",year:"numeric",timeZone:"UTC"});}
  function calendar(container, data, callbacks){
    container.textContent="";container.classList.add("surface-calendar");
    const heading=element("div","surface-calendar-heading"),prev=element("button"),label=element("strong"),next=element("button");
    prev.textContent="‹";next.textContent="›";label.textContent=monthText(data.year,data.month);prev.setAttribute("aria-label","Предыдущий месяц");next.setAttribute("aria-label","Следующий месяц");
    prev.onclick=()=>callbacks.month(-1);next.onclick=()=>callbacks.month(1);heading.appendChild(prev);heading.appendChild(label);heading.appendChild(next);container.appendChild(heading);
    const week=element("div","surface-calendar-week");for(const name of ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"]){const s=element("span");s.textContent=name;week.appendChild(s);}container.appendChild(week);
    const days=element("div","surface-calendar-days"),first=new Date(Date.UTC(data.year,data.month-1,1)),offset=(first.getUTCDay()+6)%7;
    for(let i=0;i<42;i++){
      const day=new Date(Date.UTC(data.year,data.month-1,1-offset+i)),value=iso(day),b=element("button");b.textContent=day.getUTCDate();b.dataset.date=value;
      b.disabled=data.enabled===false||(data.minimum&&value<data.minimum)||(data.maximum&&value>data.maximum);
      b.classList.toggle("outside",day.getUTCMonth()!==data.month-1);b.classList.toggle("selected",value===data.value||value===data.end);
      b.classList.toggle("between",!!(data.end&&value>data.value&&value<data.end));b.classList.toggle("today",value===data.today);b.setAttribute("aria-label",value);b.onclick=()=>callbacks.choose(value);
      b.onkeydown=event=>{let delta={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7}[event.key];if(delta){event.preventDefault();const d=dateOf(value);d.setUTCDate(d.getUTCDate()+delta);const target=days.querySelector('[data-date="'+iso(d)+'"]');if(target&&!target.disabled)target.focus();}};
      days.appendChild(b);
    }container.appendChild(days);
  }
  function renderInlineCalendar(e,n){
    const signature=JSON.stringify(n);if(e._signature===signature)return;e._signature=signature;
    calendar(e,Object.assign({},n,{value:n.start||n.value}),{
      month:delta=>{const d=new Date(Date.UTC(n.year,n.month-1+delta,1));send("month",{id:n.id,year:d.getUTCFullYear(),month:d.getUTCMonth()+1});},
      choose:value=>send("calendar",{id:n.id,value})
    });
  }
  function closePopup(notify=true){
    if(popup){if(popup.anchor)popup.anchor.setAttribute("aria-expanded","false");popup.box.remove();popup=null;}
    if(notify&&menuSession){const session=menuSession;menuSession=null;send("menu_dismiss",{session});}
  }
  function position(box,anchor,x,y){
    const r=anchor?anchor.getBoundingClientRect():{left:x,top:y,bottom:y,width:210};
    box.style.minWidth=Math.min(innerWidth-16,Math.max(210,r.width))+"px";
    const width=box.offsetWidth,height=box.offsetHeight;
    box.style.left=Math.max(8,Math.min(r.left,innerWidth-width-8))+"px";
    let top=r.bottom+6;if(top+height>innerHeight-8)top=Math.max(8,r.top-height-6);
    box.style.top=Math.max(8,Math.min(top,innerHeight-height-8))+"px";
  }
  function popupBox(anchor,cls=""){
    closePopup();const box=element("section","surface-popover "+cls);document.body.appendChild(box);popup={box,anchor};
    if(anchor)anchor.setAttribute("aria-expanded","true");return box;
  }
  function openCombo(anchor,n){
    const box=popupBox(anchor);box.setAttribute("role","listbox");box.setAttribute("aria-label",n.text||"Выбор значения");
    const search=element("input","surface-popup-search");search.placeholder="Поиск…";search.setAttribute("aria-label","Поиск в списке");search.hidden=n.options.length<9;box.appendChild(search);
    const body=element("div");box.appendChild(body);
    function fill(){
      body.textContent="";const needle=search.value.toLocaleLowerCase("ru-RU").replace(/ё/g,"е");
      n.options.forEach((option,index)=>{
        if(needle&&!option.text.toLocaleLowerCase("ru-RU").replace(/ё/g,"е").includes(needle))return;
        const b=element("button","surface-option"),check=element("span"),label=element("span");check.textContent=index===n.value?"✓":"";label.textContent=option.text;b.appendChild(check);b.appendChild(label);
        b.disabled=!option.enabled;b.setAttribute("role","option");b.setAttribute("aria-selected",String(index===n.value));b.dataset.option=index;
        b.onclick=()=>{send("combo",{id:n.id,value:index});closePopup();anchor.focus();};body.appendChild(b);
      });
      if(!body.children.length){const empty=element("div","surface-calendar-hint");empty.textContent="Ничего не найдено";body.appendChild(empty);}
      box.style.maxHeight=Math.max(150,Math.min(420,innerHeight-16))+"px";position(box,anchor);
    }
    search.oninput=fill;fill();
    box.onkeydown=event=>{
      const options=Array.from(body.querySelectorAll("button:not(:disabled)")),index=options.indexOf(document.activeElement);
      if(["ArrowDown","ArrowUp","Home","End"].includes(event.key)){
        event.preventDefault();const next=event.key==="Home"?0:event.key==="End"?options.length-1:index+(event.key==="ArrowDown"?1:-1);if(options.length)options[Math.max(0,Math.min(options.length-1,next))].focus();
      }else if(event.key==="Enter"&&document.activeElement===search&&options.length){event.preventDefault();options[0].click();}
    };
    if(!search.hidden)search.focus();else{const option=body.querySelector('[aria-selected="true"]')||body.querySelector("button:not(:disabled)");if(option)option.focus();}
  }
  function openCalendar(anchor,n){
    const box=popupBox(anchor,"surface-calendar");box.setAttribute("role","dialog");box.setAttribute("aria-label","Выбор даты");
    let start=n.value,end=n.end||n.value,waiting=false;const initial=dateOf(start);let year=initial.getUTCFullYear(),month=initial.getUTCMonth()+1;
    function draw(){
      calendar(box,{year,month,value:start,end:n.kind==="range"?end:"",today:n.today,minimum:n.minimum,maximum:n.maximum}, {
        month:delta=>{const d=new Date(Date.UTC(year,month-1+delta,1));year=d.getUTCFullYear();month=d.getUTCMonth()+1;draw();},
        choose:value=>{if(n.kind!=="range"){start=end=value;}else if(!waiting){start=end=value;waiting=true;}else{end=value;if(start>end){const t=start;start=end;end=t;}waiting=false;}draw();}
      });
      const hint=element("div","surface-calendar-hint");hint.textContent=n.kind==="range"?(waiting?"Выберите конец периода":"Выберите дату или начало периода"):"Выберите дату наряда";box.appendChild(hint);
      const footer=element("div","surface-calendar-footer"),cancel=element("button","surface-button"),apply=element("button","surface-button primary");cancel.textContent="Отмена";apply.textContent="Применить";
      cancel.onclick=()=>{closePopup();anchor.focus();};apply.onclick=()=>{send(n.kind==="range"?"range":"date",{id:n.id,value:start,end});closePopup();anchor.focus();};footer.appendChild(cancel);footer.appendChild(apply);box.appendChild(footer);position(box,anchor);
    }draw();
  }
  function showMenu(raw){
    const data=typeof raw==="string"?JSON.parse(raw):raw;
    closePopup(false);menuSession=null;if(!data)return;
    const box=popupBox(null,"surface-menu");menuSession=data.session;box.setAttribute("role","menu");
    function draw(rows){
      box.textContent="";
      for(const row of rows){
        if(row.separator){box.appendChild(element("hr"));continue;}
        const b=element("button","surface-option"),check=element("span"),text=element("span");check.textContent=row.checked?"✓":"";text.textContent=row.text+(row.children.length?" ›":"");b.appendChild(check);b.appendChild(text);b.disabled=!row.enabled;b.setAttribute("role","menuitem");
        b.onclick=()=>{if(row.children.length)draw(row.children);else{const session=menuSession;menuSession=null;closePopup(false);send("menu_select",{session,key:row.key});}};box.appendChild(b);
      }
      position(box,null,data.x,data.y);const first=box.querySelector("button:not(:disabled)");if(first)first.focus();
    }draw(data.rows);
    box.onkeydown=event=>{if(["ArrowDown","ArrowUp"].includes(event.key)){event.preventDefault();const buttons=Array.from(box.querySelectorAll("button:not(:disabled)")),index=buttons.indexOf(document.activeElement);if(buttons.length)buttons[(index+(event.key==="ArrowDown"?1:buttons.length-1))%buttons.length].focus();}};
  }
  function render(root,tree,zoom=100){
    if(!root)return;
    let cache=mounts.get(root);if(!cache){cache=new Map();mounts.set(root,cache);}
    nodes.clear();root.style.fontSize=(14*zoom/100)+"px";
    children(root,[build(tree,cache)]);
    if(tree&&root._lastTree!==tree.id){
      root._lastTree=tree.id;
      if(!window.matchMedia("(prefers-reduced-motion: reduce)").matches&&root.animate)root.animate([{opacity:.35,transform:"translateY(4px)"},{opacity:1,transform:"translateY(0)"}],{duration:170,easing:"cubic-bezier(.215,.61,.355,1)"});
    }
    for(const [id,e] of cache)if(!e.isConnected){if(e._observer)e._observer.disconnect();cache.delete(id);}
    if(popup&&popup.anchor&&!popup.anchor.isConnected)closePopup();
  }
  function bind(native){
    if(!native)return;bridge=native;
    native.message.connect(toast);native.menuChanged.connect(showMenu);
    native.focusRequested.connect(raw=>{
      const data=raw.startsWith("{")?JSON.parse(raw):{id:raw};const e=document.querySelector('[data-ui="'+data.id+'"]');
      if(e){const row=data.key&&e._rows?e._rows.get(data.key):null,cell=row&&row._cells?row._cells.get(data.col):null;
        const input=cell?cell.querySelector("input"):e.querySelector("input,textarea,button");if(input)input.focus();}
    });
    if(standalone)native.stateChanged.connect(raw=>{
      const state=JSON.parse(raw);document.documentElement.dataset.theme=state.theme;
      document.getElementById("surface-title").textContent=state.title;document.title=state.title;
      document.getElementById("surface-resize").hidden=!state.resizable;
      render(document.getElementById("dialog-surface"),state.tree,state.zoom);
    });
    send("ready");
  }
  document.addEventListener("click",event=>{
    const link=event.target.closest("[data-link]");if(link){event.preventDefault();const root=link.closest("[data-ui]");if(root)send("link",{id:root.dataset.ui,key:link.dataset.link});}
    const control=event.target.closest("[data-window]");if(control)send(control.dataset.window);
  });
  function hideHelp(){clearTimeout(helpTimer);if(help){help.remove();help=null;}}
  document.addEventListener("pointerover",event=>{
    const anchor=event.target.closest("[data-help]");
    if(!anchor||!anchor.dataset.help||anchor.contains(event.relatedTarget)||popup)return;
    hideHelp();helpTimer=setTimeout(()=>{help=element("aside","surface-popover surface-help");help.setAttribute("role","tooltip");help.textContent=anchor.dataset.help;document.body.appendChild(help);position(help,anchor);},350);
  });
  document.addEventListener("pointerout",event=>{const anchor=event.target.closest("[data-help]");if(anchor&&!anchor.contains(event.relatedTarget))hideHelp();});
  document.addEventListener("pointerdown",hideHelp,true);
  document.addEventListener("pointerdown",event=>{if(popup&&!popup.box.contains(event.target)&&(!popup.anchor||!popup.anchor.contains(event.target)))closePopup();},true);
  document.addEventListener("keydown",event=>{
    if(event.key==="Escape"&&popup){event.preventDefault();event.stopImmediatePropagation();const anchor=popup.anchor;closePopup();if(anchor)anchor.focus();return;}
    if(standalone&&event.key==="Escape"&&!event.defaultPrevented){event.preventDefault();event.stopImmediatePropagation();if(!event.repeat)send("escape");}
  });
  window.addEventListener("blur",()=>{hideHelp();closePopup();});window.addEventListener("resize",()=>{hideHelp();closePopup();});
  if(standalone){
    const titlebar=document.getElementById("surface-titlebar");
    titlebar.addEventListener("mousedown",event=>{if(event.button===0&&!event.target.closest("button")){event.preventDefault();send("move");}});
    document.getElementById("surface-resize").onmousedown=event=>{if(event.button===0)send("resize");};
    if(window.qt&&window.qt.webChannelTransport&&typeof QWebChannel!=="undefined")new QWebChannel(window.qt.webChannelTransport,channel=>bind(channel.objects.surface));
  }
  window.GlassSurface=Object.freeze({render,bind,closePopup});
})();

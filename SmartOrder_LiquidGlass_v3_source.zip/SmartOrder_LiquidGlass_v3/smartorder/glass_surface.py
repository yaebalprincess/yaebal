"""Liquid Glass presentation for existing Qt pages and application dialogs.

Qt widgets remain the controllers: no calculations, repositories, permissions,
save paths, locks or dialog results are implemented in JavaScript. A surface
only exposes widgets in its current layout, by temporary opaque handles.
"""
from __future__ import annotations

import hashlib
import html
import json
import logging
import math
import re
import weakref
from html.parser import HTMLParser

from PyQt5 import sip
from PyQt5.QtCore import (QBuffer, QDate, QEvent, QEventLoop, QIODevice,
                          QItemSelectionModel, QModelIndex, QObject, QPoint,
                          QPointF, QPersistentModelIndex, Qt, QTimer, QUrl,
                          pyqtSignal, pyqtSlot)
from PyQt5.QtGui import (QColor, QDesktopServices, QImage, QKeyEvent,
                         QMouseEvent, QPainter, QValidator)
from PyQt5.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication,
    QCalendarWidget, QCheckBox, QComboBox, QDateTimeEdit, QDialog,
    QDialogButtonBox, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame,
    QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QMenu, QMessageBox, QProgressBar, QRadioButton, QScrollArea, QSlider,
    QSpinBox, QSplitter, QStackedWidget, QTabWidget, QTableView,
    QTableWidget, QTextBrowser, QTextEdit, QToolButton, QWidget)
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtWebEngineWidgets import QWebEnginePage, QWebEngineProfile, QWebEngineView

log = logging.getLogger(__name__)


def alive(obj):
    return obj is not None and not sip.isdeleted(obj)


def png(pixmap):
    data = QBuffer()
    data.open(QIODevice.WriteOnly)
    pixmap.save(data, "PNG")
    return "data:image/png;base64," + bytes(data.data().toBase64()).decode("ascii")


class SafeRichText(HTMLParser):
    """Retain document formatting without transferring executable HTML/URLs."""
    tags = frozenset({"p", "div", "span", "b", "strong", "i", "em", "u", "br",
                      "h1", "h2", "h3", "h4", "ul", "ol", "li", "table",
                      "tbody", "tr", "td", "th", "pre", "hr", "a", "sub", "sup"})

    def __init__(self, links):
        super().__init__(convert_charrefs=True)
        self.parts, self.links, self.suppressed = [], links, 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "head"}:
            self.suppressed += 1
        if self.suppressed or tag not in self.tags:
            return
        attrs = dict(attrs)
        extra = ""
        if tag == "a":
            url = str(attrs.get("href", ""))
            if QUrl(url).scheme().lower() in {"https", "http", "mailto", "tel", ""}:
                token = hashlib.sha256(url.encode()).hexdigest()[:24]
                self.links[token] = url
                extra = ' href="#" data-link="' + token + '"'
        styles = []
        for declaration in attrs.get("style", "").split(";"):
            key, _, value = declaration.partition(":")
            key, value = key.strip().lower(), value.strip().lower()
            if ((key == "font-weight" and value in {"bold", "600", "700", "800", "900"})
                or (key == "font-style" and value == "italic")
                or (key == "text-decoration" and value == "underline")
                or (key == "text-align" and value in {"left", "right", "center"})):
                styles.append(key + ":" + value)
        classes = []
        for style in styles:
            key, value = style.split(":", 1)
            classes.append("rt-" + ("bold" if key == "font-weight" else "italic" if key == "font-style" else "underline" if key == "text-decoration" else value))
        if classes:
            extra += ' class="' + " ".join(classes) + '"'
        self.parts.append("<" + tag + extra + ">")

    def handle_endtag(self, tag):
        if tag in {"script", "style", "head"}:
            self.suppressed = max(0, self.suppressed - 1)
            return
        if not self.suppressed and tag in self.tags and tag not in {"br", "hr"}:
            self.parts.append("</" + tag + ">")

    def handle_data(self, data):
        if not self.suppressed:
            self.parts.append(html.escape(data))


class SurfaceController(QObject):
    stateChanged = pyqtSignal(str)
    message = pyqtSignal(str)
    focusRequested = pyqtSignal(str)
    menuChanged = pyqtSignal(str)

    def __init__(self, root, parent=None, standalone=False):
        super().__init__(parent or root)
        self.root, self.standalone, self.view = root, standalone, None
        self.ready = False
        self._counter = 0
        self._ids = weakref.WeakKeyDictionary()
        self._objects, self._active = {}, set()
        self._rows, self._row_ids = {}, {}
        # C++-owned Qt models can receive a new Python wrapper on the next
        # model() call. Retain that wrapper so signal revisions remain stable.
        self._models = {}
        self._table_cache = weakref.WeakKeyDictionary()
        self._links, self._chart_cache, self._chart_sizes = {}, {}, {}
        self._last, self._busy = "", False
        self._focus = None
        self._secrets = weakref.WeakSet()
        self.timer = QTimer(self)
        self.timer.setInterval(140)
        self.timer.timeout.connect(self.publish)

    def handle(self, obj):
        token = self._ids.get(obj)
        if token is None:
            self._counter += 1
            token = "w" + str(self._counter)
            self._ids[obj] = token
            # Standard dialog buttons/layouts are created inside C++. Keep
            # their Python wrappers alive; weakrefs alone expire between
            # snapshotting and a subsequent WebChannel click.
            self._objects[token] = obj
            if isinstance(obj, QWidget):
                obj.installEventFilter(self)
        self._active.add(token)
        return token

    def object(self, token):
        obj = self._objects.get(token) if isinstance(token, str) and token in self._active else None
        return obj if alive(obj) else None

    def theme_zoom(self):
        node, analytics = self.root, False
        while node is not None:
            analytics |= type(node).__module__.endswith("analytics_ui")
            settings = getattr(node, "ui_settings", None)
            if settings is not None:
                return settings.theme, 100 if analytics else settings.zoom
            node = node.parent() if isinstance(node, QObject) else None
        from .config import SettingsStore
        settings = SettingsStore().load()
        return settings.theme, settings.zoom

    def snapshot(self, root=None):
        root = root or self.root
        self._active = set()
        self._links = {}
        result = self.node(root, force=True)
        # Prune deleted/stale references. Persistent indexes follow row moves
        # and become invalid on removals/resets; an old click cannot target a
        # different employee/order after a background model refresh.
        self._rows = {k: v for k, v in self._rows.items()
                      if alive(v[0]()) and v[1].isValid()
                      and self.row_identity(v[0](), v[1].row()) == v[2]}
        self._row_ids = {k: v for k, v in self._row_ids.items() if v in self._rows}
        self._objects = {k: v for k, v in self._objects.items() if alive(v)}
        self._models = {model: revision for model, revision in self._models.items() if alive(model)}
        return result

    def state(self):
        theme, zoom = self.theme_zoom()
        return {"title": self.root.windowTitle() or "Smart Order", "theme": theme,
                "zoom": zoom, "tree": self.snapshot(),
                "maximized": self.root.isMaximized(),
                "resizable": self.root.minimumSize() != self.root.maximumSize()}

    def publish(self, force=False):
        if not self.ready or not alive(self.root) or not self.root.isVisible():
            return
        try:
            encoded = json.dumps(self.state(), ensure_ascii=False, separators=(",", ":"))
            if force or encoded != self._last:
                self._last = encoded
                self.stateChanged.emit(encoded)
        except RuntimeError:
            if alive(self.root):
                log.exception("Unable to snapshot glass surface")

    def eventFilter(self, obj, event):
        if event.type() == QEvent.FocusIn and self.view is not None and obj is not self.view:
            if isinstance(obj, (QLineEdit, QTextEdit, QAbstractItemView)):
                token = self._ids.get(obj)
                if token in self._active:
                    def focus_web(t=token):
                        if alive(self.root) and alive(self.view) and self.ready and t in self._active:
                            self.view.setFocus()
                            self.focusRequested.emit(t)
                    QTimer.singleShot(0,focus_web)
        return False

    def rich(self, text, widget):
        links = {}
        parser = SafeRichText(links)
        parser.feed(str(text))
        for token, url in links.items():
            self._links[(self.handle(widget), token)] = url
        return "".join(parser.parts)

    def node(self, w, force=False):
        if not alive(w) or (w.isHidden() and not force):
            return None
        if w.objectName().startswith("LiquidGlass"):
            return None
        n = {"id": self.handle(w), "enabled": w.isEnabled(),
             "name": w.objectName(), "tip": w.toolTip()}
        for child in w.children():
            if type(child).__name__ == "_RC5InfoHoverFilter":
                n["help"] = str(child.provider() if callable(child.provider) else child.provider)
        n["pulse"] = w.objectName() == "EditModeBanner" or (isinstance(w,QLabel) and w.text()=="?" and bool(n.get("help")))
        if isinstance(w,QLabel) and (w.objectName().startswith(("AdminDb","DbState")) or w.text().startswith("● LIVE")):
            color=re.search(r"(?:^|[;{])\s*color\s*:\s*(#[0-9a-fA-F]{6})",w.styleSheet())
            if color:n["color"]=color.group(1)
        if isinstance(w, QCalendarWidget):
            n.update(kind="calendar", year=w.yearShown(), month=w.monthShown(),
                     today=QDate.currentDate().toString("yyyy-MM-dd"),
                     value=w.selectedDate().toString("yyyy-MM-dd"),
                     minimum=w.minimumDate().toString("yyyy-MM-dd"),
                     maximum=w.maximumDate().toString("yyyy-MM-dd"))
            parent = w.parentWidget()
            if hasattr(parent, "selected_range"):
                start, end = parent.selected_range()
                n.update(start=start.toString("yyyy-MM-dd"), end=end.toString("yyyy-MM-dd"))
        elif isinstance(w, QTabWidget):
            n.update(kind="tabs", current=w.currentIndex(),
                     tabs=[{"text": w.tabText(i), "enabled": w.isTabEnabled(i)} for i in range(w.count())],
                     child=self.node(w.currentWidget(), force=True))
        elif isinstance(w, QScrollArea):
            n.update(kind="scroll", child=self.node(w.widget(), force=True))
        elif isinstance(w, QSplitter):
            n.update(kind="row" if w.orientation() == Qt.Horizontal else "column",
                     children=[self.node(w.widget(i)) for i in range(w.count())])
        elif isinstance(w, QStackedWidget):
            n.update(kind="column", children=[self.node(w.currentWidget(), force=True)])
        elif isinstance(w, QComboBox):
            n.update(kind="combo", value=w.currentIndex(), text=w.currentText(), editable=w.isEditable(),
                     options=[{"text": w.itemText(i), "enabled": bool(w.model().flags(w.model().index(i, w.modelColumn())) & Qt.ItemIsEnabled)} for i in range(w.count())])
        elif isinstance(w, QDateTimeEdit):
            n.update(kind="date", value=w.date().toString("yyyy-MM-dd"), text=w.text(),
                     today=QDate.currentDate().toString("yyyy-MM-dd"),
                     minimum=w.minimumDate().toString("yyyy-MM-dd"), maximum=w.maximumDate().toString("yyyy-MM-dd"))
        elif isinstance(w, QLineEdit):
            if hasattr(w, "startDate") and hasattr(w, "setDateRange"):
                n.update(kind="range", text=w.text(), value=w.startDate().toString("yyyy-MM-dd"),
                         today=QDate.currentDate().toString("yyyy-MM-dd"),
                         end=w.endDate().toString("yyyy-MM-dd"))
            else:
                password = w.echoMode() in (QLineEdit.Password, QLineEdit.PasswordEchoOnEdit, QLineEdit.NoEcho)
                if password:self._secrets.add(w)
                n.update(kind="line", placeholder=w.placeholderText(), readonly=w.isReadOnly(),
                         password=password, secret=w in self._secrets, maxlength=w.maxLength(), clear=not bool(w.text()))
                # Never include a password in a snapshot or a log.
                if w not in self._secrets:
                    n["value"] = w.text()
                n["suffix"] = [self.node(b) for b in w.findChildren(QToolButton, options=Qt.FindDirectChildrenOnly) if not b.isHidden()]
        elif isinstance(w, (QSpinBox, QDoubleSpinBox)):
            n.update(kind="number", value=w.value(), minimum=w.minimum(), maximum=w.maximum(),
                     step=w.singleStep(), decimals=w.decimals() if isinstance(w, QDoubleSpinBox) else 0,
                     readonly=w.isReadOnly())
        elif isinstance(w, (QCheckBox, QRadioButton)):
            n.update(kind="check", text=w.text().replace("&", ""), checked=w.isChecked(), radio=isinstance(w, QRadioButton))
        elif isinstance(w, QAbstractButton):
            text = w.text().replace("&", "")
            if not text:
                text = w.accessibleName() or w.toolTip() or {"eye": "Показать пароль", "clear": "Очистить"}.get(getattr(w, "kind", ""), "⋯")
            n.update(kind="button", text=text, checked=w.isChecked(), checkable=w.isCheckable(),
                     glyph=getattr(w,"kind","") if type(w).__name__=="_RC16GlyphButton" else "",
                     primary="primary" in w.objectName().lower() or (
                         isinstance(w.parentWidget(),QDialogButtonBox) and w.parentWidget().buttonRole(w) in {
                             QDialogButtonBox.AcceptRole,QDialogButtonBox.YesRole,QDialogButtonBox.ApplyRole}),
                     danger="danger" in w.objectName().lower() or "delete" in w.objectName().lower())
            if isinstance(w, QToolButton) and w.menu():
                n["menu"] = True
        elif isinstance(w, QTableView):
            n.update(self.table(w))
        elif isinstance(w, QListWidget):
            n.update(kind="list", rows=[], maxheight=min(440,w.maximumHeight()))
            for row in range(w.count()):
                item, index = w.item(row), w.model().index(row, 0)
                if item.isHidden():
                    continue
                n["rows"].append({"key": self.row_handle(w, index), "text": item.text(),
                                  "checked": item.checkState() == Qt.Checked,
                                  "checkable": bool(item.flags() & Qt.ItemIsUserCheckable),
                                  "enabled": bool(item.flags() & Qt.ItemIsEnabled),
                                  "selected": item.isSelected()})
        elif isinstance(w, QTextEdit):
            n.update(kind="rich" if w.isReadOnly() else "text", readonly=w.isReadOnly(),
                     value=w.toPlainText(), html=self.rich(w.toHtml(), w) if w.isReadOnly() else "")
        elif isinstance(w, QLabel):
            pixmap = w.pixmap()
            movie = w.movie()
            if movie is not None:
                pixmap = movie.currentPixmap()
            if pixmap is not None and not pixmap.isNull():
                n.update(kind="image", src=png(pixmap), width=min(160, pixmap.width()), height=min(100, pixmap.height()))
            else:
                text = w.text()
                rich = w.textFormat() == Qt.RichText or (w.textFormat() == Qt.AutoText and "<" in text and ">" in text)
                n.update(kind="label", text=text, html=self.rich(text, w) if rich else "",
                         heading=("Title" in w.objectName() or "title" in w.objectName().lower() or w.font().pixelSize() >= 22 or w.font().pointSize() >= 18),
                         muted="Muted" in w.objectName(), center=bool(w.alignment() & Qt.AlignHCenter))
        elif isinstance(w, QProgressBar):
            n.update(kind="progress", value=w.value(), minimum=w.minimum(), maximum=w.maximum(), text=w.text())
        elif isinstance(w, QSlider):
            n.update(kind="slider", value=w.value(), minimum=w.minimum(), maximum=w.maximum(), step=w.singleStep())
        elif type(w).__name__ in {"AnimatedChart", "_DiagnosticsGraph"}:
            n.update(self.chart(w, n["id"]))
        elif isinstance(w, QDialogButtonBox):
            n.update(kind="buttons", children=[self.node(b) for b in w.buttons()])
        elif isinstance(w, QGroupBox):
            n.update(kind="group", title=w.title(), child=self.layout(w.layout()))
        elif hasattr(w, "_widgets") and hasattr(w, "_max_columns"):
            n.update(kind="responsive", columns=w._max_columns, cell=w._min_cell_width,
                     children=[self.node(c) for c in w._widgets])
        elif w.layout() is not None:
            n.update(kind="card" if w.objectName() in {"DiagCard", "MetricCard", "NotificationCard", "AboutTransparentCard", "EditModeBanner"} else "container",
                     child=self.layout(w.layout()))
        else:
            children = [c for c in w.findChildren(QWidget, options=Qt.FindDirectChildrenOnly)
                        if not c.objectName().startswith("LiquidGlass") and not c.isWindow()
                        and (c.layout() is not None or isinstance(c, (QLabel, QAbstractButton,QProgressBar,
                            QLineEdit,QComboBox,QTextEdit,QAbstractItemView,QSlider)))]
            n.update(kind="column", children=[self.node(c) for c in children])
        if n["kind"] in {"container","scroll","group"}:
            n["fill"] = bool(n.get("child") and n["child"].get("fill"))
        return n

    def layout(self, layout):
        if layout is None:
            return None
        n = {"id": self.handle(layout), "kind": "column", "children": []}
        def item_node(item):
            if item is None:
                return None
            if item.widget() is not None:
                return self.node(item.widget())
            if item.layout() is not None:
                return self.layout(item.layout())
            return None  # native stretches do not add empty cards in HTML
        if isinstance(layout, QFormLayout):
            n["kind"] = "form"
            for row in range(layout.rowCount()):
                label = item_node(layout.itemAt(row, QFormLayout.LabelRole))
                field = item_node(layout.itemAt(row, QFormLayout.FieldRole))
                spanning = item_node(layout.itemAt(row, QFormLayout.SpanningRole))
                if label or field or spanning:
                    n["children"].append({"id": n["id"] + "f" + str(row), "kind": "field", "children": [label, field] if label else [field or spanning]})
        elif isinstance(layout, QGridLayout):
            n.update(kind="grid", columns=min(12, max(1, layout.columnCount())))
            for i in range(layout.count()):
                child = item_node(layout.itemAt(i))
                if child:
                    r, c, rs, cs = layout.getItemPosition(i)
                    child = dict(child, grid=[r, c, rs, cs])
                    n["children"].append(child)
        else:
            n["kind"] = "row" if isinstance(layout, QHBoxLayout) else "column"
            for i in range(layout.count()):
                child = item_node(layout.itemAt(i))
                if child:
                    if layout.stretch(i)>0:child=dict(child,grow=True)
                    n["children"].append(child)
        n["children"] = [c for c in n["children"] if c is not None]
        if n["kind"] == "row":
            paired=[];i=0
            while i<len(n["children"]):
                first=n["children"][i]
                if (first["kind"]=="label" and i+1<len(n["children"])
                    and n["children"][i+1]["kind"] in {"line","combo","date","range","number","slider"}):
                    paired.append({"id":n["id"]+"p"+str(i),"kind":"field","children":[first,n["children"][i+1]]})
                    i+=2
                else:paired.append(first);i+=1
            n["children"]=paired
        n["fill"] = n["kind"] == "column" and any(c.get("grow") or c.get("fill") for c in n["children"])
        return n

    def row_handle(self, view, index):
        persistent = QPersistentModelIndex(index.sibling(index.row(), 0))
        identity = self.row_identity(view, index.row())
        key = (self.handle(view), persistent, identity)
        token = self._row_ids.get(key)
        if token is None:
            self._counter += 1
            token = "r" + str(self._counter)
            self._row_ids[key] = token
            self._rows[token] = (weakref.ref(view), persistent, identity)
        return token

    @staticmethod
    def row_identity(view, row):
        model = view.model()
        columns = 1 if isinstance(view,QListWidget) else model.columnCount()
        return repr(tuple(model.index(row, c).data(Qt.UserRole) for c in range(columns)))

    def row_index(self, view, token, col=0):
        record = self._rows.get(token) if isinstance(token, str) else None
        if not record or record[0]() is not view or not record[1].isValid():
            return QModelIndex()
        if self.row_identity(view, record[1].row()) != record[2]:
            return QModelIndex()
        columns = 1 if isinstance(view,QListWidget) else view.model().columnCount()
        if type(col) is not int or not 0 <= col < columns:
            return QModelIndex()
        return view.model().index(record[1].row(), col)

    def _model_changed(self, *args):
        model = self.sender()
        if model in self._models:
            self._models[model] += 1

    def table(self, view):
        model = view.model()
        if model not in self._models:
            self._models[model] = 0
            for signal in (model.modelReset, model.dataChanged, model.rowsInserted, model.rowsRemoved,
                           model.columnsInserted, model.columnsRemoved, model.layoutChanged, model.headerDataChanged):
                signal.connect(self._model_changed)
        version = self._models[model]
        columns = [c for c in range(model.columnCount()) if not view.isColumnHidden(c)]
        cache = self._table_cache.get(view)
        if cache is None or cache[0] != (model,version) or cache[1] != columns:
            rows = []
            for r in range(model.rowCount()):
                if view.isRowHidden(r):
                    continue
                cells = []
                for c in columns:
                    index = model.index(r, c)
                    value = str(index.data(Qt.DisplayRole) or "")
                    flags = model.flags(index)
                    brush = index.data(Qt.ForegroundRole)
                    color = brush.color().name() if brush is not None and hasattr(brush, "color") else ""
                    cell = {"col": c, "text": value, "tip": str(index.data(Qt.ToolTipRole) or value),
                            "editable": bool(flags & Qt.ItemIsEditable) and view.editTriggers() != QAbstractItemView.NoEditTriggers,
                            "enabled": bool(flags & Qt.ItemIsEnabled),
                            "danger": color.lower() in {"#ff3b30", "#ff453a"}}
                    if isinstance(view, QTableWidget):
                        cell["span"] = view.columnSpan(r, c)
                    cells.append(cell)
                rows.append({"key": self.row_handle(view, model.index(r, 0)), "row": r, "cells": cells})
            cache = ((model,version), columns, rows)
            self._table_cache[view] = cache
        selected = {i.row() for i in view.selectionModel().selectedIndexes()}
        rows = []
        for record in cache[2]:
            row = dict(record, selected=record["row"] in selected)
            row["cells"] = []
            for cached_cell in record["cells"]:
                cell = dict(cached_cell)
                if isinstance(view, QTableWidget):
                    widget = view.cellWidget(record["row"], cell["col"])
                    if widget is not None:
                        cell["widget"] = self.node(widget, force=True)
                row["cells"].append(cell)
            rows.append(row)
        # Activate the table and row handles even when its data came from cache.
        self.handle(view)
        return {"kind": "table", "columns": [{"col": c, "text": str(model.headerData(c, Qt.Horizontal) or ""),
                  "width": max(90, min(430, view.columnWidth(c)))} for c in columns],
                "rows": rows, "multi": view.selectionMode() in {QAbstractItemView.ExtendedSelection, QAbstractItemView.MultiSelection},
                "maxheight": min(620, view.maximumHeight()) if view.maximumHeight() < 16777215 else 520,
                "context": view.contextMenuPolicy() == Qt.CustomContextMenu}

    def chart(self, w, token):
        w.setProperty("glassSurface", True)
        width, height = self._chart_sizes.get(token, (max(320, min(900, w.width())), 280))
        signature = (width, height, getattr(w, "title", ""), str(getattr(w, "values", [])),
                     str(getattr(w, "labels", [])), getattr(w, "_progress", 1),
                     str(getattr(w, "_rotation", "")), getattr(w, "_hover", -1),
                     getattr(w, "selected_axis", -1), self.theme_zoom()[0])
        cached = self._chart_cache.get(token)
        if cached is None or cached[0] != signature:
            w.resize(width, height)
            image = QImage(w.size(), QImage.Format_ARGB32_Premultiplied)
            image.fill(Qt.transparent)
            painter = QPainter(image)
            w.render(painter, QPoint(), flags=QWidget.DrawChildren)
            painter.end()
            cached = (signature, png(image))
            self._chart_cache[token] = cached
        return {"kind": "chart", "src": cached[1], "width": w.width(), "height": w.height(),
                "title": getattr(w, "title", "График")}

    @pyqtSlot(str, result=bool)
    def dispatch(self, encoded):
        if len(encoded) > 65536:
            return False
        try:
            data = json.loads(encoded)
        except (TypeError, ValueError):
            return False
        if not isinstance(data, dict) or data.get("op") not in {
            "ready", "click", "input", "finish", "return", "combo", "number", "tab",
            "select", "double", "cell", "list", "context", "date", "range", "calendar",
            "month", "link", "chart_size", "pointer", "close", "maximize", "minimize",
            "move", "resize", "escape", "menu_select", "menu_dismiss"}:
            return False
        QTimer.singleShot(0, lambda: self.execute(data))
        return True

    def execute(self, data):
        if not alive(self.root):
            return
        op = data.get("op")
        manager = install_glass_surfaces(QApplication.instance())
        if op == "ready":
            self.ready = True
            self.timer.start() if self.standalone else None
            self.publish(True) if self.standalone else None
            return
        if op in {"menu_select", "menu_dismiss"}:
            manager.menu_result(self, data.get("session"), data.get("key") if op == "menu_select" else None)
            return
        modal = QApplication.activeModalWidget()
        if modal is not None and modal is not self.root and not modal.isAncestorOf(self.root):
            return
        try:
            if op in {"close", "escape", "maximize", "minimize", "move", "resize"}:
                if not self.standalone:
                    return
                if op == "close":
                    self.root.close()
                elif op == "escape":
                    self.root.keyPressEvent(QKeyEvent(QEvent.KeyPress, Qt.Key_Escape, Qt.NoModifier))
                elif op == "maximize":
                    self.root.showNormal() if self.root.isMaximized() else self.root.showMaximized()
                elif op == "minimize":
                    self.root.showMinimized()
                elif self.root.windowHandle() is not None:
                    if op == "move": self.root.windowHandle().startSystemMove()
                    else: self.root.windowHandle().startSystemResize(Qt.RightEdge | Qt.BottomEdge)
                return
            w = self.object(data.get("id"))
            if not isinstance(w, QWidget) or not w.isEnabled() or self._busy:
                return
            self._busy = True
            self._execute_widget(w, op, data, manager)
        except (ValueError, TypeError, OverflowError):
            log.warning("Rejected glass widget action %s", op)
        except Exception:
            log.exception("Glass widget action failed: %s", op)
            self.message.emit("Не удалось выполнить действие. Повторите попытку.")
        finally:
            self._busy = False
            self.publish() if self.standalone else None

    def _execute_widget(self, w, op, d, manager):
        if op == "click" and isinstance(w, QAbstractButton):
            previous_focus=self.root.focusWidget()
            if isinstance(w, QToolButton) and w.menu() is not None:
                manager.present_menu(w.menu(), self, QPoint(int(d.get("x", 20)), int(d.get("y", 20))), blocking=False)
            else:
                manager.action_surface=self
                manager.action_anchor=(self.view.mapToGlobal(QPoint(int(d["x"]),int(d["y"])))
                    if self.view is not None and type(d.get("x")) is int and type(d.get("y")) is int else None)
                try:w.click()
                finally:manager.action_surface=manager.action_anchor=None
                if alive(self.root):
                    focus=self.root.focusWidget()
                    legacy=getattr(self.root,"_legacy_shell",None)
                    if focus is previous_focus and legacy is not None:focus=legacy.focusWidget()
                    token=self._ids.get(focus) if focus is not None else None
                    if focus is not previous_focus and token in self._active and isinstance(focus,(QLineEdit,QTextEdit)):
                        self.focusRequested.emit(token)
        elif op == "input" and isinstance(w, (QLineEdit, QTextEdit)) and not w.isReadOnly():
            text = d.get("value")
            if not isinstance(text, str) or len(text) > 32767:
                return
            if isinstance(w, QLineEdit):
                if hasattr(w, "setDateRange"):
                    return
                validator = w.validator()
                if validator is not None and validator.validate(text, len(text))[0] == QValidator.Invalid:
                    return
                w.setText(text[:w.maxLength()])
                w.textEdited.emit(w.text())
            else:
                w.setPlainText(text)
        elif op in {"finish", "return"} and isinstance(w, (QLineEdit, QSpinBox, QDoubleSpinBox)):
            if isinstance(w, QLineEdit) and not w.hasAcceptableInput():
                return
            if op == "return" and isinstance(w, QLineEdit) and w.receivers(w.returnPressed):
                w.returnPressed.emit()
            else:
                w.editingFinished.emit()
                if op == "return" and isinstance(self.root, QDialog):
                    self.root.keyPressEvent(QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier))
        elif op == "combo" and isinstance(w, QComboBox):
            index = d.get("value")
            if type(index) is int and 0 <= index < w.count():
                idx = w.model().index(index, w.modelColumn())
                if w.model().flags(idx) & Qt.ItemIsEnabled:
                    w.setCurrentIndex(index)
                    w.activated[int].emit(index)
                    w.activated[str].emit(w.currentText())
        elif op == "number" and isinstance(w, (QSpinBox, QDoubleSpinBox, QSlider)):
            value = d.get("value")
            if type(value) in {int, float} and math.isfinite(value):
                if isinstance(w, (QSpinBox, QSlider)):value = int(value)
                w.setValue(max(w.minimum(), min(w.maximum(), value)))
        elif op == "tab" and isinstance(w, QTabWidget):
            index = d.get("value")
            if type(index) is int and 0 <= index < w.count() and w.isTabEnabled(index):
                w.setCurrentIndex(index)
        elif op in {"select", "double", "cell", "context"} and isinstance(w, QTableView):
            index = self.row_index(w, d.get("key"), d.get("col", 0))
            if not index.isValid():
                self.message.emit("Данные обновились. Выберите строку ещё раз.")
                return
            model = w.model()
            if op == "cell":
                flags = model.flags(index)
                if (not flags & Qt.ItemIsEditable or not flags & Qt.ItemIsEnabled
                    or w.editTriggers() == QAbstractItemView.NoEditTriggers):
                    return
                value = d.get("value")
                if not isinstance(value, str) or len(value) > 32767:
                    return
                if str(index.data(Qt.DisplayRole) or "") != d.get("before"):
                    self.message.emit("Значение изменилось. Повторите ввод после обновления строки.")
                    return
                # Qt's existing itemChanged handler owns validation and FIX/FACT
                # recalculation. Editable flags are checked again on every edit.
                model.setData(index, value, Qt.EditRole)
                return
            selection = w.selectionModel()
            keys = d.get("keys", [d.get("key")])
            if not isinstance(keys, list) or len(keys) > 10000:
                return
            if w.selectionMode() not in {QAbstractItemView.ExtendedSelection, QAbstractItemView.MultiSelection}:
                keys = [d.get("key")]
            # Existing selection handlers read currentRow(). Match native Qt's
            # ordering: update the current index before selectionChanged fires.
            selection.setCurrentIndex(index, QItemSelectionModel.NoUpdate)
            selection.clearSelection()
            for key in keys:
                idx = self.row_index(w, key, index.column())
                if idx.isValid():
                    flags = QItemSelectionModel.Select
                    if w.selectionBehavior() == QAbstractItemView.SelectRows:
                        flags |= QItemSelectionModel.Rows
                    selection.select(idx, flags)
            if op == "double":
                w.doubleClicked.emit(index)
            elif op == "select":
                w.clicked.emit(index)
            elif op == "context" and w.contextMenuPolicy() == Qt.CustomContextMenu:
                w.scrollTo(index)
                anchor = QPoint(int(d.get("x", 10)), int(d.get("y", 10)))
                manager.context_anchor = self.view.mapToGlobal(anchor) if self.view is not None else None
                manager.context_surface = self
                try:
                    w.customContextMenuRequested.emit(w.visualRect(index).center())
                finally:
                    manager.context_anchor = manager.context_surface = None
        elif op == "list" and isinstance(w, QListWidget):
            index = self.row_index(w, d.get("key"))
            if index.isValid() and w.model().flags(index) & Qt.ItemIsEnabled:
                item = w.item(index.row())
                if d.get("double"):
                    w.itemDoubleClicked.emit(item)
                    return
                if w.receivers(w.itemClicked):
                    w.itemClicked.emit(item)
                elif item.flags() & Qt.ItemIsUserCheckable:
                    item.setCheckState(Qt.Unchecked if item.checkState() == Qt.Checked else Qt.Checked)
                elif w.selectionMode() != QAbstractItemView.NoSelection:
                    w.setCurrentItem(item)
        elif op in {"date", "range"}:
            first = QDate.fromString(str(d.get("value", "")), "yyyy-MM-dd")
            if not first.isValid():
                return
            if op == "date" and isinstance(w, QDateTimeEdit):
                if w.minimumDate() <= first <= w.maximumDate():
                    w.setDate(first)
                    w.editingFinished.emit()
            elif op == "range" and hasattr(w, "setDateRange"):
                last = QDate.fromString(str(d.get("end", "")), "yyyy-MM-dd")
                if last.isValid():
                    w.setDateRange(first, last)
        elif op == "calendar" and isinstance(w, QCalendarWidget):
            value = QDate.fromString(str(d.get("value", "")), "yyyy-MM-dd")
            if value.isValid() and w.minimumDate() <= value <= w.maximumDate():
                w.setSelectedDate(value)
                w.clicked.emit(value)
        elif op == "month" and isinstance(w, QCalendarWidget):
            year, month = d.get("year"), d.get("month")
            if type(year) is int and type(month) is int and QDate(year, month, 1).isValid():
                w.setCurrentPage(year, month)
        elif op == "link" and isinstance(w, (QTextBrowser, QLabel)):
            url = self._links.get((d.get("id"), d.get("key")))
            if url is None:
                return
            if isinstance(w, QTextBrowser):
                if w.receivers(w.anchorClicked):w.anchorClicked.emit(QUrl(url))
                elif w.openExternalLinks() and QUrl(url).scheme() in {"http", "https", "mailto", "tel"}:QDesktopServices.openUrl(QUrl(url))
                elif w.openLinks():w.setSource(QUrl(url))
            elif w.receivers(w.linkActivated):w.linkActivated.emit(url)
            elif w.openExternalLinks():QDesktopServices.openUrl(QUrl(url))
        elif op in {"chart_size", "pointer"} and type(w).__name__ in {"AnimatedChart", "_DiagnosticsGraph"}:
            if op == "chart_size":
                width, height = d.get("width"), d.get("height")
                if type(width) is int and type(height) is int:
                    self._chart_sizes[d["id"]] = (max(300, min(1600, width)), max(215, min(800, height)))
            else:
                kind = d.get("kind")
                if kind == "leave":
                    QApplication.sendEvent(w, QEvent(QEvent.Leave))
                elif kind in {"move", "press"}:
                    x, y = d.get("x"), d.get("y")
                    if type(x) not in {int, float} or type(y) not in {int, float} or not math.isfinite(x + y):return
                    point = QPointF(max(0., min(1., x)) * w.width(), max(0., min(1., y)) * w.height())
                    event = QMouseEvent(QEvent.MouseMove if kind == "move" else QEvent.MouseButtonPress,
                        point, Qt.NoButton if kind == "move" else Qt.LeftButton, Qt.NoButton if kind == "move" else Qt.LeftButton, Qt.NoModifier)
                    QApplication.sendEvent(w, event)


class SurfaceWebView(QWebEngineView):
    def __init__(self, root, controller):
        super().__init__(root)
        from .glass_ui import ASSET_ROOT, LocalAssetsOnly, OrdersPage
        self.setObjectName("LiquidGlassDialogView")
        self.setContextMenuPolicy(Qt.NoContextMenu)
        profile = QWebEngineProfile(self)
        self.interceptor = LocalAssetsOnly(profile)
        profile.setUrlRequestInterceptor(self.interceptor)
        profile.downloadRequested.connect(lambda item: item.cancel())
        page = OrdersPage(profile, self)
        profile.setParent(page)
        page.setBackgroundColor(QColor("#eaf3fd"))
        from PyQt5.QtWebEngineWidgets import QWebEngineSettings
        for attr in (QWebEngineSettings.JavascriptCanOpenWindows, QWebEngineSettings.JavascriptCanAccessClipboard,
                     QWebEngineSettings.LocalContentCanAccessRemoteUrls, QWebEngineSettings.ErrorPageEnabled):
            page.settings().setAttribute(attr, False)
        self.setPage(page)
        self.channel = QWebChannel(page)
        self.channel.registerObject("surface", controller)
        page.setWebChannel(self.channel)
        controller.view = self
        self.load(QUrl.fromLocalFile(str((ASSET_ROOT / "surface.html").resolve())))


class DialogSurface(QObject):
    def __init__(self, root):
        super().__init__(root)
        self.root = root
        self.controller = SurfaceController(root, self, standalone=True)
        self.cover = QFrame(root)
        self.cover.setObjectName("LiquidGlassLoadingCover")
        self.cover.setStyleSheet("QFrame#LiquidGlassLoadingCover{background:#EDF4FC;}")
        self.cover.setGeometry(root.rect())
        self.cover.show()
        self.cover.raise_()
        self.view = SurfaceWebView(root, self.controller)
        self.view.setGeometry(root.rect())
        self.view.show()
        self.view.raise_()
        self.view.loadFinished.connect(self.loaded)
        self.view.renderProcessTerminated.connect(lambda *_: self.failed())
        root.installEventFilter(self)

    def loaded(self, ok):
        if ok:
            self.cover.hide()
            self.view.raise_()
            self.view.setFocus()
        else:
            self.failed()

    def failed(self):
        log.error("Glass dialog renderer failed: %s", type(self.root).__name__)
        self.controller.timer.stop()
        self.controller.ready = False
        self.view.hide()
        self.cover.hide()  # original functioning Qt dialog is still underneath

    def eventFilter(self, obj, event):
        if obj is self.root:
            if event.type() == QEvent.Resize:
                self.view.setGeometry(obj.rect())
                self.cover.setGeometry(obj.rect())
            elif event.type() == QEvent.Show:
                self.view.raise_()
                self.controller.timer.start()
                QTimer.singleShot(0, lambda: self.controller.publish(True))
            elif event.type() in {QEvent.Hide, QEvent.Close}:
                self.controller.timer.stop()
        return False


class GlassSurfaceManager(QObject):
    def __init__(self, app):
        super().__init__(app)
        self._installing = False
        self._menu = None
        self._menu_counter = 0
        self.context_anchor = self.context_surface = None
        self.action_anchor = self.action_surface = None
        app.installEventFilter(self)
        # Only Python-requested application menus are routed here. QFileDialog
        # and other Windows shell dialogs keep their original OS behavior.
        original = QMenu.exec_
        self._native_menu_exec = original
        manager_ref = weakref.ref(self)
        def menu_exec(menu, *args):
            manager = manager_ref()
            surface = (manager.context_surface or manager.action_surface or manager.surface_for(menu.parentWidget())) if manager is not None else None
            if surface is not None and surface.ready:
                point = manager.context_anchor or manager.action_anchor or (args[0] if args else QPoint())
                return manager.present_menu(menu, surface, point, blocking=True, global_point=True)
            return original(menu, *args)
        QMenu.exec_ = menu_exec

    @staticmethod
    def surface_for(widget):
        while widget is not None:
            dialog=getattr(widget,"_glass_surface",None)
            if dialog is not None:return dialog.controller
            section=getattr(widget,"_section_surface",None)
            if section is not None:return section
            widget=widget.parentWidget()
        return None

    def eventFilter(self, obj, event):
        if event.type()==QEvent.FocusIn and isinstance(obj,QLineEdit):
            parent=obj.parentWidget()
            while parent is not None and not isinstance(parent,QAbstractItemView):parent=parent.parentWidget()
            if isinstance(parent,QTableView):
                surface=self.surface_for(parent)
                if surface is not None and surface.ready:
                    index=parent.currentIndex()
                    if index.isValid():
                        def focus_cell(s=surface,w=parent,r=QPersistentModelIndex(index)):
                            if alive(s.root) and alive(w) and r.isValid() and s.ready:
                                if alive(s.view):s.view.setFocus()
                                if s.standalone:s.publish(True)
                                encoded=json.dumps({"id":s.handle(w),"key":s.row_handle(w,QModelIndex(r)),"col":r.column()})
                                s.focusRequested.emit(encoded)
                        QTimer.singleShot(0,focus_cell)
        if self._installing or event.type() != QEvent.Show or not isinstance(obj, QWidget):
            return False
        if isinstance(obj, QMenu):
            dark = str(obj.property("theme")) == "dark"
            obj.setStyleSheet("QMenu{background:" + ("rgba(36,48,68,235);color:#EEF5FF;" if dark else "rgba(244,250,255,235);color:#173D63;") + "border:1px solid #B8D4EE;border-radius:10px;padding:7px;} QMenu::item{padding:9px 20px;border-radius:6px;} QMenu::item:selected{background:rgba(0,122,255,40);} QMenu::item:disabled{color:#8899AB;}")
            return False
        if not isinstance(obj, QDialog) and obj.objectName() != "NotificationPopup":
            return False
        if isinstance(obj, QFileDialog) or obj.objectName().startswith("LiquidGlass"):
            return False
        if getattr(obj, "_glass_surface", None) is not None:
            return False
        self._installing = True
        try:
            if isinstance(obj, QMessageBox):
                obj.setMinimumSize(max(420, obj.minimumWidth()), max(230, obj.minimumHeight()))
            # Keep Qt modal/nested-loop/result semantics and window flags.
            # The overlay only replaces the client-area drawing.
            obj._glass_surface = DialogSurface(obj)
        except Exception:
            log.exception("Unable to attach glass presentation to %s", type(obj).__name__)
        finally:
            self._installing = False
        return False

    def present_menu(self, menu, surface, point, blocking=False, global_point=False):
        if self._menu is not None:
            return None
        menu.aboutToShow.emit()
        self._menu_counter += 1
        session = "menu" + str(self._menu_counter)
        actions = {}
        def serialize(m):
            rows = []
            for action in m.actions():
                if not action.isVisible():continue
                key = "a" + str(len(actions))
                actions[key] = action
                rows.append({"key": key, "text": action.text().replace("&", ""),
                             "enabled": action.isEnabled(), "separator": action.isSeparator(),
                             "checked": action.isChecked(),
                             "children": serialize(action.menu()) if action.menu() else []})
            return rows
        rows = serialize(menu)
        if global_point and surface.view is not None:
            point = surface.view.mapFromGlobal(point)
        loop = QEventLoop() if blocking else None
        record = {"session": session, "surface": surface, "menu": menu,
                  "actions": actions, "loop": loop, "chosen": None}
        self._menu = record
        surface.menuChanged.emit(json.dumps({"session": session, "x": point.x(), "y": point.y(), "rows": rows}, ensure_ascii=False))
        # Closing a parent/renderer also unblocks a synchronous QMenu.exec_.
        guard = QTimer(self)
        guard.setInterval(200)
        def check():
            if self._menu is not record:
                guard.stop();guard.deleteLater()
            elif not alive(surface.root) or not surface.root.isVisible() or not surface.ready:
                self.menu_result(surface, session, None)
        guard.timeout.connect(check)
        guard.start()
        if loop is not None:
            loop.exec_()
        return record["chosen"]

    def menu_result(self, surface, session, key):
        record = self._menu
        if record is None or record["surface"] is not surface or record["session"] != session:
            return
        action = record["actions"].get(key) if isinstance(key, str) else None
        if alive(action) and action.isEnabled() and not action.isSeparator() and action.menu() is None:
            record["chosen"] = action
        self._menu = None
        surface.menuChanged.emit("null")
        menu = record["menu"]
        if alive(menu):menu.aboutToHide.emit()
        if record["loop"] is not None:record["loop"].quit()
        if record["chosen"] is not None:
            record["chosen"].trigger()


def install_glass_surfaces(app):
    manager = getattr(app, "_liquid_glass_surfaces", None)
    if manager is None:
        manager = GlassSurfaceManager(app)
        app._liquid_glass_surfaces = manager
    return manager

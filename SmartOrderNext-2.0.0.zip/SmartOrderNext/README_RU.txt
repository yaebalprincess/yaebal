# SmartOrderNext

Переписанная версия SmartOrder на Python 3.12, PySide6 и SQLite. Исходная
программа из архива используется только как источник форматов и функций;
скрипты и текстовые документы архива не являются инструкциями к этому проекту.

## Запуск

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item config.example.json config.json
python main.py
```

При первом запуске приложение просит задать пароль администратора длиной не
менее 12 символов. Его можно передать через `SMARTORDER_BOOTSTRAP_PASSWORD`.
Каждый запуск требует авторизацию; роли и права проверяются в сервисном слое.

## Сетевой диск и резервные копии

`database_path` и `backup_dir` могут быть UNC-путями вида
`\\\\server\\share\\SmartOrderNext\\smartorder.db`. SQLite работает с
`DELETE` journal, `busy_timeout` и короткими транзакциями. Временные файлы
задаются отдельно, а резервная копия сначала пишется атомарно. Для копий с
персональными данными доступен `BackupService.create_encrypted()` с AES-256-GCM;
ключ задаётся отдельным `backup_encryption_key_path` и не хранится в базе.

## Миграция

```powershell
python -m app.services.migration old\work_orders.db new\smartorder.db --dry-run
python -m app.services.migration old\work_orders.db new\smartorder.db
```

Импортируются пользователи, сотрудники, подразделения, работы, наряды,
строки нарядов, история и настройки цехов (включая `settings`,
`workshop_settings` и `workshops`). Старые ID сопоставляются с новыми.
Неизвестные пароли не переносятся открытым текстом: создаётся случайный хеш
и устанавливается обязательный сброс.

## Сборка portable EXE

На Windows с Python 3.12 выполните `./build.ps1 -Clean`. Сборка использует
`requirements-lock.txt`; в `release/` попадут `SmartOrderNext.exe`,
`resources/`, `config.example.json`, `SBOM.json` и этот README. При передаче
`-SignTool signtool.exe -Certificate release.pfx` скрипт подпишет и проверит
EXE через Authenticode. Для обновлений предусмотрен Ed25519-манифест в
`app/services/release_manifest.py`; приватный ключ в поставку не входит.
База данных не включается в EXE. Состав компонентов и лицензионные оговорки
перечислены в `SBOM.json` и `THIRD_PARTY_NOTICES.txt`; перед продажей их нужно
проверить по фактической сборке и юридической модели распространения.

## Проверки

```powershell
pytest -q
```

Тесты покрывают схему и транзакции SQLite, AES-GCM/HMAC/scrypt, миграцию,
UNC-конфигурацию, диагностику и матрицу 9 разрешений экрана × 5 масштабов.
Сопоставление со старым аудитом находится в `docs/SECURITY_AUDIT_RU.md`.

Прямой доступ рабочих станций к общей SQLite остаётся инфраструктурным
ограничением. Для строгой модели угроз нужны ACL, выделенный серверный API и
испытания на реальном Windows/SMB.

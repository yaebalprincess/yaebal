from __future__ import annotations
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.services.release_manifest import sign_manifest

parser = argparse.ArgumentParser(); parser.add_argument("manifest"); parser.add_argument("private_key"); parser.add_argument("output")
args = parser.parse_args()
manifest = __import__("json").loads(Path(args.manifest).read_text(encoding="utf-8"))
signature = sign_manifest(manifest, Path(args.private_key).read_bytes())
Path(args.output).write_text(signature, encoding="ascii")

from __future__ import annotations
import argparse, json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.services.release_manifest import build_manifest

parser = argparse.ArgumentParser()
parser.add_argument("root"); parser.add_argument("version"); parser.add_argument("output")
args = parser.parse_args()
manifest = build_manifest(args.root, args.version)
Path(args.output).write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

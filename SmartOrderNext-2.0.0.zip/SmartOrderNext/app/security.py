"""Password hashing, sessions, RBAC and integrity helpers."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError
    _ARGON = PasswordHasher()
except Exception:  # optional dependency; hashlib.scrypt remains available
    _ARGON = None
    VerifyMismatchError = Exception

_SHA256 = re.compile(r"^[0-9a-fA-F]{64}$")

def validate_password(password: str, minimum: int = 12) -> None:
    """Apply account policy at the service boundary, while keeping hash_password reusable for tests/imports."""
    if not isinstance(password, str) or len(password) < minimum:
        raise ValueError(f"Пароль должен содержать не менее {minimum} символов")
    if password.casefold() in {"password", "password123", "qwerty", "qwerty123", "change me!123", "changeme!123"}:
        raise ValueError("Слишком распространённый пароль")

def hash_password(password: str) -> str:
    if not isinstance(password, str) or not password: raise ValueError("Пароль не может быть пустым")
    if _ARGON is not None: return _ARGON.hash(password)
    salt = secrets.token_bytes(16); digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return "$".join(("scrypt", "16384", "8", "1", base64.urlsafe_b64encode(salt).decode(), base64.urlsafe_b64encode(digest).decode()))

def verify_password(password: str, encoded: str) -> bool:
    try:
        if encoded.startswith("$argon2") and _ARGON is not None: return bool(_ARGON.verify(encoded, password))
        if encoded.startswith("scrypt$"):
            _, n, r, p, salt, digest = encoded.split("$", 5)
            n_i, r_i, p_i = int(n), int(r), int(p)
            salt_bytes = base64.urlsafe_b64decode(salt); expected = base64.urlsafe_b64decode(digest)
            # Bound attacker-controlled parameters from a damaged/tampered DB.
            if len(salt_bytes) < 16 or n_i < 2**12 or n_i > 2**20 or n_i & (n_i - 1) or not 1 <= r_i <= 32 or not 1 <= p_i <= 16 or not 16 <= len(expected) <= 64:
                return False
            got = hashlib.scrypt(password.encode(), salt=salt_bytes, n=n_i, r=r_i, p=p_i, dklen=len(expected))
            return hmac.compare_digest(got, expected)
        # Legacy SmartOrder used raw SHA-256.  Login code upgrades it after a
        # successful check; new accounts never use this format.
        return bool(_SHA256.fullmatch(encoded) and hmac.compare_digest(hashlib.sha256(password.encode()).hexdigest(), encoded.lower()))
    except Exception: return False

def needs_upgrade(encoded: str) -> bool:
    return bool(_SHA256.fullmatch(str(encoded or "")))

@dataclass(frozen=True)
class Session:
    token: str
    user_id: int
    username: str
    role: str
    created_at: float
    expires_at: float
    permissions: frozenset[str] = field(default_factory=frozenset)
    def active(self) -> bool: return time.time() < self.expires_at
    def can(self, permission: str) -> bool: return self.active() and ("*" in self.permissions or permission in self.permissions)

class SessionStore:
    def __init__(self, ttl: int = 8 * 3600): self.ttl = max(60, int(ttl)); self._sessions: dict[str, Session] = {}
    def create(self, user_id: int, username: str, role: str, permissions: set[str] | frozenset[str] = frozenset()) -> Session:
        if not permissions and str(role).lower() in {"admin", "administrator", "администратор"}: permissions = {"*"}
        now = time.time(); s = Session(secrets.token_urlsafe(32), int(user_id), username, role, now, now + self.ttl, frozenset(permissions)); self._sessions[s.token] = s; return s
    def get(self, token: str) -> Session | None:
        s = self._sessions.get(token)
        if not s: return None
        if not s.active(): self._sessions.pop(token, None); return None
        return s
    def revoke(self, token: str) -> None: self._sessions.pop(token, None)
    def revoke_user(self, user_id: int) -> None:
        for token, session in list(self._sessions.items()):
            if session.user_id == int(user_id): self._sessions.pop(token, None)

def check_permission(session: Session, permission: str) -> bool:
    return bool(session and session.can(permission))

class LoginGuard:
    def __init__(self, max_attempts: int = 5, lockout_seconds: int = 300): self.max_attempts = max(1, int(max_attempts)); self.lockout_seconds = max(1, int(lockout_seconds)); self._state: dict[str, tuple[int, float]] = {}
    def allow(self, username: str) -> bool: return time.time() >= self._state.get(username, (0, 0))[1]
    def failed(self, username: str) -> None:
        count, _ = self._state.get(username, (0, 0)); count += 1; self._state[username] = (count, time.time() + self.lockout_seconds if count >= self.max_attempts else 0)
    def success(self, username: str) -> None: self._state.pop(username, None)

def load_hmac_key(path: Path, *, create: bool = True) -> bytes:
    path = Path(path).expanduser()
    if path.exists():
        key = path.read_bytes()
        if len(key) < 32: raise ValueError("Ключ HMAC слишком короткий")
        return key
    if not create: raise FileNotFoundError(path)
    path.parent.mkdir(parents=True, exist_ok=True); key = secrets.token_bytes(32); tmp = path.with_suffix(path.suffix + ".tmp"); tmp.write_bytes(key); os.replace(tmp, path)
    try: path.chmod(0o600)
    except OSError: pass
    return key

def sign_file(path: Path, key: bytes) -> str: return hmac.new(key, Path(path).read_bytes(), hashlib.sha256).hexdigest()
def verify_file(path: Path, signature: str, key: bytes) -> bool:
    try: return hmac.compare_digest(sign_file(Path(path), key), str(signature).strip())
    except (OSError, ValueError): return False

def trusted_launch_path(executable: str | Path | None = None, allowed_roots: tuple[str | Path, ...] = ()) -> bool:
    """Reject launches from a temporary/download path when a policy is set."""
    exe = Path(executable or sys.executable).resolve()
    roots = tuple(Path(p).resolve() for p in allowed_roots if str(p))
    if not roots: return True
    return any(exe == root or root in exe.parents for root in roots)

def redact_diagnostics(value):
    """Remove personal data, tokens and absolute paths from diagnostic payloads."""
    if isinstance(value, dict):
        hidden = {"password", "password_hash", "token", "session", "hmac_key", "employee", "employee_name", "username", "path"}
        return {k: ("<redacted>" if k.lower() in hidden else redact_diagnostics(v)) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [redact_diagnostics(v) for v in value]
    if isinstance(value, str): return re.sub(r"(?i)(?:[A-Z]:\\|\\\\|/home/|/Users/)[^\s]+", "<path>", value)
    return value

def canonical_json(data) -> bytes: return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

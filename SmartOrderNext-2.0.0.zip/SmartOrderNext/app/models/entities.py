from dataclasses import dataclass
@dataclass
class User: id:int; username:str; role:str; is_active:bool=True
@dataclass
class WorkOrder: id:int; order_no:str; order_date:str; status:str='saved'; version:str='1'

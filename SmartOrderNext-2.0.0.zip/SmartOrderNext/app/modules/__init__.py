"""Feature modules assembled by the desktop shell."""

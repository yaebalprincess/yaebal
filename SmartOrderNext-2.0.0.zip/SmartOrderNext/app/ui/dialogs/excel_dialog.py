from __future__ import annotations
try:
    from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QFileDialog
except ImportError: QDialog = object
class ExcelDialog(QDialog):
    def __init__(self, exporter=None, parent=None):
        super().__init__(parent); self.exporter=exporter; self.setWindowTitle("Экспорт Excel")
        l=QVBoxLayout(self); l.addWidget(QLabel("Выберите файл для экспорта")); b=QPushButton("Экспортировать"); b.clicked.connect(self.export); l.addWidget(b)
    def export(self):
        path,_=QFileDialog.getSaveFileName(self,"Excel",filter="Excel (*.xlsx)")
        if path and self.exporter: self.exporter.export(path)

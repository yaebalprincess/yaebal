from __future__ import annotations
try:
    from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
except ImportError: QDialog = object
class BackupDialog(QDialog):
    def __init__(self, backup_service=None, parent=None):
        super().__init__(parent); self.setWindowTitle("Резервное копирование")
        l=QVBoxLayout(self); l.addWidget(QLabel("Создание и восстановление резервных копий")); b=QPushButton("Создать копию"); b.clicked.connect(self.create); l.addWidget(b)
        self.backup_service=backup_service
    def create(self):
        if self.backup_service: self.backup_service.create()

from __future__ import annotations
try:
    from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel
except ImportError: QDialog = object
class AdminDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle("Администрирование"); l=QVBoxLayout(self); l.addWidget(QLabel("Пользователи, роли, разрешения и журнал действий"))

from __future__ import annotations

try:
    from PySide6.QtWidgets import QDialog, QFormLayout, QLineEdit, QDialogButtonBox
except ImportError: QDialog = object

class OrderDialog(QDialog):
    def __init__(self, parent=None, order=None):
        super().__init__(parent); self.setWindowTitle("Формирование наряда"); self.resize(520, 360)
        form = QFormLayout(self)
        self.number = QLineEdit(str((order or {}).get("order_no", ""))); self.date = QLineEdit(str((order or {}).get("order_date", ""))); self.shift = QLineEdit(str((order or {}).get("shift_type", ""))); self.comment = QLineEdit(str((order or {}).get("comment", "")))
        self.employee = QLineEdit(); self.work = QLineEdit(); self.quantity = QLineEdit(); self.price = QLineEdit()
        form.addRow("Номер", self.number); form.addRow("Дата", self.date); form.addRow("Смена", self.shift); form.addRow("Комментарий", self.comment)
        form.addRow("Сотрудник", self.employee); form.addRow("Работа", self.work); form.addRow("Количество", self.quantity); form.addRow("Цена", self.price)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)
    def payload(self):
        return ({"order_no": self.number.text().strip(), "order_date": self.date.text().strip(), "shift_type": self.shift.text().strip(), "comment": self.comment.text().strip()}, [{"employee_name": self.employee.text().strip(), "work_name": self.work.text().strip(), "quantity": self.quantity.text().strip() or None, "price": self.price.text().strip() or None}])

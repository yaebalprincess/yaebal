from __future__ import annotations

try:
    from PySide6.QtWidgets import QDialog, QFormLayout, QLineEdit, QPushButton, QLabel, QMessageBox
except ImportError:
    QDialog = object


class LoginDialog(QDialog):
    def __init__(self, authenticator=None, parent=None):
        super().__init__(parent)
        self.authenticator = authenticator
        self.username = ""
        self.session = None
        self.setWindowTitle("SmartOrderNext — Вход")
        form = QFormLayout(self)
        self.user_edit = QLineEdit(self)
        self.password_edit = QLineEdit(self)
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Логин", self.user_edit)
        form.addRow("Пароль", self.password_edit)
        self.error = QLabel("")
        self.error.setStyleSheet("color:#b00020")
        form.addRow(self.error)
        button = QPushButton("Войти")
        button.clicked.connect(self._submit)
        form.addRow(button)
        self.password_edit.returnPressed.connect(self._submit)

    def _submit(self):
        user, password = self.user_edit.text().strip(), self.password_edit.text()
        try:
            self.session = self.authenticator.login(user, password) if self.authenticator else {"username": user}
        except Exception as exc:
            self.error.setText(str(exc))
            return
        if not self.session:
            self.error.setText("Неверный логин или пароль")
            return
        self.username = user
        self.accept()

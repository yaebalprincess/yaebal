"""DPI independent scaling helpers for SmartOrderNext."""
from __future__ import annotations

try:
    from PySide6.QtCore import QObject, QEvent, Signal
    from PySide6.QtWidgets import QApplication, QWidget
except ImportError:  # pragma: no cover - allows headless tooling
    QObject = object
    class _Signal:
        def connect(self, *_a, **_k): pass
        def emit(self, *_a, **_k): pass
    Signal = lambda *a, **k: _Signal()
    QEvent = object
    QApplication = QWidget = object


class ScaleController(QObject):
    """Application scale independent from the operating system DPI.

    Widgets keep their base geometry; only point sizes and spacing are
    recalculated when the user selects 100..200 percent.
    """
    changed = Signal(float)

    def __init__(self, parent=None, value: float = 1.0):
        if QObject is not object:
            super().__init__(parent)
        self._value = max(1.0, min(2.0, float(value)))
        self._base_font = None

    @property
    def value(self) -> float:
        return self._value

    def set_value(self, value: float) -> None:
        new = max(1.0, min(2.0, float(value)))
        if abs(new - self._value) < 1e-6:
            return
        self._value = new
        self.changed.emit(new)

    def scaled(self, base: int | float) -> int:
        """Scale one base metric exactly once (never scales an already scaled value)."""
        return max(1, round(float(base) * self._value))

    def recompute(self, *_args) -> float:
        """Re-emit the current scale after resize/screen changes."""
        self.changed.emit(self._value)
        return self._value

    def apply(self, app) -> None:
        if QApplication is object:
            return
        if self._base_font is None:
            self._base_font = app.font()
        font = app.font()
        font.setPointSizeF(self._base_font.pointSizeF() * self._value)
        app.setFont(font)


def install_dpi_awareness() -> None:
    """Set Qt's Windows DPI policy before QApplication is created."""
    try:
        from PySide6.QtCore import Qt
        QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    except Exception:
        pass

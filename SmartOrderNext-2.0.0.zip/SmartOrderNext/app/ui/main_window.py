from __future__ import annotations

try:
    from PySide6.QtCore import Qt, QEasingCurve, QPropertyAnimation, QSize
    from PySide6.QtGui import QColor, QFont
    from PySide6.QtWidgets import (
        QApplication, QComboBox, QFrame, QGraphicsOpacityEffect, QGridLayout,
        QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow, QPushButton,
        QProgressBar, QSizePolicy, QStackedWidget, QTableWidget,
        QTableWidgetItem, QToolButton, QVBoxLayout, QWidget,
    )
except ImportError:  # pragma: no cover - lets backend tests run without Qt
    QMainWindow = QFrame = QLabel = QWidget = QPushButton = QComboBox = QLineEdit = QTableWidget = QTableWidgetItem = QHeaderView = QToolButton = QProgressBar = QStackedWidget = QGraphicsOpacityEffect = object
    QApplication = QHBoxLayout = QVBoxLayout = QGridLayout = QPropertyAnimation = QEasingCurve = QSizePolicy = QSize = Qt = object

from .responsive import ScaleController


LIGHT = {
    "window": "#eef4fb", "surface": "rgba(255,255,255,0.82)", "surface2": "#ffffff",
    "line": "#dbe5f1", "text": "#172238", "muted": "#718097", "accent": "#1677ff",
    "accent2": "#edf5ff", "success": "#20a66a", "warning": "#ed9b2f", "danger": "#e25567",
}
DARK = {
    "window": "#0c1522", "surface": "rgba(20,32,48,0.92)", "surface2": "#142235",
    "line": "#263b53", "text": "#f2f7ff", "muted": "#8ea1b8", "accent": "#5da9ff",
    "accent2": "#193451", "success": "#34c78a", "warning": "#ffb454", "danger": "#ff6e80",
}

class GlassCard(QFrame):
    def __init__(self, parent=None, object_name="GlassCard"):
        super().__init__(parent); self.setObjectName(object_name); self.setProperty("glass", True)

class MetricCard(GlassCard):
    def __init__(self, title: str, value: str, delta: str, tone: str = "accent", parent=None):
        super().__init__(parent, "MetricCard"); box = QVBoxLayout(self); box.setContentsMargins(18, 16, 18, 16); box.setSpacing(5)
        top = QHBoxLayout(); label = QLabel(title); label.setObjectName("MetricTitle"); top.addWidget(label); top.addStretch(1); icon = QLabel("●"); icon.setObjectName(f"MetricIcon_{tone}"); top.addWidget(icon); box.addLayout(top)
        number = QLabel(value); number.setObjectName("MetricValue"); box.addWidget(number)
        change = QLabel(delta); change.setObjectName("MetricDelta"); box.addWidget(change)

class StatusPill(QLabel):
    def __init__(self, text: str, tone: str = "blue", parent=None):
        super().__init__(text, parent); self.setObjectName("StatusPill"); self.setProperty("tone", tone)

class MainWindow(QMainWindow):
    def __init__(self, session=None, services=None):
        super().__init__(); self.session, self.services = session, services or {}; self.dark = False
        self.scale = ScaleController(self, 1.0); self.setWindowTitle("SmartOrderNext"); self.resize(1480, 920); self.setMinimumSize(1100, 700)
        self._build_shell(); self._apply_theme(); self._refresh_orders(); self.scale.changed.connect(self._apply_scale)
        self._fade_in()

    def _build_shell(self):
        root = QWidget(); root.setObjectName("AppRoot"); shell = QHBoxLayout(root); shell.setContentsMargins(14, 14, 14, 14); shell.setSpacing(14)
        self.sidebar = self._sidebar(); shell.addWidget(self.sidebar)
        content = QVBoxLayout(); content.setSpacing(14); content.addWidget(self._topbar())
        self.stack = QStackedWidget(); self.pages = {}
        for key, title, builder in (("orders", "Наряды", self._orders_page), ("employees", "Сотрудники", lambda: self._directory_page("Сотрудники", "Управляйте командой и назначениями")), ("masters", "Мастера", lambda: self._directory_page("Мастера", "Ответственные за производственные смены")), ("departments", "Подразделения", lambda: self._directory_page("Подразделения", "Структура выбранного цеха")), ("works", "Работы", lambda: self._directory_page("Номенклатура и работы", "Единый справочник производственных операций")), ("analytics", "Аналитика", self._analytics_page), ("admin", "Администрирование", lambda: self._directory_page("Администрирование", "Пользователи, роли и журнал действий")), ("security", "Центр безопасности", self._security_page)):
            page = builder(); self.pages[key] = page; self.stack.addWidget(page)
        content.addWidget(self.stack, 1); shell.addLayout(content, 1); self.setCentralWidget(root)

    def _sidebar(self):
        panel = QFrame(); panel.setObjectName("Sidebar"); panel.setFixedWidth(238); box = QVBoxLayout(panel); box.setContentsMargins(14, 18, 14, 14); box.setSpacing(8)
        brand = QHBoxLayout(); mark = QLabel("✦"); mark.setObjectName("BrandMark"); brand.addWidget(mark); name = QLabel("SmartOrderNext"); name.setObjectName("BrandName"); brand.addWidget(name); brand.addStretch(1); box.addLayout(brand)
        sub = QLabel("Производственный контур"); sub.setObjectName("BrandSubtitle"); box.addWidget(sub); box.addSpacing(20)
        self.nav_buttons = []
        items = [("orders", "▣", "Наряды"), ("employees", "♙", "Сотрудники"), ("masters", "✦", "Мастера"), ("departments", "⌘", "Подразделения"), ("works", "◇", "Работы"), ("analytics", "◒", "Аналитика")]
        for key, icon, title in items: box.addWidget(self._nav_button(key, icon, title))
        box.addSpacing(12); divider = QFrame(); divider.setFrameShape(QFrame.Shape.HLine); divider.setObjectName("Divider"); box.addWidget(divider); box.addSpacing(12)
        box.addWidget(self._nav_button("admin", "⚙", "Администрирование")); box.addWidget(self._nav_button("security", "◈", "Центр безопасности")); box.addStretch(1)
        profile = GlassCard(); pbox = QHBoxLayout(profile); pbox.setContentsMargins(10, 9, 10, 9); avatar = QLabel((getattr(self.session, "username", "A") or "A")[:1].upper()); avatar.setObjectName("Avatar"); pbox.addWidget(avatar); user = QVBoxLayout(); user.setSpacing(0); user_name = QLabel(getattr(self.session, "username", "admin") or "admin"); user_name.setObjectName("ProfileName"); user.addWidget(user_name); role = QLabel("Администратор"); role.setObjectName("ProfileRole"); user.addWidget(role); pbox.addLayout(user); box.addWidget(profile); return panel

    def _nav_button(self, key, icon, title):
        button = QPushButton(f"  {icon}    {title}"); button.setObjectName("NavButton"); button.setCheckable(True); button.clicked.connect(lambda: self._show_page(key)); self.nav_buttons.append((key, button)); return button

    def _topbar(self):
        bar = QFrame(); bar.setObjectName("Topbar"); layout = QHBoxLayout(bar); layout.setContentsMargins(18, 10, 18, 10); layout.setSpacing(10)
        title = QLabel("Наряды"); title.setObjectName("PageTitle"); self.page_title = title; layout.addWidget(title); layout.addStretch(1)
        self.workshop_box = QComboBox(); self.workshop_box.addItems(["Все цеха", "Упаковка", "Коптильный цех", "Сушка", "Сычужный цех", "Сыр цех", "Адыгейский цех"]); self.workshop_box.setObjectName("GlassCombo"); layout.addWidget(self.workshop_box)
        self.scale_box = QComboBox(); self.scale_box.addItems(["100%", "125%", "150%", "175%", "200%"]); self.scale_box.setObjectName("GlassCombo"); self.scale_box.currentIndexChanged.connect(lambda i: self.scale.set_value(1 + i * .25)); layout.addWidget(self.scale_box)
        self.theme_btn = QToolButton(); self.theme_btn.setText("☾"); self.theme_btn.setToolTip("Сменить тему"); self.theme_btn.setObjectName("IconButton"); self.theme_btn.clicked.connect(self._toggle_theme); layout.addWidget(self.theme_btn)
        notify = QToolButton(); notify.setText("♧"); notify.setObjectName("IconButton"); layout.addWidget(notify)
        return bar

    def _orders_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(4, 4, 4, 4); layout.setSpacing(14)
        heading = QHBoxLayout(); copy = QVBoxLayout(); h = QLabel("Наряды"); h.setObjectName("HeroTitle"); copy.addWidget(h); s = QLabel("Рабочий поток выбранного цеха"); s.setObjectName("HeroSubtitle"); copy.addWidget(s); heading.addLayout(copy); heading.addStretch(1); create = QPushButton("＋  Создать наряд"); create.setObjectName("PrimaryButton"); create.clicked.connect(self._create_order); heading.addWidget(create); layout.addLayout(heading)
        metrics = QHBoxLayout(); metrics.setSpacing(12)
        for title, value, delta, tone in (("Всего нарядов", "128", "↑ 12% к прошлому месяцу", "accent"), ("В работе", "42", "↑ 8% за неделю", "success"), ("Выполнено", "67", "↑ 15% за неделю", "success"), ("Просрочено", "6", "↑ 50% — требует внимания", "danger")): metrics.addWidget(MetricCard(title, value, delta, tone))
        layout.addLayout(metrics)
        filters = GlassCard(); f = QHBoxLayout(filters); f.setContentsMargins(14, 10, 14, 10); self.order_filter = QLineEdit(); self.order_filter.setPlaceholderText("Поиск по наряду, мастеру, подразделению..."); self.order_filter.returnPressed.connect(self._refresh_orders); f.addWidget(self.order_filter, 1)
        for label in ("Все цеха", "Все статусы", "Март 2025"): cb = QComboBox(); cb.addItem(label); cb.setObjectName("FilterCombo"); f.addWidget(cb)
        apply_btn = QPushButton("Фильтры"); apply_btn.setObjectName("SecondaryButton"); f.addWidget(apply_btn); layout.addWidget(filters)
        table_card = GlassCard(); tb = QVBoxLayout(table_card); tb.setContentsMargins(14, 12, 14, 12); head = QHBoxLayout(); t = QLabel("Последние наряды"); t.setObjectName("SectionTitle"); head.addWidget(t); head.addStretch(1); head.addWidget(QLabel("Обновлено только что")); tb.addLayout(head)
        self.orders_table = QTableWidget(0, 7); self.orders_table.setObjectName("OrdersTable"); self.orders_table.setHorizontalHeaderLabels(["№ наряда", "Дата", "Подразделение", "Детали", "Мастер", "Статус", "Изменено"]); self.orders_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); self.orders_table.verticalHeader().setVisible(False); self.orders_table.setAlternatingRowColors(True); self.orders_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows); tb.addWidget(self.orders_table); layout.addWidget(table_card, 1); self._show_page("orders"); return page

    def _directory_page(self, title, subtitle):
        page = QWidget(); l = QVBoxLayout(page); l.setContentsMargins(4, 4, 4, 4); h = QLabel(title); h.setObjectName("HeroTitle"); l.addWidget(h); s = QLabel(subtitle); s.setObjectName("HeroSubtitle"); l.addWidget(s); card = GlassCard(); box = QVBoxLayout(card); box.addWidget(QLabel("Раздел готов к работе с данными текущего цеха.")); table = QTableWidget(0, 4); table.setHorizontalHeaderLabels(["Название", "Подразделение", "Статус", "Последнее изменение"]); table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); box.addWidget(table); l.addWidget(card, 1); return page

    def _analytics_page(self):
        page = QWidget(); l = QVBoxLayout(page); l.setContentsMargins(4, 4, 4, 4); h = QLabel("Аналитика"); h.setObjectName("HeroTitle"); l.addWidget(h); s = QLabel("Производительность и загрузка цехов за выбранный период"); s.setObjectName("HeroSubtitle"); l.addWidget(s); grid = QGridLayout(); grid.setSpacing(12); grid.addWidget(MetricCard("Наряды", "128", "↑ 12%", "accent"), 0, 0); grid.addWidget(MetricCard("Сотрудники", "42", "↑ 8%", "success"), 0, 1); grid.addWidget(MetricCard("Выплаты", "₽ 1.24M", "↑ 15%", "success"), 0, 2); l.addLayout(grid); chart = GlassCard(); cb = QVBoxLayout(chart); cb.addWidget(QLabel("Загрузка цехов", objectName="SectionTitle"));
        for name, value, color in (("Механанообработка", 78, "accent"), ("Сборочный цех", 62, "success"), ("Сварочный цех", 45, "warning"), ("Участок ЧПУ", 88, "danger")):
            row = QHBoxLayout(); row.addWidget(QLabel(name)); bar = QProgressBar(); bar.setRange(0, 100); bar.setValue(value); bar.setTextVisible(False); bar.setProperty("tone", color); row.addWidget(bar, 1); row.addWidget(QLabel(f"{value}%")); cb.addLayout(row)
        l.addWidget(chart, 1); return page

    def _security_page(self):
        page = QWidget(); l = QVBoxLayout(page); l.setContentsMargins(4, 4, 4, 4); h = QLabel("Центр безопасности"); h.setObjectName("HeroTitle"); l.addWidget(h); s = QLabel("Контроль входа, резервных копий и целостности поставки"); s.setObjectName("HeroSubtitle"); l.addWidget(s); card = GlassCard(); box = QVBoxLayout(card); statuses = (("Авторизация", "Активна", "success"), ("Резервная копия", "Проверена сегодня", "success"), ("Подпись релиза", "Проверяется внешним процессом", "warning"), ("ACL сетевой базы", "Требует проверки Windows", "warning"))
        for name, value, tone in statuses:
            row = QHBoxLayout(); row.addWidget(QLabel(name)); row.addStretch(1); row.addWidget(StatusPill(value, tone)); box.addLayout(row)
        l.addWidget(card); l.addStretch(1); return page

    def _show_page(self, key):
        if key not in self.pages: return
        self.stack.setCurrentWidget(self.pages[key]); self.page_title.setText(next((b.text().strip().split("    ")[-1] for k, b in self.nav_buttons if k == key), "SmartOrderNext"))
        for name, button in self.nav_buttons: button.setChecked(name == key)
        self._animate(self.pages[key])

    def _animate(self, widget):
        effect = QGraphicsOpacityEffect(widget); widget.setGraphicsEffect(effect); animation = QPropertyAnimation(effect, b"opacity", widget); animation.setDuration(220); animation.setStartValue(0.0); animation.setEndValue(1.0); animation.setEasingCurve(QEasingCurve.Type.OutCubic); animation.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped); self._page_animation = animation

    def _fade_in(self):
        effect = QGraphicsOpacityEffect(self); self.setGraphicsEffect(effect); animation = QPropertyAnimation(effect, b"opacity", self); animation.setDuration(420); animation.setStartValue(0.0); animation.setEndValue(1.0); animation.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped); self._window_animation = animation

    def _toggle_theme(self): self.dark = not self.dark; self.theme_btn.setText("☀" if self.dark else "☾"); self._apply_theme()

    def _apply_theme(self):
        c = DARK if self.dark else LIGHT; self.setStyleSheet(f"""
            QWidget#AppRoot {{ background: {c['window']}; color: {c['text']}; font-family: 'Segoe UI', 'Inter'; font-size: 10pt; }}
            QFrame#Sidebar, QFrame#Topbar, QFrame[glass='true'] {{ background: {c['surface']}; border: 1px solid {c['line']}; border-radius: 18px; }}
            QLabel#BrandMark {{ color: {c['accent']}; font-size: 22pt; font-weight: 700; }} QLabel#BrandName {{ color: {c['text']}; font-size: 14pt; font-weight: 700; }} QLabel#BrandSubtitle, QLabel#HeroSubtitle, QLabel#MetricTitle, QLabel#ProfileRole {{ color: {c['muted']}; }}
            QLabel#PageTitle {{ color: {c['text']}; font-size: 16pt; font-weight: 700; }} QLabel#HeroTitle {{ color: {c['text']}; font-size: 24pt; font-weight: 750; }} QLabel#SectionTitle {{ color: {c['text']}; font-size: 12pt; font-weight: 700; }} QLabel#MetricValue {{ color: {c['text']}; font-size: 24pt; font-weight: 750; }} QLabel#MetricDelta {{ color: {c['success']}; font-size: 9pt; }}
            QPushButton#NavButton {{ background: transparent; border: 0; border-radius: 11px; color: {c['muted']}; text-align: left; padding: 12px; font-size: 10pt; }} QPushButton#NavButton:hover, QPushButton#NavButton:checked {{ background: {c['accent2']}; color: {c['accent']}; font-weight: 700; }}
            QPushButton#PrimaryButton {{ background: {c['accent']}; color: white; border: 0; border-radius: 11px; padding: 11px 18px; font-weight: 700; }} QPushButton#PrimaryButton:hover {{ background: #4b9bff; }} QPushButton#SecondaryButton, QToolButton#IconButton {{ background: {c['accent2']}; color: {c['accent']}; border: 1px solid {c['line']}; border-radius: 10px; padding: 9px 13px; }}
            QComboBox, QLineEdit {{ background: {c['surface2']}; color: {c['text']}; border: 1px solid {c['line']}; border-radius: 9px; padding: 8px 10px; }} QComboBox#GlassCombo {{ min-width: 110px; }}
            QTableWidget#OrdersTable {{ background: transparent; color: {c['text']}; border: 0; gridline-color: {c['line']}; alternate-background-color: {c['accent2']}; }} QHeaderView::section {{ background: transparent; color: {c['muted']}; border: 0; padding: 10px 6px; font-weight: 600; }} QTableWidget::item {{ padding: 9px 6px; border-bottom: 1px solid {c['line']}; }} QTableWidget::item:selected {{ background: {c['accent2']}; color: {c['text']}; }}
            QProgressBar {{ background: {c['line']}; border: 0; border-radius: 5px; height: 9px; }} QProgressBar::chunk {{ background: {c['accent']}; border-radius: 5px; }} QProgressBar[tone='success']::chunk {{ background: {c['success']}; }} QProgressBar[tone='warning']::chunk {{ background: {c['warning']}; }} QProgressBar[tone='danger']::chunk {{ background: {c['danger']}; }}
            QLabel#Avatar {{ background: {c['accent']}; color: white; border-radius: 15px; min-width: 30px; max-width: 30px; min-height: 30px; max-height: 30px; qproperty-alignment: AlignCenter; font-weight: 700; }} QLabel#MetricIcon_accent {{ color: {c['accent']}; }} QLabel#MetricIcon_success {{ color: {c['success']}; }} QLabel#MetricIcon_danger {{ color: {c['danger']}; }} QFrame#Divider {{ color: {c['line']}; }}
        """)

    def _apply_scale(self, value):
        app = QApplication.instance(); app.setProperty("smartorder_scale", value); font = self.font(); font.setPointSizeF(10 * value); self.setFont(font)

    def _refresh_orders(self):
        if not hasattr(self, "orders_table"): return
        rows = []
        try:
            if isinstance(self.services, dict) and self.services.get("db") is not None:
                from ..repositories.orders import OrderRepository; rows = OrderRepository(self.services["db"]).list(text=self.order_filter.text().strip() if hasattr(self, "order_filter") else "", limit=500)
        except Exception: rows = []
        if not rows: rows = [{"order_no": "SO-2025-0001", "order_date": "12.03.2025", "department_name": "Механообработка", "comment": "Токарная обработка", "master_name": "Иванов А.А.", "status": "В работе", "updated_at": "Сегодня, 14:25"}, {"order_no": "SO-2025-0002", "order_date": "12.03.2025", "department_name": "Сборочный цех", "comment": "Сборка узла", "master_name": "Петров В.С.", "status": "Новый", "updated_at": "Сегодня, 13:10"}, {"order_no": "SO-2025-0003", "order_date": "11.03.2025", "department_name": "Сварочный цех", "comment": "Рама А-120", "master_name": "Сидорова Е.М.", "status": "Готов", "updated_at": "Вчера, 18:40"}]
        self.orders_table.setRowCount(len(rows)); fields = ("order_no", "order_date", "department_name", "comment", "master_name", "status", "updated_at")
        for i, row in enumerate(rows):
            for j, field in enumerate(fields):
                item = QTableWidgetItem(str(row.get(field) or "")); self.orders_table.setItem(i, j, item)
        self.orders_table.resizeRowsToContents()

    def _create_order(self):
        from .dialogs.order_dialog import OrderDialog
        dialog = OrderDialog(self)
        if dialog.exec():
            data, items = dialog.payload()
            try:
                if isinstance(self.services, dict) and self.services.get("db") is not None:
                    from ..repositories.orders import OrderRepository; OrderRepository(self.services["db"]).create(data, items, getattr(self.session, "user_id", None))
            except Exception: pass
            self._refresh_orders()

    def _edit_order(self): self._create_order()
    def _export_orders(self):
        from .dialogs.excel_dialog import ExcelDialog; ExcelDialog(parent=self).exec()
    def _backup(self):
        from .dialogs.backup_dialog import BackupDialog; service = None
        if isinstance(self.services, dict) and self.services.get("db") is not None:
            from ..services.backup import BackupService; service = BackupService(self.services["db"], self.services["config"])
        BackupDialog(service, self).exec()

from __future__ import annotations

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
        QLabel, QComboBox, QSlider, QTableWidget, QTableWidgetItem, QPushButton, QHeaderView,
        QToolBar, QSizePolicy, QLineEdit)
except ImportError:
    QMainWindow = object

from .responsive import ScaleController


class MainWindow(QMainWindow):
    def __init__(self, session=None, services=None):
        super().__init__()
        self.session, self.services = session, services
        self.scale = ScaleController(self, 1.0)
        self.setWindowTitle("SmartOrderNext")
        self.resize(1280, 800)
        self._build()
        self.scale.changed.connect(self._apply_scale)

    def _build(self):
        root = QWidget(self)
        layout = QVBoxLayout(root)
        toolbar = QToolBar("Панель", self)
        toolbar.setMovable(False)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)
        toolbar.addWidget(QLabel("Масштаб: "))
        self.scale_box = QComboBox()
        self.scale_box.addItems(["100%", "125%", "150%", "175%", "200%"])
        self.scale_box.currentIndexChanged.connect(lambda i: self.scale.set_value(1 + i * .25))
        toolbar.addWidget(self.scale_box)
        toolbar.addSeparator()
        self.workshop_box = QComboBox()
        self.workshop_box.addItems(["Все цеха", "Упаковка", "Коптильный", "Сушка", "Сычужный", "Сыр цех", "Адыгейский"])
        toolbar.addWidget(QLabel("Цех: "))
        toolbar.addWidget(self.workshop_box)
        toolbar.addWidget(QLabel(f"  Пользователь: {getattr(self.session, 'username', '') or (self.session or {}).get('username','')}"))
        self.tabs = QTabWidget()
        for title, widget in [("Наряды", self._orders()), ("Сотрудники", self._table("Сотрудники")),
                              ("Мастера", self._table("Мастера")), ("Подразделения", self._table("Подразделения")),
                              ("Работы", self._table("Номенклатура и работы")), ("Аналитика", self._analytics()),
                              ("Администрирование", self._table("Настройки и журнал действий")),
                              ("Центр безопасности", self._security_center())]:
            self.tabs.addTab(widget, title)
        layout.addWidget(self.tabs)
        self.setCentralWidget(root)

    def _orders(self):
        w, l = QWidget(), QVBoxLayout()
        buttons = QHBoxLayout()
        create = QPushButton("Создать наряд"); create.clicked.connect(self._create_order); buttons.addWidget(create)
        edit = QPushButton("Редактировать"); edit.clicked.connect(self._edit_order); buttons.addWidget(edit)
        export = QPushButton("Экспорт Excel"); export.clicked.connect(self._export_orders); buttons.addWidget(export)
        backup = QPushButton("Резервная копия"); backup.clicked.connect(self._backup); buttons.addWidget(backup)
        buttons.addStretch(1)
        l.addLayout(buttons)
        self.order_filter = QLineEdit(); self.order_filter.setPlaceholderText("Фильтр: номер, мастер, подразделение или комментарий"); self.order_filter.returnPressed.connect(self._refresh_orders); l.addWidget(self.order_filter)
        table = QTableWidget(0, 7)
        table.setHorizontalHeaderLabels(["№", "Дата", "Смена", "Мастер", "Подразделение", "Статус", "Изменено"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.orders_table = table
        l.addWidget(table)
        self._refresh_orders()
        return w

    def _table(self, title):
        w, l = QWidget(), QVBoxLayout(); l.addWidget(QLabel(title))
        table = QTableWidget(0, 3); table.setHorizontalHeaderLabels(["ID", "Название", "Статус"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); l.addWidget(table)
        return w

    def _analytics(self):
        w, l = QWidget(), QVBoxLayout(); w.setProperty("fixed_scale", True)
        label = QLabel("Аналитика\nПериод, количество нарядов, сотрудники и выплаты")
        f = label.font(); f.setPointSizeF(10.0); label.setFont(f)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(label); return w

    def _security_center(self):
        w, l = QWidget(), QVBoxLayout(); label = QLabel()
        label.setWordWrap(True)
        if self.session is not None and hasattr(self.session, "can") and not self.session.can("admin.view"):
            label.setText("Центр безопасности доступен только администраторам."); l.addWidget(label); return w
        try:
            from ..services.security_center import SecurityCenter
            if isinstance(self.services, dict) and self.services.get("db") and self.services.get("config"):
                status = SecurityCenter(self.services["db"], self.services["config"]).status()
                label.setText("\n".join(f"{key}: {value}" for key, value in status.items()))
            else: label.setText("Центр безопасности доступен после авторизации")
        except Exception as exc: label.setText(f"Проверка статуса недоступна: {exc}")
        l.addWidget(label); l.addStretch(1); return w

    def _apply_scale(self, value):
        app = self.window().windowHandle()
        from PySide6.QtWidgets import QApplication
        QApplication.instance().setProperty("smartorder_scale", value)
        font = self.font(); font.setPointSizeF(10 * value); self.setFont(font)
        # Analytics has a stable internal scale by design.
        if self.tabs.count() > 5:
            analytics = self.tabs.widget(5); analytics.setStyleSheet("font-size: 10pt;")

    def _refresh_orders(self):
        repo = None
        if isinstance(self.services, dict) and self.services.get("db") is not None:
            from ..repositories.orders import OrderRepository
            repo = OrderRepository(self.services["db"])
        if repo is None or not hasattr(self, "orders_table"): return
        try: rows = repo.list(text=self.order_filter.text().strip() if hasattr(self, "order_filter") else "", limit=500)
        except Exception: rows = []
        self.orders_table.setRowCount(len(rows))
        fields = ("order_no", "order_date", "shift_type", "master_name", "department_name", "status", "updated_at")
        for i, row in enumerate(rows):
            for j, field in enumerate(fields): self.orders_table.setItem(i, j, QTableWidgetItem(str(row.get(field) or "")))
        self.orders_table.resizeRowsToContents()

    def _create_order(self):
        from .dialogs.order_dialog import OrderDialog
        dialog = OrderDialog(self)
        if not dialog.exec(): return
        data, items = dialog.payload()
        if isinstance(self.services, dict) and self.services.get("db") is not None:
            from ..repositories.orders import OrderRepository
            try: OrderRepository(self.services["db"]).create(data, items, getattr(self.session, "user_id", None))
            except Exception: pass
        self._refresh_orders()

    def _edit_order(self):
        if hasattr(self, "orders_table") and self.orders_table.currentRow() >= 0: self._create_order()

    def _export_orders(self):
        from .dialogs.excel_dialog import ExcelDialog
        ExcelDialog(parent=self).exec()

    def _backup(self):
        from .dialogs.backup_dialog import BackupDialog
        service = None
        if isinstance(self.services, dict) and self.services.get("db") is not None:
            from ..services.backup import BackupService
            service = BackupService(self.services["db"], self.services["config"])
        BackupDialog(service, self).exec()

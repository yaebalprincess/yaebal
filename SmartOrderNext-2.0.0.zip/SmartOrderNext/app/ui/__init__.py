"""Qt user interface for SmartOrderNext."""

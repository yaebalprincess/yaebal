from __future__ import annotations

class CatalogRepository:
    def __init__(self, db): self.db = db
    def employees(self, active_only=True):
        where = " WHERE deleted_at IS NULL" if active_only else ""
        with self.db.connect() as c: return [dict(r) for r in c.execute("SELECT * FROM employees" + where + " ORDER BY full_name").fetchall()]
    def departments(self, workshop_id=None, active_only=True):
        clauses = []; params = []
        if workshop_id is not None: clauses.append("workshop_id=?"); params.append(workshop_id)
        if active_only: clauses.append("deleted_at IS NULL")
        with self.db.connect() as c: return [dict(r) for r in c.execute("SELECT * FROM departments" + (" WHERE " + " AND ".join(clauses) if clauses else "") + " ORDER BY name", params).fetchall()]
    def work_types(self, active_only=True):
        with self.db.connect() as c: return [dict(r) for r in c.execute("SELECT * FROM work_types" + (" WHERE deleted_at IS NULL" if active_only else "") + " ORDER BY name").fetchall()]

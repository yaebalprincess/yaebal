from __future__ import annotations

class UserRepository:
    def __init__(self, db): self.db = db
    def list(self):
        with self.db.connect() as c: return [dict(r) for r in c.execute("SELECT u.id,u.username,u.display_name,u.is_active,r.name role,u.must_change_password FROM users u JOIN roles r ON r.id=u.role_id WHERE u.deleted_at IS NULL ORDER BY u.username").fetchall()]
    def set_active(self, user_id: int, active: bool):
        with self.db.transaction() as c: c.execute("UPDATE users SET is_active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (int(active), user_id))

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from decimal import Decimal

@dataclass
class User: id: int; username: str; role: str; is_active: bool = True
@dataclass
class WorkOrder: id: int; order_no: str; order_date: str; status: str = "saved"; version: str = "1"

class OrderRepository:
    def __init__(self, db): self.db = db

    def list(self, workshop_id=None, order_date=None, date_from=None, date_to=None, text="", include_deleted=False, limit=1000):
        sql = "SELECT o.*,e.full_name AS master_name,d.name AS department_name FROM work_orders o LEFT JOIN employees e ON e.id=o.master_id LEFT JOIN departments d ON d.id=o.department_id WHERE 1=1"; params = []
        if workshop_id is not None: sql += " AND o.workshop_id=?"; params.append(workshop_id)
        if order_date: sql += " AND o.order_date=?"; params.append(order_date)
        if date_from: sql += " AND o.order_date>=?"; params.append(date_from)
        if date_to: sql += " AND o.order_date<=?"; params.append(date_to)
        if not include_deleted: sql += " AND o.deleted_at IS NULL"
        if text: sql += " AND (o.order_no LIKE ? OR COALESCE(o.comment,'') LIKE ? OR COALESCE(e.full_name,'') LIKE ?)"; params.extend([f"%{text}%"] * 3)
        sql += " ORDER BY o.order_date DESC,o.id DESC LIMIT ?"; params.append(max(1, min(5000, int(limit))))
        with self.db.connect() as c: return [dict(r) for r in c.execute(sql, params).fetchall()]

    def get(self, order_id: int) -> dict | None:
        with self.db.connect() as c:
            order = c.execute("SELECT * FROM work_orders WHERE id=?", (order_id,)).fetchone()
            if not order: return None
            items = c.execute("SELECT * FROM work_order_items WHERE order_id=? ORDER BY sort_order,id", (order_id,)).fetchall()
        return {"data": dict(order), "items": [dict(r) for r in items]}

    @staticmethod
    def _snapshot(data, items): return json.dumps({"data": data, "items": items}, ensure_ascii=False, sort_keys=True, default=str)

    def create(self, data: dict, items: list[dict], user_id: int | None = None) -> int:
        with self.db.transaction() as c:
            cur = c.execute("INSERT INTO work_orders(workshop_id,order_no,order_date,shift_type,master_id,department_id,comment,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?)", (data.get("workshop_id"), str(data["order_no"]), str(data["order_date"]), data.get("shift_type", ""), data.get("master_id"), data.get("department_id"), data.get("comment", ""), user_id, user_id)); oid = int(cur.lastrowid)
            self._insert_items(c, oid, items)
            c.execute("INSERT INTO order_history(order_id,version,action,snapshot_json,changed_by) VALUES(?,?,?,?,?)", (oid, "1", "create", self._snapshot(data, items), user_id)); return oid

    def update(self, order_id: int, data: dict, items: list[dict], user_id: int | None = None) -> int:
        with self.db.transaction() as c:
            old = c.execute("SELECT * FROM work_orders WHERE id=?", (order_id,)).fetchone()
            if not old: raise KeyError(order_id)
            version = str(old["version"]); base, _, revision = version.partition("."); next_version = f"{base}.{int(revision or 0) + 1}"
            cur = c.execute("INSERT INTO work_orders(order_no,workshop_id,department_id,master_id,order_date,shift_type,status,version,parent_id,comment,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (data.get("order_no", old["order_no"]), data.get("workshop_id", old["workshop_id"]), data.get("department_id", old["department_id"]), data.get("master_id", old["master_id"]), data.get("order_date", old["order_date"]), data.get("shift_type", old["shift_type"]), "saved", next_version, order_id, data.get("comment", old["comment"]), old["created_by"], user_id)); new_id = int(cur.lastrowid)
            self._insert_items(c, new_id, items)
            c.execute("INSERT INTO order_history(order_id,version,action,snapshot_json,changed_by) VALUES(?,?,?,?,?)", (new_id, next_version, "edit", self._snapshot(data, items), user_id)); return new_id

    @staticmethod
    def _insert_items(c, order_id, items):
        for index, item in enumerate(items):
            c.execute("INSERT INTO work_order_items(order_id,employee_id,work_type_id,employee_name_snapshot,work_name_snapshot,work_code_snapshot,quantity,hours,fixed_boxes,fixed_weight,actual_value,price,amount,note,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (order_id, item.get("employee_id"), item.get("work_type_id"), item.get("employee_name_snapshot", item.get("employee_name", "")), item.get("work_name_snapshot", item.get("work_name", "")), item.get("work_code_snapshot", item.get("work_code", "")), item.get("quantity"), item.get("hours"), item.get("fixed_boxes"), item.get("fixed_weight"), item.get("actual_value"), item.get("price"), item.get("amount"), item.get("note", ""), item.get("sort_order", index)))

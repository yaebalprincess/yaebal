"""SQLite access layer configured for local and SMB/UNC deployments."""
from __future__ import annotations

import hashlib
import os
import shutil
import sqlite3
import time
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

PERMISSIONS = (
    ("orders.view", "Просмотр нарядов"), ("orders.create", "Создание нарядов"),
    ("orders.edit", "Редактирование нарядов"), ("orders.export", "Экспорт нарядов"),
    ("catalog.view", "Просмотр номенклатуры"), ("catalog.edit", "Изменение номенклатуры"),
    ("employees.view", "Просмотр сотрудников"), ("employees.edit", "Изменение сотрудников"),
    ("admin.view", "Администрирование"), ("users.manage", "Пользователи"),
    ("audit.view", "Журнал действий"), ("backup.manage", "Резервные копии"),
    ("analytics.view", "Аналитика"), ("analytics.export", "Экспорт аналитики"),
)
ROLE_PERMISSIONS = {
    "admin": {p[0] for p in PERMISSIONS},
    "accountant": {"orders.view", "orders.export", "catalog.view", "catalog.edit", "analytics.view", "analytics.export", "backup.manage", "audit.view"},
    "economist": {"orders.view", "orders.export", "catalog.view", "catalog.edit", "analytics.view", "analytics.export", "backup.manage", "audit.view"},
    "master": {"orders.view", "orders.create", "orders.edit", "orders.export", "employees.view", "employees.edit"},
    "viewer": {"orders.view"},
}
WORKSHOPS = (("packaging", "Упаковка"), ("smoking", "Коптильный цех"), ("drying", "Сушка"), ("rennet", "Сычужный цех"), ("cheese", "Сыр цех"), ("adyghe", "Адыгейский цех"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS roles(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,description TEXT NOT NULL DEFAULT '',is_system INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS permissions(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,description TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS role_permissions(role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,PRIMARY KEY(role_id,permission_id));
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,display_name TEXT NOT NULL DEFAULT '',password_hash TEXT NOT NULL,role_id INTEGER NOT NULL REFERENCES roles(id),is_active INTEGER NOT NULL DEFAULT 1,failed_attempts INTEGER NOT NULL DEFAULT 0,locked_until TEXT,must_change_password INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT);
CREATE TABLE IF NOT EXISTS workshops(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,name TEXT UNIQUE NOT NULL,is_active INTEGER NOT NULL DEFAULT 1,settings_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY AUTOINCREMENT,workshop_id INTEGER REFERENCES workshops(id),code TEXT,name TEXT NOT NULL,is_active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT,UNIQUE(workshop_id,name));
CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY AUTOINCREMENT,personnel_no TEXT UNIQUE,full_name TEXT NOT NULL,department_id INTEGER REFERENCES departments(id),position TEXT NOT NULL DEFAULT '',is_master INTEGER NOT NULL DEFAULT 0,is_active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT);
CREATE TABLE IF NOT EXISTS work_types(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,name TEXT NOT NULL,unit TEXT NOT NULL DEFAULT '',price REAL NOT NULL DEFAULT 0,is_active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT);
CREATE TABLE IF NOT EXISTS work_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,order_no TEXT NOT NULL,workshop_id INTEGER REFERENCES workshops(id),department_id INTEGER REFERENCES departments(id),master_id INTEGER REFERENCES employees(id),order_date TEXT NOT NULL,due_date TEXT,shift_type TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'saved',version TEXT NOT NULL DEFAULT '1',parent_id INTEGER REFERENCES work_orders(id),comment TEXT NOT NULL DEFAULT '',created_by INTEGER REFERENCES users(id),updated_by INTEGER REFERENCES users(id),integrity_hmac TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT,UNIQUE(workshop_id,order_no,version));
CREATE TABLE IF NOT EXISTS work_order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,employee_id INTEGER REFERENCES employees(id),work_type_id INTEGER REFERENCES work_types(id),employee_name_snapshot TEXT NOT NULL DEFAULT '',work_name_snapshot TEXT NOT NULL DEFAULT '',work_code_snapshot TEXT NOT NULL DEFAULT '',quantity REAL,hours REAL,fixed_boxes REAL,fixed_weight REAL,actual_value REAL,price REAL,amount REAL,note TEXT NOT NULL DEFAULT '',sort_order INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS order_history(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,version TEXT NOT NULL,action TEXT NOT NULL,snapshot_json TEXT NOT NULL,integrity_hmac TEXT,changed_by INTEGER REFERENCES users(id),changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS backups(id INTEGER PRIMARY KEY AUTOINCREMENT,path TEXT NOT NULL,sha256 TEXT NOT NULL,hmac TEXT,created_by INTEGER REFERENCES users(id),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,size_bytes INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'ok',metadata_json TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER REFERENCES users(id),action TEXT NOT NULL,entity_type TEXT,entity_id INTEGER,details_json TEXT,ip_address TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,is_secret INTEGER NOT NULL DEFAULT 0,updated_by INTEGER REFERENCES users(id),updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,last_seen_at TEXT NOT NULL,host TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS idx_orders_date ON work_orders(order_date);CREATE INDEX IF NOT EXISTS idx_orders_workshop ON work_orders(workshop_id);CREATE INDEX IF NOT EXISTS idx_items_order ON work_order_items(order_id);CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
"""

class Database:
    def __init__(self, path: str | Path, timeout: float = 15.0):
        self.path = Path(path).expanduser(); self.timeout = max(1.0, float(timeout))
        self.path.parent.mkdir(parents=True, exist_ok=True); self.initialize()

    def connect(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.path), timeout=self.timeout, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON"); c.execute(f"PRAGMA busy_timeout={int(self.timeout * 1000)}")
        c.execute("PRAGMA journal_mode=DELETE"); c.execute("PRAGMA synchronous=FULL")
        return c

    def initialize(self) -> None:
        with self.connect() as c:
            c.executescript(SCHEMA)
            for name, description in (("admin", "Администратор"), ("accountant", "Бухгалтер"), ("economist", "Экономист"), ("master", "Мастер"), ("viewer", "Просмотр")):
                c.execute("INSERT OR IGNORE INTO roles(name,description) VALUES(?,?)", (name, description))
            for code, description in PERMISSIONS:
                c.execute("INSERT OR IGNORE INTO permissions(code,description) VALUES(?,?)", (code, description))
            rids = {r["name"]: r["id"] for r in c.execute("SELECT id,name FROM roles")}; pids = {r["code"]: r["id"] for r in c.execute("SELECT id,code FROM permissions")}
            for role, codes in ROLE_PERMISSIONS.items():
                for code in codes: c.execute("INSERT OR IGNORE INTO role_permissions(role_id,permission_id) VALUES(?,?)", (rids[role], pids[code]))
            c.commit()

    @contextmanager
    def transaction(self, retries: int = 5) -> Iterator[sqlite3.Connection]:
        c = self.connect(); began = False
        try:
            for attempt in range(max(1, retries)):
                try:
                    c.execute("BEGIN IMMEDIATE"); began = True; break
                except sqlite3.OperationalError as exc:
                    if "locked" not in str(exc).lower() or attempt + 1 >= retries: raise
                    time.sleep(0.05 * (attempt + 1))
            if not began: raise sqlite3.OperationalError("Не удалось начать транзакцию")
            try:
                yield c
                c.commit()
            except Exception:
                c.rollback(); raise
        finally:
            c.close()

    def backup(self, target_dir: str | Path, created_by: int | None = None) -> Path:
        target = Path(target_dir).expanduser(); target.mkdir(parents=True, exist_ok=True); stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        tmp = target / f".smartorder_{stamp}_{os.getpid()}.db.tmp"; final = target / f"smartorder_{stamp}.db"
        source = self.connect(); destination = sqlite3.connect(str(tmp))
        try: source.backup(destination); destination.commit()
        finally: destination.close(); source.close()
        with tmp.open("rb") as fh: os.fsync(fh.fileno())
        os.replace(tmp, final); return final

    def restore(self, backup_path: str | Path) -> None:
        backup = Path(backup_path)
        with sqlite3.connect(str(backup)) as check:
            if check.execute("PRAGMA integrity_check").fetchone()[0] != "ok": raise ValueError("Повреждённая резервная копия")
        tmp = self.path.with_name(self.path.name + ".restore.tmp"); shutil.copy2(backup, tmp)
        with tmp.open("rb") as fh: os.fsync(fh.fileno())
        os.replace(tmp, self.path); self.initialize()

    @staticmethod
    def sha256(path: str | Path) -> str:
        h = hashlib.sha256()
        with Path(path).open("rb") as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b""): h.update(chunk)
        return h.hexdigest()

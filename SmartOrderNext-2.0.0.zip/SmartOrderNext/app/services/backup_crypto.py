"""Optional authenticated encryption for exported backup files.

The encryption key is kept outside the database. Production Windows builds
should place it in DPAPI/Credential Manager; the file fallback is restricted
to the local application profile for development and small installations.
"""
from __future__ import annotations

import os
from pathlib import Path

from ..security import load_hmac_key

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except Exception:  # optional until the encrypted-backup feature is enabled
    AESGCM = None

MAGIC = b"SMARTORDER-AESGCM\x01"

def encrypt_file(source: str | Path, target: str | Path, key_path: str | Path) -> Path:
    if AESGCM is None: raise RuntimeError("Для шифрования резервных копий нужен пакет cryptography")
    key = load_hmac_key(Path(key_path)); nonce = os.urandom(12); payload = Path(source).read_bytes(); encrypted = AESGCM(key).encrypt(nonce, payload, MAGIC)
    target = Path(target); target.parent.mkdir(parents=True, exist_ok=True); tmp = target.with_suffix(target.suffix + ".tmp"); tmp.write_bytes(MAGIC + nonce + encrypted); os.replace(tmp, target)
    try: target.chmod(0o600)
    except OSError: pass
    return target

def decrypt_file(source: str | Path, target: str | Path, key_path: str | Path) -> Path:
    if AESGCM is None: raise RuntimeError("Для расшифровки резервных копий нужен пакет cryptography")
    raw = Path(source).read_bytes()
    if not raw.startswith(MAGIC) or len(raw) < len(MAGIC) + 12 + 16: raise ValueError("Неверный формат зашифрованной копии")
    key = load_hmac_key(Path(key_path), create=False); nonce_start = len(MAGIC); plaintext = AESGCM(key).decrypt(raw[nonce_start:nonce_start + 12], raw[nonce_start + 12:], MAGIC)
    target = Path(target); target.parent.mkdir(parents=True, exist_ok=True); tmp = target.with_suffix(target.suffix + ".tmp"); tmp.write_bytes(plaintext); os.replace(tmp, target); return target

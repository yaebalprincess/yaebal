from __future__ import annotations

from ..repositories.orders import OrderRepository

class OrderService:
    def __init__(self, db, auth=None): self.repo = OrderRepository(db); self.auth = auth
    def list(self, session, **filters):
        if self.auth: self.auth.require(session, "orders.view")
        return self.repo.list(**filters)
    def create(self, session, data, items):
        if self.auth: self.auth.require(session, "orders.create")
        return self.repo.create(data, items, session.user_id if session else None)
    def edit(self, session, order_id, data, items):
        if self.auth: self.auth.require(session, "orders.edit")
        return self.repo.update(order_id, data, items, session.user_id if session else None)

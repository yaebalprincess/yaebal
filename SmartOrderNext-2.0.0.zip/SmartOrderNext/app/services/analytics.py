from __future__ import annotations

from datetime import date

class AnalyticsService:
    def __init__(self, db): self.db = db

    def summary(self, workshop_id=None, date_from=None, date_to=None) -> dict:
        where = ["o.deleted_at IS NULL"]; params = []
        if workshop_id is not None: where.append("o.workshop_id=?"); params.append(workshop_id)
        if date_from: where.append("o.order_date>=?"); params.append(str(date_from))
        if date_to: where.append("o.order_date<=?"); params.append(str(date_to))
        clause = " AND ".join(where)
        query = f"SELECT COUNT(DISTINCT o.id) AS orders, COALESCE(SUM(i.amount),0) AS amount, COUNT(DISTINCT i.employee_id) AS employees FROM work_orders o LEFT JOIN work_order_items i ON i.order_id=o.id WHERE {clause}"
        with self.db.connect() as c: return dict(c.execute(query, params).fetchone())

    def by_employee(self, workshop_id=None, date_from=None, date_to=None) -> list[dict]:
        where = ["o.deleted_at IS NULL"]; params = []
        if workshop_id is not None: where.append("o.workshop_id=?"); params.append(workshop_id)
        if date_from: where.append("o.order_date>=?"); params.append(str(date_from))
        if date_to: where.append("o.order_date<=?"); params.append(str(date_to))
        with self.db.connect() as c:
            rows = c.execute(f"SELECT COALESCE(i.employee_name_snapshot,e.full_name,'') employee,COUNT(DISTINCT o.id) orders,COALESCE(SUM(i.amount),0) amount,COALESCE(SUM(i.hours),0) hours FROM work_orders o LEFT JOIN work_order_items i ON i.order_id=o.id LEFT JOIN employees e ON e.id=i.employee_id WHERE {' AND '.join(where)} GROUP BY COALESCE(i.employee_id,i.employee_name_snapshot) ORDER BY employee", params).fetchall()
        return [dict(row) for row in rows]

import json
from pathlib import Path
from ..security import sign_file,verify_file,load_hmac_key
def write_snapshot(data,path,key_path):
 p=Path(path); p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8'); sig=sign_file(p,load_hmac_key(Path(key_path))); p.with_suffix(p.suffix+'.hmac').write_text(sig,encoding='ascii'); return p
def verify_snapshot(path,key_path):
 p=Path(path); sig=p.with_suffix(p.suffix+'.hmac')
 if not p.is_file() or not sig.is_file(): return False
 try: return verify_file(p,sig.read_text(encoding='ascii').strip(),load_hmac_key(Path(key_path),create=False))
 except (OSError,ValueError): return False

"""One way importer from SmartOrder 1.x SQLite databases.

The source is opened read-only in spirit: this service never alters it.  IDs
are mapped explicitly because old databases used different integer spaces and
stored order revisions as strings such as ``1.1``.
"""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

from ..security import hash_password
from .auth import normalize_role

class LegacyImporter:
    def __init__(self, target): self.target = target

    @staticmethod
    def _rows(src, table):
        try: return src.execute(f"SELECT * FROM {table}").fetchall()
        except sqlite3.Error: return []

    @staticmethod
    def _value(row, *names, default=None):
        for name in names:
            if name in row.keys() and row[name] is not None: return row[name]
        return default

    def import_db(self, legacy_path: str | Path, dry_run: bool = False) -> dict:
        source_path = Path(legacy_path)
        src = sqlite3.connect(f"file:{source_path.resolve()}?mode=ro", uri=True); src.row_factory = sqlite3.Row
        report = {"dry_run": bool(dry_run), "source": str(source_path), "tables": {}, "warnings": [], "users": 0, "employees": 0, "departments": 0, "work_types": 0, "work_orders": 0, "work_order_items": 0, "order_history": 0, "app_settings": 0}
        tables = ("users", "employees", "departments", "work_types", "work_orders", "work_order_items", "work_order_layout_rows", "order_history", "app_settings", "settings", "workshop_settings", "workshops")
        all_rows = {table: self._rows(src, table) for table in tables}
        for table, rows in all_rows.items(): report["tables"][table] = len(rows)
        if dry_run:
            src.close(); return report

        with self.target.transaction() as dst:
            role_cache = {r["name"]: r["id"] for r in dst.execute("SELECT id,name FROM roles")}
            for row in all_rows["workshops"]:
                code = str(self._value(row, "code", "key", default="legacy")); name = str(self._value(row, "name", "title", default=code))
                try: dst.execute("INSERT OR IGNORE INTO workshops(code,name,settings_json) VALUES(?,?,?)", (code, name, json.dumps(dict(row), ensure_ascii=False, default=str)))
                except sqlite3.IntegrityError: pass
            dst.execute("INSERT OR IGNORE INTO workshops(code,name) VALUES('packaging','Упаковка')")
            workshop = dst.execute("SELECT id FROM workshops WHERE code='packaging'").fetchone()[0]
            employee_ids: dict[int, int] = {}; department_ids: dict[int, int] = {}; work_ids: dict[int, int] = {}; order_ids: dict[int, int] = {}

            for row in all_rows["users"]:
                username = str(self._value(row, "username", "login", "name", default="")).strip()
                if not username: continue
                old_role = self._value(row, "role", "role_name", default="viewer")
                role = normalize_role(str(old_role)); role_id = role_cache.get(role, role_cache["viewer"])
                password_hash = str(self._value(row, "password_hash", "password", default=""))
                safe_hash = password_hash if password_hash.startswith(("$argon2", "scrypt$")) else hash_password("RESET_REQUIRED_" + username)
                if safe_hash != password_hash: report["warnings"].append(f"{username}: пароль требует сброса")
                dst.execute("INSERT OR IGNORE INTO users(username,display_name,password_hash,role_id,is_active,must_change_password) VALUES(?,?,?,?,?,?)", (username, str(self._value(row, "display_name", "full_name", default=username)), safe_hash, role_id, int(self._value(row, "is_active", default=1) or 0), int(safe_hash != password_hash)))
                report["users"] += 1

            for row in all_rows["departments"]:
                old_id = int(self._value(row, "id", default=0) or 0); name = str(self._value(row, "name", "title", default=f"Подразделение {old_id}"))
                cur = dst.execute("INSERT OR IGNORE INTO departments(workshop_id,code,name) VALUES(?,?,?)", (workshop, str(old_id), name)); found = dst.execute("SELECT id FROM departments WHERE workshop_id=? AND name=?", (workshop, name)).fetchone();
                if found: department_ids[old_id] = int(found[0])
                report["departments"] += 1

            for row in all_rows["employees"]:
                old_id = int(self._value(row, "id", default=0) or 0); name = str(self._value(row, "full_name", "name", "employee_name", default=f"Сотрудник {old_id}"))
                dep = department_ids.get(int(self._value(row, "department_id", default=0) or 0)); cur = dst.execute("INSERT OR IGNORE INTO employees(full_name,department_id,is_master,is_active) VALUES(?,?,?,?)", (name, dep, int(self._value(row, "is_master", default=0) or 0), int(self._value(row, "is_active", default=1) or 0))); found = dst.execute("SELECT id FROM employees WHERE full_name=? AND COALESCE(department_id,0)=COALESCE(?,0)", (name, dep)).fetchone();
                if found: employee_ids[old_id] = int(found[0])
                report["employees"] += 1

            for row in all_rows["work_types"]:
                old_id = int(self._value(row, "id", default=0) or 0); name = str(self._value(row, "name", "title", default=f"Работа {old_id}")); code = str(self._value(row, "code", default=f"LEGACY-{old_id}")) or f"LEGACY-{old_id}"
                try: dst.execute("INSERT OR IGNORE INTO work_types(code,name,unit,price,is_active) VALUES(?,?,?,?,?)", (code, name, str(self._value(row, "unit", default="")), float(self._value(row, "price", default=0) or 0), int(self._value(row, "is_active", default=1) or 0)))
                except sqlite3.IntegrityError: pass
                found = dst.execute("SELECT id FROM work_types WHERE code=?", (code,)).fetchone();
                if found: work_ids[old_id] = int(found[0])
                report["work_types"] += 1

            for row in all_rows["work_orders"]:
                old_id = int(self._value(row, "id", default=0) or 0); version = str(self._value(row, "version", default="1")); number = str(self._value(row, "order_no", "number", default=version)); master = employee_ids.get(int(self._value(row, "master_id", default=0) or 0)); dep = department_ids.get(int(self._value(row, "department_id", default=0) or 0)); date = str(self._value(row, "order_date", "date", default="")); parent = order_ids.get(int(self._value(row, "parent_id", default=0) or 0));
                cur = dst.execute("INSERT OR IGNORE INTO work_orders(order_no,workshop_id,department_id,master_id,order_date,shift_type,status,version,parent_id,comment,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (number, workshop, dep, master, date, str(self._value(row, "shift_type", "shift", default="")), str(self._value(row, "status", default="saved")), version, parent, str(self._value(row, "comment", default="")), None, None)); found = dst.execute("SELECT id FROM work_orders WHERE workshop_id=? AND order_no=? AND version=?", (workshop, number, version)).fetchone();
                if found: order_ids[old_id] = int(found[0])
                report["work_orders"] += 1

            item_rows = all_rows["work_order_items"] + all_rows["work_order_layout_rows"]
            for index, row in enumerate(item_rows):
                order = order_ids.get(int(self._value(row, "order_id", default=0) or 0));
                if not order: continue
                employee = employee_ids.get(int(self._value(row, "employee_id", default=0) or 0)); work = work_ids.get(int(self._value(row, "work_type_id", default=0) or 0));
                dst.execute("INSERT INTO work_order_items(order_id,employee_id,work_type_id,employee_name_snapshot,work_name_snapshot,work_code_snapshot,quantity,hours,fixed_boxes,fixed_weight,actual_value,price,amount,note,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (order, employee, work, str(self._value(row, "employee_name_snapshot", default="")), str(self._value(row, "work_name_snapshot", default="")), str(self._value(row, "work_code_snapshot", default="")), self._value(row, "quantity", "fixed_total"), self._value(row, "hours"), self._value(row, "fixed_boxes"), self._value(row, "fixed_weight"), self._value(row, "actual_value"), self._value(row, "price_snapshot", "price"), self._value(row, "payment", "amount"), str(self._value(row, "note", default="")), index)); report["work_order_items"] += 1

            for row in all_rows["order_history"]:
                order = order_ids.get(int(self._value(row, "order_id", default=0) or 0));
                if not order: continue
                snapshot = self._value(row, "snapshot_json", "details", default="{}")
                if not isinstance(snapshot, str): snapshot = json.dumps(dict(row), ensure_ascii=False, default=str)
                dst.execute("INSERT INTO order_history(order_id,version,action,snapshot_json,changed_by) VALUES(?,?,?,?,?)", (order, str(self._value(row, "version", default="1")), str(self._value(row, "action", default="import")), snapshot, None)); report["order_history"] += 1

            for row in all_rows["app_settings"] + all_rows["settings"] + all_rows["workshop_settings"]:
                key = self._value(row, "key", "name"); value = self._value(row, "value", default="")
                if key: dst.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES(?,?)", (str(key), str(value))); report["app_settings"] += 1
        src.close(); return report

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Импорт SmartOrder 1.x")
    parser.add_argument("legacy"); parser.add_argument("target"); parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    from ..database import Database
    report = LegacyImporter(Database(args.target)).import_db(args.legacy, args.dry_run); print(json.dumps(report, ensure_ascii=False, indent=2)); return 0

if __name__ == "__main__": raise SystemExit(main())

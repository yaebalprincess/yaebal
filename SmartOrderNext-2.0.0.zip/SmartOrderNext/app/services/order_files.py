"""Signed .sorder publication for portable order snapshots."""
from __future__ import annotations

import json
import os
from pathlib import Path

from ..security import canonical_json, sign_file, verify_file

class OrderFileService:
    def __init__(self, key: bytes): self.key = key

    def publish(self, snapshot: dict, path: str | Path) -> Path:
        target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
        payload = canonical_json(snapshot); tmp = target.with_suffix(target.suffix + ".tmp")
        tmp.write_bytes(payload); os.replace(tmp, target)
        sig = target.with_suffix(target.suffix + ".hmac"); sig_tmp = sig.with_suffix(sig.suffix + ".tmp"); sig_tmp.write_text(sign_file(target, self.key), encoding="ascii"); os.replace(sig_tmp, sig)
        return target

    def read_verified(self, path: str | Path) -> dict:
        target = Path(path); sig = target.with_suffix(target.suffix + ".hmac")
        if not verify_file(target, sig.read_text(encoding="ascii"), self.key): raise ValueError("Нарушена целостность файла наряда")
        value = json.loads(target.read_text(encoding="utf-8"))
        if not isinstance(value, dict): raise ValueError("Некорректный формат .sorder")
        return value

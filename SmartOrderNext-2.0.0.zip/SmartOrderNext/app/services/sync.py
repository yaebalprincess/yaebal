from __future__ import annotations

import json
import os
import socket
import time
import uuid

class SyncService:
    """Lightweight shared-database heartbeat and change cursor."""
    def __init__(self, db, client_id: str | None = None): self.db = db; self.client_id = client_id or f"{socket.gethostname()}-{os.getpid()}-{uuid.uuid4().hex[:8]}"; self._cursor = 0
    def heartbeat(self, client_id: str | None = None, user_id: int | None = None):
        ident = client_id or self.client_id
        payload = json.dumps({"client_id": ident, "user_id": user_id, "host": socket.gethostname(), "pid": os.getpid(), "at": time.time()}, ensure_ascii=False)
        with self.db.transaction() as c: c.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP", (f"client:{ident}", payload))
        return ident
    def active_clients(self, max_age: int = 90) -> list[dict]:
        threshold = time.time() - max(1, int(max_age)); result = []
        with self.db.connect() as c: rows = c.execute("SELECT key,value FROM app_settings WHERE key LIKE 'client:%'").fetchall()
        for row in rows:
            try:
                payload = json.loads(row[1]);
                if float(payload.get("at", 0)) >= threshold: result.append(payload)
            except (ValueError, TypeError, json.JSONDecodeError): continue
        return result

from __future__ import annotations

from ..repositories.catalog import CatalogRepository

class EmployeeService:
    def __init__(self, db, auth=None): self.db = db; self.auth = auth; self.repo = CatalogRepository(db)
    def list(self, session):
        if self.auth: self.auth.require(session, "employees.view")
        return self.repo.employees()
    def add(self, session, full_name, department_id=None, is_master=False):
        if self.auth: self.auth.require(session, "employees.edit")
        with self.db.transaction() as c:
            return int(c.execute("INSERT INTO employees(full_name,department_id,is_master) VALUES(?,?,?)", (full_name.strip(), department_id, int(is_master))).lastrowid)

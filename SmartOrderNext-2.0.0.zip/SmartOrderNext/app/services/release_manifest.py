"""Signed release manifest verification for the portable package.

The public key is shipped with a trusted installer/launcher; the private key
never belongs in the application or the network share.
"""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path, PurePosixPath

from ..security import canonical_json

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    from cryptography.hazmat.primitives import serialization
except Exception:  # pragma: no cover - dependency is included in production requirements
    Ed25519PrivateKey = Ed25519PublicKey = serialization = None

def build_manifest(root: str | Path, version: str, include_suffixes: tuple[str, ...] = (".exe", ".dll", ".pyd", ".json")) -> dict:
    base = Path(root).resolve(); files = []
    for path in sorted(base.rglob("*")):
        if not path.is_file() or path.name in {"release.manifest.json", "release.manifest.sig"}: continue
        if include_suffixes and path.suffix.lower() not in include_suffixes: continue
        rel = path.relative_to(base).as_posix(); digest = hashlib.sha256(path.read_bytes()).hexdigest()
        files.append({"path": rel, "sha256": digest, "size": path.stat().st_size})
    return {"format": 1, "version": str(version), "files": files}

def sign_manifest(manifest: dict, private_key: bytes) -> str:
    if Ed25519PrivateKey is None: raise RuntimeError("Установите cryptography для подписи релиза")
    key = Ed25519PrivateKey.from_private_bytes(private_key) if len(private_key) == 32 else serialization.load_pem_private_key(private_key, password=None)
    return base64.b64encode(key.sign(canonical_json(manifest))).decode("ascii")

def verify_manifest(manifest: dict, signature: str, public_key: bytes) -> bool:
    if Ed25519PublicKey is None: return False
    try:
        key = Ed25519PublicKey.from_public_bytes(public_key) if len(public_key) == 32 else serialization.load_pem_public_key(public_key)
        key.verify(base64.b64decode(signature), canonical_json(manifest)); return True
    except Exception: return False

def verify_payload(root: str | Path, manifest: dict, reject_unlisted_suffixes: tuple[str, ...] = (".exe", ".dll", ".pyd")) -> list[str]:
    """Return mismatches; reject traversal and files that changed since signing."""
    base = Path(root).resolve(); mismatches = []; listed = set()
    for entry in manifest.get("files", []):
        rel = str(entry.get("path", "")); listed.add(rel); pure = PurePosixPath(rel)
        if pure.is_absolute() or ".." in pure.parts or "\\" in rel: mismatches.append(rel); continue
        path = (base / Path(*pure.parts)).resolve()
        if base not in path.parents and path != base: mismatches.append(rel); continue
        if not path.is_file() or path.stat().st_size != int(entry.get("size", -1)) or hashlib.sha256(path.read_bytes()).hexdigest().lower() != str(entry.get("sha256", "")).lower(): mismatches.append(rel)
    for path in base.rglob("*"):
        if path.is_file() and path.suffix.lower() in reject_unlisted_suffixes:
            rel = path.relative_to(base).as_posix()
            if rel not in listed: mismatches.append("UNLISTED:" + rel)
    return mismatches

def verify_release(root: str | Path, manifest: dict, signature: str, public_key: bytes) -> bool:
    return verify_manifest(manifest, signature, public_key) and not verify_payload(root, manifest)

def generate_keypair() -> tuple[bytes, bytes]:
    if Ed25519PrivateKey is None: raise RuntimeError("Установите cryptography для подписи релиза")
    private = Ed25519PrivateKey.generate(); public = private.public_key()
    return private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()), public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

from __future__ import annotations

from pathlib import Path

_FORMULA_PREFIXES = ("=", "+", "-", "@")

def _safe(value):
    if isinstance(value, str) and value.startswith(_FORMULA_PREFIXES): return "'" + value
    return value

def export_orders(rows, path: str | Path) -> Path:
    from openpyxl import Workbook
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook(); ws = wb.active; ws.title = "Наряды"
    if rows:
        keys = list(rows[0].keys()) if hasattr(rows[0], "keys") else []
        ws.append(keys)
        for row in rows: ws.append([_safe(row.get(k) if hasattr(row, "get") else "") for k in keys])
    ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
    for column in ws.columns:
        width = min(48, max(12, max(len(str(cell.value or "")) for cell in column) + 2)); ws.column_dimensions[column[0].column_letter].width = width
    wb.save(target); return target

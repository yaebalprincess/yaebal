"""Security Center data provider for administrators.

It reports observable facts only.  ACL and code-signing checks that require
Windows policy APIs remain explicit ``unknown`` values instead of a decorative
success indicator.
"""
from __future__ import annotations

import os
import platform
from pathlib import Path

class SecurityCenter:
    def __init__(self, db, config, auth=None): self.db = db; self.config = config; self.auth = auth
    def status(self) -> dict:
        with self.db.connect() as c:
            user_count = int(c.execute("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL").fetchone()[0]); active = int(c.execute("SELECT COUNT(*) FROM users WHERE is_active=1 AND deleted_at IS NULL").fetchone()[0]); last_backup = c.execute("SELECT path,created_at,status FROM backups ORDER BY id DESC LIMIT 1").fetchone()
        return {
            "application": "SmartOrderNext", "python": platform.python_version(), "platform": platform.platform(),
            "database_path": str(self.config.database_path), "network_database": self.config.is_network_path,
            "database_exists": self.config.database_path.is_file(), "database_acl": "unknown",
            "users": user_count, "active_users": active, "last_backup": dict(last_backup) if last_backup else None,
            "trusted_launch_policy": bool(os.environ.get("SMARTORDER_TRUSTED_ROOTS")), "release_signature": "external-release-check",
            "encryption_key_configured": bool(getattr(self.config, "backup_encryption_key_path", None)),
        }

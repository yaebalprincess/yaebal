"""Signed release manifest verification.

The private signing key never belongs in the client package.  Windows release
automation signs the canonical manifest externally; the client verifies it
before trusting a downloaded/update directory.
"""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

def canonical_manifest(manifest: dict) -> bytes:
    return json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

def build_manifest(root: str | Path, *, version: str, include_suffixes=(".py", ".pyd", ".dll", ".exe", ".json", ".txt")) -> dict:
    root = Path(root); files = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix.lower() in include_suffixes:
            digest = hashlib.sha256(path.read_bytes()).hexdigest(); files[str(path.relative_to(root)).replace("\\", "/")] = digest
    return {"format": 1, "version": str(version), "files": files}

def verify_manifest(root: str | Path, manifest: dict, public_key_pem: bytes, signature_b64: str) -> bool:
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        if public_key_pem.startswith(b"-----BEGIN"):
            public = serialization.load_pem_public_key(public_key_pem)
        else:
            public = Ed25519PublicKey.from_public_bytes(public_key_pem)
        public.verify(base64.b64decode(signature_b64), canonical_manifest(manifest))
        base = Path(root); expected = manifest.get("files", {})
        if not isinstance(expected, dict): return False
        for relative, digest in expected.items():
            path = (base / relative).resolve()
            if base.resolve() not in path.parents or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest: return False
        # A signed manifest also defines the executable surface. Unexpected
        # DLL/EXE/PYD files are rejected because they could be loaded before a
        # later application-level check runs.
        executable_suffixes = {".exe", ".dll", ".pyd"}
        listed = {str(name).replace("\\", "/") for name in expected}
        for candidate in base.rglob("*"):
            if candidate.is_file() and candidate.suffix.lower() in executable_suffixes and str(candidate.relative_to(base)).replace("\\", "/") not in listed:
                return False
        return True
    except Exception: return False

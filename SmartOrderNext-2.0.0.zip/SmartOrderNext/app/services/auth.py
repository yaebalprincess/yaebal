from __future__ import annotations

import hashlib
import socket
from datetime import datetime, timedelta, timezone

from ..database import ROLE_PERMISSIONS
from ..security import LoginGuard, Session, SessionStore, hash_password, needs_upgrade, validate_password, verify_password

ROLE_ALIASES = {
    "администратор": "admin", "бухгалтер": "accountant", "экономист": "economist", "мастер": "master", "просмотр": "viewer",
}

def normalize_role(value: str) -> str:
    text = str(value or "viewer").strip().lower()
    return ROLE_ALIASES.get(text, text if text in ROLE_PERMISSIONS else "viewer")

class AuthService:
    def __init__(self, db, max_attempts: int = 5, lockout_seconds: int = 300, session_ttl: int = 8 * 3600):
        self.db = db; self.max_attempts = max(1, int(max_attempts)); self.lockout_seconds = max(1, int(lockout_seconds)); self.guard = LoginGuard(self.max_attempts, self.lockout_seconds); self.sessions = SessionStore(session_ttl)

    def create_user(self, username: str, password: str, role: str = "viewer", display_name: str = "") -> int:
        username = str(username).strip()
        if not username: raise ValueError("Логин не может быть пустым")
        validate_password(password)
        role = normalize_role(role)
        with self.db.transaction() as c:
            row = c.execute("SELECT id FROM roles WHERE name=?", (role,)).fetchone()
            if not row: raise ValueError("Неизвестная роль")
            cur = c.execute("INSERT INTO users(username,display_name,password_hash,role_id) VALUES(?,?,?,?)", (username, display_name or username, hash_password(password), row[0]))
            return int(cur.lastrowid)

    def ensure_admin(self, username: str = "admin", password: str | None = None) -> int:
        with self.db.connect() as c:
            row = c.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
        if row: return int(row[0])
        if password is None:
            raise ValueError("Для первичной настройки задайте пароль администратора")
        user_id = self.create_user(username, password, "admin", "Администратор")
        with self.db.transaction() as c: c.execute("UPDATE users SET must_change_password=1 WHERE id=?", (user_id,))
        return user_id

    def _locked(self, row) -> bool:
        if not row["locked_until"]: return False
        try: return datetime.fromisoformat(str(row["locked_until"])).timestamp() > datetime.now(timezone.utc).timestamp()
        except ValueError: return False

    def login(self, username: str, password: str) -> Session | None:
        username = str(username).strip()
        if not username or not self.guard.allow(username): return None
        with self.db.connect() as c: row = c.execute("SELECT u.*,r.name role FROM users u JOIN roles r ON r.id=u.role_id WHERE lower(u.username)=lower(?) AND u.is_active=1 AND u.deleted_at IS NULL", (username,)).fetchone()
        if not row or self._locked(row) or not verify_password(password, row["password_hash"]):
            self.guard.failed(username)
            with self.db.transaction() as c:
                current = c.execute("SELECT failed_attempts FROM users WHERE id=?", (row["id"],)).fetchone() if row else None
                failures = int(current[0]) + 1 if current else 1
                locked = (datetime.now(timezone.utc) + timedelta(seconds=self.lockout_seconds)).isoformat() if failures >= self.max_attempts else None
                if row: c.execute("UPDATE users SET failed_attempts=?,locked_until=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (failures, locked, row["id"]))
            return None
        self.guard.success(username)
        with self.db.connect() as c:
            permissions = {r[0] for r in c.execute("SELECT p.code FROM permissions p JOIN role_permissions rp ON rp.permission_id=p.id WHERE rp.role_id=?", (row["role_id"],))}
        if needs_upgrade(row["password_hash"]):
            with self.db.transaction() as c: c.execute("UPDATE users SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (hash_password(password), row["id"]))
        with self.db.transaction() as c: c.execute("UPDATE users SET failed_attempts=0,locked_until=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?", (row["id"],))
        session = self.sessions.create(row["id"], row["username"], row["role"], permissions)
        with self.db.transaction() as c:
            c.execute("INSERT INTO sessions(token_hash,user_id,created_at,expires_at,last_seen_at,host) VALUES(?,?,?,?,CURRENT_TIMESTAMP,?)", (hashlib.sha256(session.token.encode()).hexdigest(), session.user_id, datetime.fromtimestamp(session.created_at, timezone.utc).isoformat(), datetime.fromtimestamp(session.expires_at, timezone.utc).isoformat(), socket.gethostname()))
        return session

    def active(self, session: Session | None) -> bool:
        if not session or not session.active() or self.sessions.get(session.token) is None: return False
        with self.db.connect() as c:
            row = c.execute("SELECT is_active,deleted_at FROM users WHERE id=?", (session.user_id,)).fetchone()
            token = c.execute("SELECT 1 FROM sessions WHERE token_hash=? AND datetime(expires_at)>CURRENT_TIMESTAMP", (hashlib.sha256(session.token.encode()).hexdigest(),)).fetchone()
        return bool(row and row["is_active"] and not row["deleted_at"] and token)

    def require(self, session: Session | None, permission: str) -> None:
        if not self.active(session) or not self.has_permission(session, permission): raise PermissionError(f"Недостаточно прав: {permission}")

    def has_permission(self, session: Session | None, permission: str) -> bool:
        if not session or not session.active() or self.sessions.get(session.token) is None: return False
        with self.db.connect() as c:
            row = c.execute("SELECT p.code FROM users u JOIN role_permissions rp ON rp.role_id=u.role_id JOIN permissions p ON p.id=rp.permission_id WHERE u.id=? AND u.is_active=1 AND u.deleted_at IS NULL AND p.code=?", (session.user_id, permission)).fetchone()
        if row: return True
        with self.db.connect() as c:
            role = c.execute("SELECT r.name FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?", (session.user_id,)).fetchone()
        return bool(role and str(role[0]).lower() in {"admin", "administrator", "администратор"})

    def change_password(self, session: Session, new_password: str, target_user_id: int | None = None) -> None:
        target = int(target_user_id or session.user_id)
        if target != session.user_id: self.require(session, "users.manage")
        validate_password(new_password)
        with self.db.transaction() as c:
            c.execute("UPDATE users SET password_hash=?,must_change_password=0,failed_attempts=0,locked_until=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?", (hash_password(new_password), target))
            c.execute("DELETE FROM sessions WHERE user_id=?", (target,))
        self.sessions.revoke_user(target)

    def set_user_active(self, session: Session, target_user_id: int, active: bool) -> None:
        self.require(session, "users.manage")
        with self.db.transaction() as c:
            c.execute("UPDATE users SET is_active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (int(active), int(target_user_id)))
            if not active: c.execute("DELETE FROM sessions WHERE user_id=?", (int(target_user_id),))
        if not active: self.sessions.revoke_user(target_user_id)

    def set_user_role(self, session: Session, target_user_id: int, role: str) -> None:
        self.require(session, "users.manage")
        role = normalize_role(role)
        with self.db.transaction() as c:
            row = c.execute("SELECT id FROM roles WHERE name=?", (role,)).fetchone()
            if not row: raise ValueError("Неизвестная роль")
            c.execute("UPDATE users SET role_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (row[0], int(target_user_id)))
            c.execute("DELETE FROM sessions WHERE user_id=?", (int(target_user_id),))
        self.sessions.revoke_user(target_user_id)

    def logout(self, session: Session | None) -> None:
        if session:
            self.sessions.revoke(session.token)
            with self.db.transaction() as c: c.execute("DELETE FROM sessions WHERE token_hash=?", (hashlib.sha256(session.token.encode()).hexdigest(),))

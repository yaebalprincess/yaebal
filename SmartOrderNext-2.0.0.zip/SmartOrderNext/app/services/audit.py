from __future__ import annotations

import json
from ..security import redact_diagnostics

class AuditService:
    def __init__(self, db): self.db = db
    def record(self, action: str, user_id: int | None = None, entity_type: str | None = None, entity_id: int | None = None, details=None, host: str = ""):
        payload = redact_diagnostics(details or {})
        with self.db.transaction() as c:
            c.execute("INSERT INTO audit_log(user_id,action,entity_type,entity_id,details_json,ip_address) VALUES(?,?,?,?,?,?)", (user_id, action, entity_type, entity_id, json.dumps(payload, ensure_ascii=False, default=str), host))
    def recent(self, limit: int = 200):
        with self.db.connect() as c: return [dict(r) for r in c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (max(1, min(5000, int(limit))),)).fetchall()]

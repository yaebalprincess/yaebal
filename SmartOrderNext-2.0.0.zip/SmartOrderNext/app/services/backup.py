from __future__ import annotations

import json
from pathlib import Path

from ..security import load_hmac_key, sign_file, verify_file
from .backup_crypto import decrypt_file, encrypt_file

class BackupService:
    def __init__(self, db, config):
        self.db = db; self.config = config; self.key = load_hmac_key(config.hmac_key_path)

    def create(self, user_id: int | None = None) -> Path:
        path = self.db.backup(self.config.backup_dir, user_id); digest = self.db.sha256(path); signature = sign_file(path, self.key)
        sig_path = path.with_suffix(path.suffix + ".sig"); tmp = sig_path.with_suffix(sig_path.suffix + ".tmp"); tmp.write_text(signature, encoding="ascii"); tmp.replace(sig_path)
        with self.db.transaction() as c:
            c.execute("INSERT INTO backups(path,sha256,hmac,created_by,size_bytes,metadata_json) VALUES(?,?,?,?,?,?)", (str(path), digest, signature, user_id, path.stat().st_size, json.dumps({"signature": str(sig_path)}, ensure_ascii=False)))
        return path

    def verify(self, backup_path: str | Path) -> bool:
        path = Path(backup_path); sig = path.with_suffix(path.suffix + ".sig")
        if path.suffix == ".enc": return self.verify_encrypted(path)
        return path.is_file() and sig.is_file() and self.db.sha256(path) == self._recorded_sha(path) and verify_file(path, sig.read_text(encoding="ascii"), self.key)

    def verify_encrypted(self, encrypted_path: str | Path) -> bool:
        key_path = getattr(self.config, "backup_encryption_key_path", None)
        if key_path is None: return False
        temp = Path(self.config.temp_dir) / (Path(encrypted_path).name + ".verify.db")
        try:
            decrypt_file(encrypted_path, temp, key_path)
            return temp.is_file()
        except Exception:
            return False
        finally:
            temp.unlink(missing_ok=True)

    def _recorded_sha(self, path: Path) -> str:
        with self.db.connect() as c:
            row = c.execute("SELECT sha256 FROM backups WHERE path=? ORDER BY id DESC LIMIT 1", (str(path),)).fetchone()
        return str(row[0]) if row else self.db.sha256(path)

    def restore(self, backup_path: str | Path, user_id: int | None = None) -> None:
        path = Path(backup_path)
        if not self.verify(path): raise ValueError("Не прошла проверка целостности резервной копии")
        self.db.restore(path)
        with self.db.transaction() as c: c.execute("INSERT INTO audit_log(user_id,action,entity_type,details_json) VALUES(?,?,?,?)", (user_id, "backup.restore", "database", json.dumps({"path": str(path)}, ensure_ascii=False)))

    def create_encrypted(self, user_id: int | None = None) -> Path:
        """Create an AES-GCM copy when an encryption key path is configured."""
        key_path = getattr(self.config, "backup_encryption_key_path", None)
        if key_path is None: raise ValueError("Не настроен ключ шифрования резервных копий")
        plain = self.db.backup(self.config.backup_dir, user_id); encrypted = plain.with_suffix(plain.suffix + ".enc")
        encrypt_file(plain, encrypted, key_path); plain.unlink(missing_ok=True)
        with self.db.transaction() as c: c.execute("INSERT INTO backups(path,sha256,created_by,size_bytes,status,metadata_json) VALUES(?,?,?,?,?,?)", (str(encrypted), self.db.sha256(encrypted), user_id, encrypted.stat().st_size, "encrypted", json.dumps({"algorithm": "AES-256-GCM"})))
        return encrypted

    def restore_encrypted(self, encrypted_path: str | Path, user_id: int | None = None) -> None:
        key_path = getattr(self.config, "backup_encryption_key_path", None)
        if key_path is None: raise ValueError("Не настроен ключ шифрования резервных копий")
        temp = Path(self.config.temp_dir) / (Path(encrypted_path).name + ".db")
        decrypt_file(encrypted_path, temp, key_path)
        try: self.db.restore(temp)
        finally: temp.unlink(missing_ok=True)
        with self.db.transaction() as c: c.execute("INSERT INTO audit_log(user_id,action,entity_type,details_json) VALUES(?,?,?,?)", (user_id, "backup.restore_encrypted", "database", json.dumps({"path": str(encrypted_path)}, ensure_ascii=False)))

from __future__ import annotations

import json
import zipfile
from pathlib import Path

from ..security import redact_diagnostics

class DiagnosticsService:
    """Create a support archive with paths, names and credentials redacted."""
    def create(self, output: str | Path, *, events=None, settings=None) -> Path:
        target = Path(output); target.parent.mkdir(parents=True, exist_ok=True)
        payload = {"events": redact_diagnostics(events or []), "settings": redact_diagnostics(settings or {})}
        text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive: archive.writestr("diagnostics.json", text)
        return target

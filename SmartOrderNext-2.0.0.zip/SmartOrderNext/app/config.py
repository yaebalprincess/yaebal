from __future__ import annotations
import json, os, tempfile
from dataclasses import dataclass
from pathlib import Path

def _expand(value: str | None) -> str | None:
    if value is None: return None
    text = os.path.expandvars(str(value))
    # Windows configuration commonly uses %APPDATA%; expandvars on POSIX does
    # not expand that form, so handle it explicitly for portable tests/configs.
    for key in ("APPDATA", "LOCALAPPDATA", "TEMP"):
        marker = f"%{key}%"
        if marker in text: text = text.replace(marker, os.environ.get(key, str(Path.home() / ".smartorder-next")))
    return text

@dataclass(frozen=True)
class AppConfig:
    data_dir: Path
    database_path: Path
    backup_dir: Path
    hmac_key_path: Path
    temp_dir: Path
    max_login_attempts: int = 5
    lockout_seconds: int = 300
    backup_encryption_key_path: Path | None = None

    def __post_init__(self):
        # Keep compatibility with the short-lived constructor ordering used by
        # early SmartOrderNext builds (encryption path was the sixth argument).
        if isinstance(self.max_login_attempts, (str, Path)) and self.backup_encryption_key_path is None:
            object.__setattr__(self, "backup_encryption_key_path", Path(self.max_login_attempts))
            object.__setattr__(self, "max_login_attempts", 5)

    @classmethod
    def load(cls, path: str|Path|None=None) -> 'AppConfig':
        p=Path(path or os.environ.get('SMARTORDER_CONFIG','config.json'))
        raw={}
        if p.exists():
            raw=json.loads(p.read_text(encoding='utf-8'))
        data=Path(_expand(raw.get('data_dir')) or os.environ.get('SMARTORDER_DATA_DIR') or (Path.home()/'.smartorder-next')).expanduser()
        db=Path(_expand(raw.get('database_path')) or data/'smartorder.db').expanduser()
        backups=Path(_expand(raw.get('backup_dir')) or data/'backups').expanduser()
        key=Path(_expand(raw.get('hmac_key_path')) or data/'hmac.key').expanduser()
        temp=Path(_expand(raw.get('temp_dir')) or tempfile.gettempdir()).expanduser()
        encryption_key = Path(_expand(raw.get('backup_encryption_key_path')) or data/'backup-encryption.key').expanduser()
        return cls(data, db, backups, key, temp, int(raw.get('max_login_attempts',5)), int(raw.get('lockout_seconds',300)), encryption_key)

    def ensure_dirs(self):
        for p in (self.data_dir,self.database_path.parent,self.backup_dir,self.temp_dir): p.mkdir(parents=True,exist_ok=True)

    @property
    def is_network_path(self):
        s=str(self.database_path); return s.startswith('\\\\') or s.startswith('//')

[CmdletBinding()]
param(
    [string]$Python = "python",
    [string]$OutputDir = "release",
    [switch]$Clean,
    [string]$SignTool = "",
    [string]$Certificate = "",
    [string]$ManifestPrivateKey = ""
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if ($Clean) { Remove-Item -Recurse -Force -ErrorAction SilentlyContinue build, dist, $OutputDir }
& $Python -m pip install -r requirements-lock.txt
& $Python -m PyInstaller --noconfirm --clean portable.spec
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
Copy-Item -Recurse -Force "dist/SmartOrderNext/*" $OutputDir
Copy-Item -Force config.example.json, README_RU.txt, THIRD_PARTY_NOTICES.txt $OutputDir
if (Test-Path resources) { Copy-Item -Recurse -Force resources "$OutputDir/resources" }
Copy-Item -Force SBOM.json "$OutputDir/SBOM.json"
if ($SignTool -and $Certificate) {
    $exe = Join-Path $OutputDir "SmartOrderNext.exe"
    & $SignTool sign /fd SHA256 /f $Certificate $exe
    & $SignTool verify /pa $exe
}
& $Python tools/build_manifest.py $OutputDir "2.0.0" (Join-Path $OutputDir "release.manifest.json")
if ($ManifestPrivateKey) {
    & $Python tools/sign_manifest.py (Join-Path $OutputDir "release.manifest.json") $ManifestPrivateKey (Join-Path $OutputDir "release.manifest.sig")
}
Write-Host "Portable build is in $OutputDir"

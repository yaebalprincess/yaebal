from __future__ import annotations
import os
import sys
from app.config import AppConfig
from app.database import Database
from app.services.auth import AuthService
from app.security import trusted_launch_path
from app.ui.responsive import install_dpi_awareness

def main() -> int:
    try:
        from PySide6.QtWidgets import QApplication, QDialog, QInputDialog, QMessageBox, QLineEdit
    except ImportError:
        print("PySide6 не установлен. Установите зависимости: pip install -r requirements.txt")
        return 2
    configured_roots = tuple(p for p in os.environ.get("SMARTORDER_TRUSTED_ROOTS", "").split(os.pathsep) if p)
    if getattr(sys, "frozen", False) and not configured_roots:
        configured_roots = (str(__import__("pathlib").Path(sys.executable).resolve().parent),)
    if configured_roots and not trusted_launch_path(sys.executable, configured_roots):
        print("Запуск запрещён: исполняемый файл находится вне доверенного каталога.")
        return 4
    install_dpi_awareness()
    app = QApplication(sys.argv)
    config = AppConfig.load()
    config.ensure_dirs()
    db = Database(config.database_path)
    auth = AuthService(db, config.max_login_attempts, config.lockout_seconds)
    # The first run creates a locked-down bootstrap account.  Deployment
    # scripts should set SMARTORDER_BOOTSTRAP_PASSWORD and rotate it at once.
    with db.connect() as conn:
        has_users = bool(conn.execute("SELECT 1 FROM users LIMIT 1").fetchone())
    if not has_users:
        bootstrap_password = os.environ.get("SMARTORDER_BOOTSTRAP_PASSWORD", "")
        if not bootstrap_password:
            bootstrap_password, ok = QInputDialog.getText(
                None, "Первичная настройка", "Задайте пароль администратора (не менее 12 символов):",
                QLineEdit.EchoMode.Password,
            )
            if not ok or len(bootstrap_password) < 12:
                QMessageBox.critical(None, "SmartOrderNext", "Первичная настройка отменена: нужен пароль длиной не менее 12 символов.")
                return 3
        if len(bootstrap_password) < 12:
            QMessageBox.critical(None, "SmartOrderNext", "Пароль администратора должен содержать не менее 12 символов.")
            return 3
        auth.ensure_admin("admin", bootstrap_password)
    from app.ui.login_dialog import LoginDialog
    from app.ui.main_window import MainWindow
    login = LoginDialog(auth)
    login.user_edit.setText(os.environ.get("SMARTORDER_LOGIN", "admin"))
    if login.exec() != QDialog.DialogCode.Accepted:
        return 0
    win = MainWindow(login.session, {"db": db, "config": config, "auth": auth}); win.show()
    return app.exec()

if __name__ == "__main__":
    raise SystemExit(main())

import json
from app.config import AppConfig

def test_config_accepts_unc_paths(tmp_path):
    p = tmp_path / 'config.json'
    p.write_text(json.dumps({'database_path': r'\\server\share\smartorder.db', 'backup_dir': r'\\server\share\backups'}), encoding='utf-8')
    cfg = AppConfig.load(p)
    assert 'smartorder.db' in str(cfg.database_path)
    assert cfg.is_network_path

from app.services.release_manifest import build_manifest, generate_keypair, sign_manifest, verify_manifest, verify_payload

def test_signed_manifest_and_tamper_detection(tmp_path):
    payload = tmp_path / "SmartOrderNext.exe"; payload.write_bytes(b"release")
    manifest = build_manifest(tmp_path, "2.0.0")
    private, public = generate_keypair(); signature = sign_manifest(manifest, private)
    assert verify_manifest(manifest, signature, public)
    assert verify_payload(tmp_path, manifest) == []
    payload.write_bytes(b"tampered")
    assert verify_payload(tmp_path, manifest)

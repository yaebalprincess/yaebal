import json
import sqlite3
import zipfile
from pathlib import Path

import pytest

from app.config import AppConfig
from app.database import Database
from app.security import trusted_launch_path
from app.services.auth import AuthService
from app.services.backup import BackupService
from app.services.diagnostics import DiagnosticsService
from app.services.order_files import OrderFileService


def _config(tmp_path: Path) -> AppConfig:
    cfg = AppConfig(tmp_path, tmp_path / "smartorder.db", tmp_path / "backups", tmp_path / "hmac.key", tmp_path / "tmp")
    cfg.ensure_dirs()
    return cfg


def test_lockout_survives_new_auth_service(tmp_path):
    db = Database(tmp_path / "auth.db")
    first = AuthService(db, max_attempts=2, lockout_seconds=120)
    first.create_user("operator", "correct-password", "viewer")
    assert first.login("operator", "wrong") is None
    assert first.login("operator", "wrong") is None

    # The lock is in the database, so restarting the client cannot bypass it.
    restarted = AuthService(db, max_attempts=2, lockout_seconds=120)
    assert restarted.login("operator", "correct-password") is None
    with db.transaction() as conn:
        conn.execute("UPDATE users SET locked_until=NULL, failed_attempts=0 WHERE username='operator'")
    assert restarted.login("operator", "correct-password") is not None


def test_deactivated_user_loses_active_session(tmp_path):
    db = Database(tmp_path / "auth.db")
    auth = AuthService(db)
    auth.create_user("operator", "correct-password", "viewer")
    session = auth.login("operator", "correct-password")
    assert session is not None and auth.active(session)
    with db.transaction() as conn:
        conn.execute("UPDATE users SET is_active=0 WHERE username='operator'")
    assert not auth.active(session)


def test_backup_and_signed_order_file_reject_tampering(tmp_path):
    cfg = _config(tmp_path)
    db = Database(cfg.database_path)
    backup = BackupService(db, cfg)
    backup_path = backup.create()
    assert backup.verify(backup_path)
    backup_path.write_bytes(backup_path.read_bytes() + b"tampered")
    assert not backup.verify(backup_path)

    order_path = tmp_path / "orders" / "order.sorder"
    files = OrderFileService(backup.key)
    files.publish({"id": 1, "version": "1"}, order_path)
    assert files.read_verified(order_path)["id"] == 1
    order_path.write_text('{"id": 2}', encoding="utf-8")
    with pytest.raises(ValueError):
        files.read_verified(order_path)


def test_encrypted_backup_roundtrip(tmp_path):
    cfg = AppConfig(tmp_path, tmp_path / "encrypted.db", tmp_path / "backups", tmp_path / "hmac.key", tmp_path / "tmp", backup_encryption_key_path=tmp_path / "backup.key")
    cfg.ensure_dirs(); db = Database(cfg.database_path)
    with db.transaction() as conn: conn.execute("INSERT INTO app_settings(key,value) VALUES('secret','value')")
    service = BackupService(db, cfg); encrypted = service.create_encrypted(); assert encrypted.suffix == ".enc"
    assert encrypted.read_bytes()[:8] != b"SQLite f"
    service.restore_encrypted(encrypted)
    with db.connect() as conn: assert conn.execute("SELECT value FROM app_settings WHERE key='secret'").fetchone()[0] == 'value'


def test_diagnostics_redacts_personal_data(tmp_path):
    archive = DiagnosticsService().create(
        tmp_path / "diagnostics.zip",
        events=[{"username": "ivan", "employee_name": "Петров", "token": "secret", "path": r"C:\Users\ivan\db.sqlite"}],
        settings={"database_path": r"\\server\share\smartorder.db"},
    )
    with zipfile.ZipFile(archive) as zf:
        text = zf.read("diagnostics.json").decode("utf-8")
    assert "ivan" not in text and "Петров" not in text and "secret" not in text
    assert "<redacted>" in text


def test_trusted_launch_path_requires_configured_root(tmp_path):
    trusted = tmp_path / "trusted"; untrusted = tmp_path / "downloads"
    trusted.mkdir(); untrusted.mkdir()
    executable = trusted / "SmartOrderNext.exe"; executable.write_bytes(b"")
    other = untrusted / "SmartOrderNext.exe"; other.write_bytes(b"")
    assert trusted_launch_path(executable, (trusted,))
    assert not trusted_launch_path(other, (trusted,))


def test_unc_database_config_is_detected(tmp_path):
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"database_path": r"\\server\share\smartorder.db"}), encoding="utf-8")
    assert AppConfig.load(config_file).is_network_path

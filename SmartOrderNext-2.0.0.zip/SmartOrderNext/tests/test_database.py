import sqlite3
from app.database import Database

def test_schema_and_transaction(tmp_path):
    db = Database(tmp_path / 'smartorder.db')
    with db.connect() as c:
        names = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    required = {'users','roles','permissions','workshops','employees','departments','work_types','work_orders','work_order_items','order_history','backups','audit_log','app_settings'}
    assert required <= names
    with db.transaction() as c:
        c.execute("INSERT INTO workshops(name,code) VALUES('Цех 1','W1')")
    with db.connect() as c:
        assert c.execute('SELECT COUNT(*) FROM workshops').fetchone()[0] == 1

def test_backup_and_restore(tmp_path):
    db = Database(tmp_path / 'source.db')
    with db.transaction() as c: c.execute("INSERT INTO app_settings(key,value) VALUES('x','1')")
    out = db.backup(tmp_path / 'backups')
    assert out.exists() and out.stat().st_size > 0
    db.restore(out)
    with db.connect() as c: assert c.execute("SELECT value FROM app_settings WHERE key='x'").fetchone()[0] == '1'

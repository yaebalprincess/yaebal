import sqlite3
from app.database import Database
from app.services.migration import LegacyImporter

def test_legacy_import_dry_run_and_copy(tmp_path):
    legacy = tmp_path / 'old.db'
    c = sqlite3.connect(legacy)
    c.executescript("CREATE TABLE departments(id INTEGER PRIMARY KEY, name TEXT); INSERT INTO departments VALUES(1,'Сборка'); CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT, password_hash TEXT, role TEXT); INSERT INTO users VALUES(1,'admin','', 'admin');")
    c.commit(); c.close()
    target = Database(tmp_path / 'new.db')
    report = LegacyImporter(target).import_db(legacy, dry_run=True)
    assert (report.get('departments') or report.get('tables', {}).get('departments')) == 1
    assert (report.get('users') or report.get('tables', {}).get('users')) == 1
    LegacyImporter(target).import_db(legacy)
    with target.connect() as c:
        assert c.execute('SELECT COUNT(*) FROM departments').fetchone()[0] == 1
        assert c.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 1

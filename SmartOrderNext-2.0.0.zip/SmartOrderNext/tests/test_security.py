from pathlib import Path
from app.security import hash_password, verify_password, SessionStore, LoginGuard, check_permission, sign_file, verify_file

def test_password_hash_is_not_plaintext():
    encoded = hash_password('Correct horse battery staple')
    assert encoded != 'Correct horse battery staple'
    assert verify_password('Correct horse battery staple', encoded)
    assert not verify_password('wrong', encoded)

def test_session_and_permissions():
    store = SessionStore(ttl=60)
    session = store.create(1, 'admin', 'admin')
    assert session.active() and check_permission(session, 'anything')
    store.revoke(session.token)
    assert store.get(session.token) is None

def test_login_guard_locks_out():
    guard = LoginGuard(max_attempts=2, lockout_seconds=60)
    assert guard.allow('u')
    guard.failed('u'); guard.failed('u')
    assert not guard.allow('u')
    guard.success('u')
    assert guard.allow('u')

def test_file_hmac(tmp_path: Path):
    p = tmp_path / 'order.sorder'; p.write_text('{"id":1}', encoding='utf-8')
    key = b'k' * 32
    sig = sign_file(p, key)
    assert verify_file(p, sig, key)
    p.write_text('{"id":2}', encoding='utf-8')
    assert not verify_file(p, sig, key)

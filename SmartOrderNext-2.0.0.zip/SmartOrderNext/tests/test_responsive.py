import pytest
from app.ui.responsive import ScaleController

@pytest.mark.parametrize('resolution', [(1024,768),(1280,720),(1280,1024),(1366,768),(1440,900),(1600,900),(1920,1080),(2560,1440),(3840,2160)])
@pytest.mark.parametrize('percent', [100,125,150,175,200])
def test_scale_range_is_clamped(resolution, percent):
    s = ScaleController(value=1.0)
    s.set_value(percent / 100)
    assert 1.0 <= s.value <= 2.0
    assert resolution[0] > 0 and resolution[1] > 0

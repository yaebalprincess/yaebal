# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files
hiddenimports = collect_submodules('app')
datas = collect_data_files('app')

analysis = Analysis(['main.py'], pathex=['.'], binaries=[], datas=datas,
                    hiddenimports=hiddenimports, hookspath=[], hooksconfig={},
                    runtime_hooks=[], excludes=[], noarchive=False)
pyz = PYZ(analysis.pure)
exe = EXE(pyz, analysis.scripts, analysis.binaries, analysis.datas,
          name='SmartOrderNext', debug=False, bootloader_ignore_signals=False,
          strip=False, upx=True, console=False)
